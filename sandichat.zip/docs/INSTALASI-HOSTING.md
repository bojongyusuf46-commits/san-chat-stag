# Panduan Instalasi SandiChat di Hosting (aaPanel, cPanel, & VPS)

Dokumen ini menjelaskan cara memasang dan menjalankan **SandiChat** (Dashboard Admin + Server Express + WebSocket `/ws` + Widget Embed `/embed.js`) di server produksi seperti **aaPanel**, **cPanel**, maupun **VPS Ubuntu/Debian**.

---

## 1. Persyaratan Sistem

- **Runtime Node.js**: Versi **Node.js 20 LTS** atau **Node.js 22 LTS** (disarankan Node.js 22+).
- **Manajer Proses / Proxy**:
  - **Nginx** atau **Apache** dengan dukungan **WebSocket Reverse Proxy (`Upgrade` & `Connection: upgrade`)**.
- **SSL / HTTPS Wajib untuk Domain Produksi**:
  - Fitur Enkripsi End-to-End (ECDH P-256 + AES-256-GCM) menggunakan **Web Crypto API (`window.crypto.subtle`)**, yang oleh browser modern hanya diaktifkan pada **`https://`** (atau `localhost`).
  - Widget juga dimuat lewat `wss://` agar tidak diblokir *Mixed Content* oleh website klien.
- **Ukuran Upload Body Proxy**:
  - Minimal `5M` (`client_max_body_size 10M;`) agar unggah foto profil CS maupun gambar/GIF launcher widget (maks 2 MB per file) berjalan lancar.

---

## 2. Persiapan Project & Variabel Lingkungan (`.env`)

1. Unggah atau clone kode sumber aplikasi ke direktori server (misalnya `/www/wwwroot/chat.domainanda.com` di aaPanel atau `/home/username/sandichat` di cPanel).
2. Pasang seluruh dependensi dan build frontend produksi:
   ```bash
   npm install
   npm run build
   ```
   Perintah `npm run build` akan menghasilkan folder `dist/` yang otomatis disajikan oleh `server.ts` saat `NODE_ENV=production`.

3. Buat file `.env` di root direktori project:
   ```env
   PORT=3000
   NODE_ENV=production
   APP_URL=https://chat.domainanda.com

   # Kredensial Login Dashboard Admin (wajib diisi untuk produksi)
   ADMIN_EMAIL=admin@domainanda.com
   ADMIN_PASSCODE=GantiDenganKataSandiKuatMin12Karakter!
   ```
   > **Catatan Keamanan:** Jika `ADMIN_PASSCODE` dikosongkan, dashboard menampilkan halaman pembuatan akun admin pertama secara sementara di memori server (akan hilang saat server restart). Untuk produksi, **selalu isi `ADMIN_EMAIL` dan `ADMIN_PASSCODE` di `.env`**.

---

## 3. Instalasi di aaPanel (Disarankan)

aaPanel mendukung Node.js + Nginx + WebSocket + SSL Let's Encrypt secara langsung dan sangat stabil untuk aplikasi real-time WebSocket.

### Langkah A — Pasang Node.js & Build Aplikasi
1. Login ke panel **aaPanel** -> buka menu **App Store**.
2. Pastikan **Nginx** terpasang.
3. Buka **Website -> Node project** -> klik **Node version manager**, pasang **Node.js v22 LTS** (atau v20 LTS).
4. Unggah file project ke `/www/wwwroot/chat.domainanda.com` (ekstrak `.zip` atau `git clone`).
5. Buka terminal SSH atau Terminal bawaan aaPanel di folder project, lalu jalankan:
   ```bash
   npm install
   npm run build
   ```
6. Buat file `.env` di `/www/wwwroot/chat.domainanda.com/.env` seperti pada Bagian 2.

### Langkah B — Jalankan Node Project di aaPanel
1. Masuk ke **Website -> Node project -> Add Node project**.
2. Isi konfigurasi berikut:
   - **Path**: `/www/wwwroot/chat.domainanda.com`
   - **Name**: `sandichat`
   - **Run opt**: pilih **Custom** atau script:
     - Jika memakai Node v22.18+: `node server.ts`
     - Jika memakai Node v20 / v22 awal: `./node_modules/.bin/tsx server.ts`
   - **Port**: `3000` (harus sama dengan `PORT=` di `.env`)
   - **Domain**: masukkan subdomain/domain Anda, misalnya `chat.domainanda.com`.
3. Centang **Auto start on boot** lalu klik **Submit**.
4. Pastikan status project menjadi **Running**.

### Langkah C — Pasang SSL & Konfigurasi Proxy WebSocket Nginx
1. Pada daftar **Node project**, klik **Settings** pada domain `chat.domainanda.com` -> tab **SSL** -> pasang sertifikat **Let's Encrypt** dan aktifkan **Force HTTPS**.
2. Buka tab **Config / Reverse Proxy** di pengaturan situs aaPanel, pastikan blok proxy memiliki dukungan **WebSocket (`/ws`)** dan ukuran upload `10M`:
   ```nginx
   location / {
       proxy_pass http://127.0.0.1:3000;
       proxy_http_version 1.1;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection "upgrade";
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
       proxy_read_timeout 86400s;
       proxy_send_timeout 86400s;
       client_max_body_size 10M;
   }
   ```
3. Simpan konfigurasi dan reload Nginx.
4. Uji akses `https://chat.domainanda.com/api/health` (harus mengembalikan `{"status":"ok",...}`), lalu login di `https://chat.domainanda.com`.

---

## 4. Instalasi di cPanel (Shared Hosting / CloudLinux)

SandiChat dapat dijalankan pada cPanel yang memiliki fitur **Setup Node.js App** (CloudLinux Phusion Passenger).

### Langkah A — Siapkan Direktori & Environment
1. Login ke **cPanel** -> buka **File Manager**.
2. Buat folder misalnya `/home/usercpanel/sandichat`, unggah seluruh file project (kecuali `node_modules`).
3. Buat file `.env` di `/home/usercpanel/sandichat/.env` berisi:
   ```env
   NODE_ENV=production
   APP_URL=https://chat.domainanda.com
   ADMIN_EMAIL=admin@domainanda.com
   ADMIN_PASSCODE=KataSandiKuatAnda!
   ```
   *(Catatan: Pada CloudLinux Passenger di cPanel, `PORT` biasanya disuntikkan otomatis oleh cPanel/Passenger; `server.ts` otomatis membaca `process.env.PORT || 3000`.)*

### Langkah B — Buat Entry Point CJS/JS untuk Passenger (Jika Node < 22.18)
Jika cPanel hanya menyediakan Node.js 18 atau 20 (belum mendukung TypeScript native), buat file `loader.mjs` atau jalankan build `server.mjs` dengan `esbuild`:
```bash
npx esbuild server.ts --bundle --platform=node --format=esm --packages=external --outfile=server.mjs
```
Atau buat file startup `app.cjs`:
```js
import('tsx/esm/api').then(({ register }) => {
  register();
  return import('./server.ts');
});
```

### Langkah C — Konfigurasi di Menu "Setup Node.js App"
1. Buka menu **Setup Node.js App** di cPanel -> klik **Create Application**.
2. Isi konfigurasi:
   - **Node.js version**: pilih **20.x** atau **22.x**.
   - **Application mode**: **Production**.
   - **Application root**: `sandichat`
   - **Application URL**: pilih domain/subdomain (mis. `chat.domainanda.com`).
   - **Application startup file**: `server.mjs` (hasil bundle esbuild) atau `app.cjs` atau `server.ts` (jika Node 22.18+).
3. Klik **Create**, lalu klik **Run NPM Install** pada halaman yang sama (atau jalankan lewat **Terminal** cPanel).
4. Masuk ke **Terminal** cPanel atau SSH, aktifkan virtual environment Node.js yang tampil di bagian atas halaman *Setup Node.js App*, lalu jalankan build frontend:
   ```bash
   npm run build
   # Jika perlu bundle server.ts ke server.mjs:
   npx esbuild server.ts --bundle --platform=node --format=esm --packages=external --outfile=server.mjs
   ```
5. Kembali ke **Setup Node.js App** dan klik **Restart**.
6. Aktifkan SSL melalui menu **SSL/TLS Status** (AutoSSL) agar domain berjalan di `https://`.

> **Penting Khusus Shared Hosting cPanel (Apache/LiteSpeed):**
> Sebagian paket shared hosting murah membatasi koneksi WebSocket (`/ws`) pada Phusion Passenger atau menutup port upgrade di LiteSpeed/Apache. Jika chat tidak tersambung *real-time* di shared hosting cPanel:
> - Gunakan **LiteSpeed WebSocket Proxy** / aktifkan `mod_proxy_wstunnel` di WHM (jika punya akses root/WHM), atau
> - Gunakan **aaPanel / VPS** dengan Nginx agar WebSocket `/ws` stabil 100% tanpa batas proses shared hosting.

---

## 5. Instalasi di VPS Ubuntu / Debian (PM2 + Nginx + Certbot)

Jika menggunakan VPS polos tanpa panel:

```bash
# 1. Pasang Node.js 22 LTS & PM2
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs nginx
sudo npm install -g pm2

# 2. Masuk ke folder project, install & build
cd /var/www/sandichat
npm install
npm run build

# 3. Jalankan dengan PM2 (tsx atau node v22.18+)
NODE_ENV=production pm2 start ./node_modules/.bin/tsx --name sandichat -- server.ts
pm2 save
pm2 startup
```

Buat konfigurasi Nginx `/etc/nginx/sites-available/sandichat`:
```nginx
server {
    listen 80;
    server_name chat.domainanda.com;

    client_max_body_size 10M;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
    }
}
```
Aktifkan site dan pasang SSL gratis Certbot:
```bash
sudo ln -s /etc/nginx/sites-available/sandichat /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d chat.domainanda.com
```

---

## 6. Memasang Livechat di Website Lain (Tanpa Integrasi Rumit)

Setelah server SandiChat aktif di `https://chat.domainanda.com`, cukup tempel **1 baris script** ini sebelum `</body>` di website mana saja (WordPress, Laravel, Shopify, HTML statis, React, Next.js):

```html
<script src="https://chat.domainanda.com/embed.js" defer></script>
```

---

## 7. Troubleshooting Umum

| Masalah | Penyebab | Solusi |
| :--- | :--- | :--- |
| **502 Bad Gateway** | Aplikasi Node belum berjalan atau port `.env` berbeda dengan Nginx | Cek status PM2/Node Project di aaPanel, pastikan port sama (`3000`) |
| **WebSocket gagal / status kuning** | Nginx/Proxy belum meneruskan header `Upgrade` | Tambahkan `proxy_set_header Upgrade $http_upgrade;` dan `Connection "upgrade";` |
| **Upload foto CS / GIF gagal 413** | Batas upload bawaan Nginx hanya 1 MB | Tambahkan `client_max_body_size 10M;` di config Nginx |
| **Enkripsi E2EE tidak aktif di browser** | Situs diakses lewat `http://` selain localhost | Pasang SSL (`https://`) melalui Let's Encrypt / AutoSSL |
| **Dashboard minta setup ulang setelah restart** | `ADMIN_PASSCODE` di `.env` belum diisi | Isi `ADMIN_EMAIL` dan `ADMIN_PASSCODE` pada file `.env`, lalu restart Node |
