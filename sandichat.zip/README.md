# SandiChat — Platform Livechat E2EE & Widget Embed

**SandiChat** adalah aplikasi livechat *real-time* berbasis **React + Vite + Express + WebSocket (`ws`)** dengan enkripsi *End-to-End* (**ECDH P-256 + AES-256-GCM**) di browser, panel admin **Live Inbox**, builder **Formulir Pra-Chat Kustom**, kustomisasi tampilan widget (termasuk maskot **GIF** saat widget tertutup & foto profil CS), **notifikasi suara**, serta script embed siap pakai (`/embed.js`) untuk dipasang di website lain tanpa integrasi backend yang rumit.

---

## Fitur Utama

- **Enkripsi End-to-End (E2EE)**: Pertukaran kunci ECDH kurva P-256 dan enkripsi pesan AES-256-GCM langsung di sisi browser (*Web Crypto API*).
- **Live Inbox & Multi-Room**: Pemantauan status pengunjung (*Online* / *Offline*), indikator sedang mengetik (*typing indicator*), hapus pesan, dan pemisahan sesi tiap pengunjung berdasarkan `roomId` unik.
- **Formulir Pra-Chat & Elemen Input Kustom**: Tambah/atur kolom input seperti *Username*, *Email*, *Angka*, *Textarea*, *Dropdown*, dan *Pilihan Opsi (Radio)* sebelum pengunjung memulai obrolan.
- **Kustomisasi Studio Widget & Launcher GIF**: Atur nama & foto CS, warna aksen, tema gelap, animasi, serta ganti tombol launcher tertutup menjadi gambar atau animasi `.gif`.
- **Upload Multi-Gambar Ketat**: Validasi ekstensi, *MIME type*, dan *magic bytes* file gambar (`PNG`, `JPEG`, `WebP`, `GIF`) di sisi klien dan server untuk memblokir skrip `.php`, `.svg`, HTML, maupun *polyglot*.
- **Notifikasi Suara Pesan Masuk**: Pengaturan suara terpisah untuk **Dashboard Admin** dan **Widget Pengunjung** dengan 4 pilihan nada, kontrol volume, serta tombol tes suara.
- **Autentikasi Dashboard Admin**: Halaman login admin dengan proteksi token sesi HMAC-SHA256, *rate limiting* percobaan login, dan dukungan kredensial melalui `.env` (`ADMIN_EMAIL` & `ADMIN_PASSCODE`).
- **Plug & Play Embed (`/embed.js`)**: Pasang widget ke website lain hanya dengan 1 baris `<script>`.

---

## Struktur Project

```text
.
├── server.ts                  # Server utama Express + WebSocket (/ws) + API + /embed.js
├── src/                       # Kode sumber frontend React + TypeScript + Tailwind CSS
│   ├── components/            # Inbox, Analytics, Studio Widget, Login, Widget Pengunjung, dll.
│   ├── hooks/                 # Hook koneksi WebSocket & dekripsi E2EE admin
│   ├── lib/                   # Kripto E2EE, validasi gambar ketat, payload codec, audio notif
│   └── types/                 # Definisi tipe TypeScript
├── docs/
│   └── INSTALASI-HOSTING.md   # Panduan detail khusus aaPanel, cPanel, dan VPS
├── .env.example               # Contoh variabel lingkungan
├── package.json
└── vite.config.ts
```

---

## Persyaratan Server

- **Node.js**: Versi **20 LTS** atau **22 LTS** (disarankan **Node.js v22.18+** agar `node server.ts` berjalan langsung tanpa flag tambahan; untuk Node 20/22 awal gunakan `tsx` atau bundle `esbuild`).
- **npm**: Versi 9+.
- **Reverse Proxy**: **Nginx** (disarankan) atau Apache/LiteSpeed dengan dukungan **WebSocket (`Upgrade` & `Connection: upgrade`)**.
- **SSL / HTTPS Wajib di Produksi**:
  - Fitur enkripsi E2EE menggunakan `window.crypto.subtle` (*Web Crypto API*), yang oleh browser modern **wajib diakses melalui `https://`** (atau `http://localhost` saat pengembangan lokal).
  - Koneksi WebSocket produksi berjalan di `wss://` agar tidak diblokir *Mixed Content* saat widget dipasang di website pihak ketiga.
- **Batas Upload Proxy**: Set `client_max_body_size 10M;` pada Nginx agar upload gambar obrolan, foto CS, dan GIF launcher berjalan lancar.

---

## 1. Menjalankan di Lokal (Development)

1. **Install dependensi:**
   ```bash
   npm install
   ```

2. **Salin file `.env.example` menjadi `.env`:**
   ```bash
   cp .env.example .env
   ```
   Isi kredensial admin di `.env` (opsional saat development — jika dikosongkan, halaman awal akan menampilkan formulir pembuatan akun admin pertama kali):
   ```env
   PORT=3000
   ADMIN_EMAIL=admin@domainanda.com
   ADMIN_PASSCODE=GantiDenganSandiMinimal8Karakter
   ```

3. **Jalankan server development:**
   ```bash
   npm run dev
   ```
   Aplikasi dapat diakses di `http://localhost:3000`.

---

## 2. Cara Instalasi ke Server Produksi (VPS / aaPanel / cPanel)

### Langkah A — Persiapan Kode & Build Produksi

Di direktori project pada server (misalnya `/var/www/sandichat` atau `/www/wwwroot/chat.domainanda.com`):

```bash
# 1. Install seluruh dependensi
npm install

# 2. Build frontend React/Vite ke folder dist/
npm run build
```

Perintah `npm run build` akan menghasilkan folder `dist/`. Saat `NODE_ENV=production`, `server.ts` otomatis menyajikan file statis dari `dist/` dan `/src/assets/images` sekaligus melayani API dan WebSocket pada port yang sama.

### Langkah B — Konfigurasi File `.env` Produksi

Buat file `.env` di root direktori project:

```env
PORT=3000
NODE_ENV=production
APP_URL=https://chat.domainanda.com

# Kredensial Login Dashboard Admin (wajib diisi untuk server produksi)
ADMIN_EMAIL=admin@domainanda.com
ADMIN_PASSCODE=GantiDenganKataSandiKuatMin12Karakter!

# Opsional: kunci rahasia penandatangan token sesi admin (jika kosong akan dibuat acak tiap restart)
SESSION_SECRET=isi_string_acak_panjang_64_karakter_hex
```

> **Catatan Keamanan:** Jika `ADMIN_PASSCODE` dikosongkan, akun admin yang dibuat lewat formulir setup awal hanya tersimpan di memori sementara dan akan terhapus saat server restart. Untuk server produksi, **selalu isi `ADMIN_EMAIL` dan `ADMIN_PASSCODE` di `.env`**.

---

### Langkah C — Menjalankan Server Node.js

Pilih cara sesuai versi Node.js di server Anda:

- **Node.js v22.18+ (native TypeScript):**
  ```bash
  NODE_ENV=production npm start
  ```
- **Node.js v20 LTS / v22 awal (dengan `tsx` atau PM2):**
  ```bash
  NODE_ENV=production pm2 start ./node_modules/.bin/tsx --name sandichat -- server.ts
  pm2 save
  pm2 startup
  ```
- **Alternatif bundle `server.mjs` (cocok untuk cPanel / shared Node runner):**
  ```bash
  npx esbuild server.ts --bundle --platform=node --format=esm --packages=external --outfile=server.mjs
  NODE_ENV=production node server.mjs
  ```

---

### Langkah D — Konfigurasi Nginx Reverse Proxy & SSL (VPS / aaPanel)

Tambahkan konfigurasi Nginx untuk domain Anda (misalnya `/etc/nginx/sites-available/sandichat` pada VPS atau di menu **Reverse Proxy / Config** pada aaPanel):

```nginx
server {
    listen 80;
    server_name chat.domainanda.com;

    client_max_body_size 10M;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
    }
}
```

Aktifkan konfigurasi Nginx dan pasang sertifikat SSL gratis (Certbot / Let's Encrypt):

```bash
sudo ln -s /etc/nginx/sites-available/sandichat /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d chat.domainanda.com
```

> Untuk langkah detail bergambar/panel khusus **aaPanel** dan **cPanel (Setup Node.js App)**, lihat dokumen lengkap di [`docs/INSTALASI-HOSTING.md`](docs/INSTALASI-HOSTING.md).

---

## 3. Memasang Widget Livechat di Website Lain

Setelah server SandiChat aktif di `https://chat.domainanda.com`, Anda tidak perlu melakukan integrasi backend tambahan. Cukup tempelkan **1 baris script** ini sebelum tag penutup `</body>` di website target (HTML statis, WordPress, Laravel, Shopify, React, Next.js, dll.):

```html
<script src="https://chat.domainanda.com/embed.js" defer></script>
```

---

## 4. Verifikasi & Endpoint Server

| Endpoint / Path | Fungsi |
| :--- | :--- |
| `GET /` | Dashboard Admin (halaman login & panel pengelola) |
| `GET /?embed=1` | Halaman widget pengunjung standalone (dimuat dalam iframe oleh `embed.js`) |
| `GET /embed.js` | Script loader widget pihak ketiga |
| `GET /api/health` | Cek status kesehatan server (`{"status":"ok",...}`) |
| `GET /api/v1/widget-config` | Konfigurasi tampilan, form pra-chat, dan notifikasi widget aktif |
| `WS /ws` | Jalur WebSocket real-time untuk chat, status online, dan indikator mengetik |

---

## 5. Troubleshooting Umum

| Masalah | Penyebab | Solusi |
| :--- | :--- | :--- |
| **502 Bad Gateway** | Aplikasi Node belum berjalan atau port `.env` tidak cocok | Pastikan proses `pm2` / Node running dan `PORT` sama dengan `proxy_pass` (`3000`). |
| **Status WebSocket kuning / tidak real-time** | Reverse proxy tidak meneruskan header WebSocket | Pastikan `proxy_http_version 1.1;`, `Upgrade`, dan `Connection "upgrade";` ada di Nginx. |
| **Error 413 saat upload foto/GIF** | Limit ukuran body bawaan Nginx hanya 1 MB | Tambahkan `client_max_body_size 10M;` di blok `server` atau `location /` Nginx. |
| **E2EE gagal aktif di browser** | Domain diakses melalui `http://` non-localhost | Aktifkan SSL (`https://`) menggunakan Let's Encrypt / AutoSSL. |
| **Sesi login admin ter-reset setelah restart** | `SESSION_SECRET` / `ADMIN_PASSCODE` belum diset | Isi `ADMIN_EMAIL`, `ADMIN_PASSCODE`, dan `SESSION_SECRET` di file `.env`. |
