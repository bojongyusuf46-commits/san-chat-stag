export type LogoStyle = 'shield' | 'waveform' | 'hexagon' | 'custom';
export type SurfaceContrast = 'obsidian' | 'slate' | 'midnight';
export type BorderRadiusScale = 'sharp' | 'balanced' | 'soft';
export type TypingAnimationStyle = 'wave' | 'dots' | 'pulse-bar' | 'minimal';
export type EntranceAnimationStyle = 'spring' | 'slide' | 'fade';
export type CustomFormFieldType = 'text' | 'email' | 'number' | 'textarea' | 'select' | 'radio';
export type LauncherMode = 'button' | 'image';
export type LauncherImageShape = 'floating' | 'circle' | 'rounded';
export type NotificationSoundPreset = 'chime' | 'pop' | 'bell' | 'subtle';

export interface CustomFormField {
  id: string;
  label: string;
  key: string;
  type: CustomFormFieldType;
  placeholder?: string;
  required: boolean;
  options?: string[];
}

export interface WidgetSettings {
  brandName: string;
  agentName: string;
  agentAvatarUrl: string;
  logoStyle: LogoStyle;
  customLogoUrl: string;
  accentColor: string;
  surfaceContrast: SurfaceContrast;
  borderRadius: BorderRadiusScale;
  typingAnimation: TypingAnimationStyle;
  entranceAnimation: EntranceAnimationStyle;
  welcomeMessage: string;
  offlineMessage: string;
  inputPlaceholder: string;
  enforceE2EE: boolean;
  showReadReceipts: boolean;
  adminSoundEnabled: boolean;
  widgetSoundEnabled: boolean;
  soundPreset: NotificationSoundPreset;
  soundVolume: number;
  launcherPosition: 'bottom-right' | 'bottom-left';
  launcherMode: LauncherMode;
  launcherImageUrl: string;
  launcherImageShape: LauncherImageShape;
  launcherImageSize: number;
  launcherBubbleText: string;
  preChatFormEnabled: boolean;
  preChatFormTitle: string;
  preChatFormDescription: string;
  preChatSubmitLabel: string;
  preChatFields: CustomFormField[];
}

export interface ImageAttachment {
  dataUrl: string;
  fileName: string;
  mimeType: 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif';
  sizeBytes: number;
  width?: number;
  height?: number;
}

export interface ChatMessage {
  id: string;
  roomId: string;
  senderId: string;
  senderName: string;
  senderRole: 'visitor' | 'agent' | 'api' | 'system';
  encrypted: boolean;
  ciphertext?: string;
  iv?: string;
  senderPublicKey?: JsonWebKey;
  keyFingerprint?: string;
  plaintext?: string;
  attachment?: ImageAttachment;
  attachments?: ImageAttachment[];
  timestamp: number;
  read?: boolean;
}

export interface TypingState {
  roomId: string;
  senderId: string;
  senderName: string;
  senderRole: 'visitor' | 'agent';
  isTyping: boolean;
  updatedAt: number;
}

export interface VisitorRoom {
  id: string;
  visitorName: string;
  visitorEmail?: string;
  visitorAvatar?: string;
  customAttributes?: Record<string, string>;
  currentPage: string;
  location: string;
  device: string;
  browser: string;
  status: 'active' | 'idle' | 'resolved';
  online: boolean;
  unreadCount: number;
  e2eeVerified: boolean;
  visitorPublicKey?: JsonWebKey;
  keyFingerprint?: string;
  startedAt: number;
  lastActivityAt: number;
  lastMessagePreview: string;
  lastMessageEncrypted: boolean;
  messageCount: number;
}

export interface HourlyBucket {
  hour: string;
  totalMessages: number;
  encryptedMessages: number;
  avgResponseSec: number;
}

export interface AnalyticsSnapshot {
  totalMessages: number;
  encryptedMessages: number;
  encryptionRate: number;
  activeVisitors: number;
  totalRooms: number;
  avgFirstResponseSec: number;
  hourlyVolume: HourlyBucket[];
  topPages: Array<{ path: string; visitors: number; share: number }>;
  deviceSplit: Array<{ label: string; count: number; percentage: number }>;
}

export interface ApiKeyRecord {
  id: string;
  name: string;
  prefix: string;
  scopes: string[];
  createdAt: number;
  lastUsedAt: number | null;
  requestsCount: number;
}

export interface WebhookConfig {
  id: string;
  url: string;
  events: string[];
  active: boolean;
  createdAt: number;
  lastStatus: number | null;
  lastTriggeredAt: number | null;
}

export type NavSection = 'inbox' | 'analytics' | 'studio' | 'api';

export interface AdminAuthUser {
  email: string;
  name: string;
  role: 'admin';
}

export interface AuthStatusResponse {
  authenticated: boolean;
  setupRequired: boolean;
  envManaged: boolean;
  expectedEmailHint: string | null;
  user: AdminAuthUser | null;
}
