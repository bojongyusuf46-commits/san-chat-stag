import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  decryptWithAESGCM,
  deriveSharedAESKey,
  encryptWithAESGCM,
  getOrCreateWorkspaceIdentity,
  importPublicKeyJWK,
  type StoredIdentity,
} from '../lib/crypto';
import { decodeChatPayload, encodeChatPayload } from '../lib/payloadCodec';
import { installAudioUnlockListeners, playNotificationSound } from '../lib/soundNotifier';
import type {
  AnalyticsSnapshot,
  ChatMessage,
  ImageAttachment,
  TypingState,
  VisitorRoom,
  WidgetSettings,
} from '../types/chat';

export interface DecryptedChatMessage extends ChatMessage {
  displayText: string;
  displayAttachments: ImageAttachment[];
  decryptionStatus: 'decrypted' | 'plaintext' | 'pending' | 'unreadable';
}

function formatPreviewFromMessage(msg: DecryptedChatMessage): string | null {
  if (msg.decryptionStatus === 'pending' || msg.decryptionStatus === 'unreadable') {
    return null;
  }
  const text = msg.displayText.trim();
  if (msg.displayAttachments.length > 0) {
    return text
      ? `[${msg.displayAttachments.length} Gambar] ${text}`
      : `[${msg.displayAttachments.length} Gambar] ${msg.displayAttachments[0].fileName}`;
  }
  return text || null;
}

const DEFAULT_SETTINGS: WidgetSettings = {
  brandName: 'SandiChat',
  agentName: 'Citra Pratama',
  agentAvatarUrl: '/src/assets/images/avatar_admin_agent_1795413952963.jpg',
  logoStyle: 'shield',
  customLogoUrl: '',
  accentColor: '#10B981',
  surfaceContrast: 'obsidian',
  borderRadius: 'balanced',
  typingAnimation: 'wave',
  entranceAnimation: 'spring',
  welcomeMessage:
    'Halo! Percakapan ini dilindungi enkripsi end-to-end. Ada yang bisa kami bantu hari ini?',
  offlineMessage:
    'Tim kami sedang offline. Tinggalkan pesan terenkripsi dan kami akan segera membalas.',
  inputPlaceholder: 'Tulis pesan terenkripsi...',
  enforceE2EE: true,
  showReadReceipts: true,
  adminSoundEnabled: true,
  widgetSoundEnabled: true,
  soundPreset: 'chime',
  soundVolume: 70,
  launcherPosition: 'bottom-right',
  launcherMode: 'button',
  launcherImageUrl: '',
  launcherImageShape: 'floating',
  launcherImageSize: 72,
  launcherBubbleText: '',
  preChatFormEnabled: true,
  preChatFormTitle: 'Mulai Percakapan Terenkripsi',
  preChatFormDescription: 'Lengkapi data singkat di bawah ini sebelum terhubung dengan tim kami.',
  preChatSubmitLabel: 'Mulai Obrolan',
  preChatFields: [
    {
      id: 'field-username',
      label: 'Username',
      key: 'username',
      type: 'text',
      placeholder: 'Masukkan username Anda...',
      required: true,
    },
    {
      id: 'field-topic',
      label: 'Topik Bantuan',
      key: 'topik',
      type: 'radio',
      required: true,
      options: ['Dukungan Teknis', 'Integrasi API', 'Pertanyaan Billing'],
    },
  ],
};

interface UseLiveChatSocketOptions {
  authToken: string | null;
  onUnauthorized?: () => void;
}

export function useLiveChatSocket({ authToken, onUnauthorized }: UseLiveChatSocketOptions) {
  const [connected, setConnected] = useState(false);
  const [settings, setSettings] = useState<WidgetSettings>(DEFAULT_SETTINGS);
  const [rooms, setRooms] = useState<VisitorRoom[]>([]);
  const [activeRoomId, setActiveRoomId] = useState<string>('room-nadia-841');
  const [messagesMap, setMessagesMap] = useState<Record<string, DecryptedChatMessage[]>>({});
  const [typingMap, setTypingMap] = useState<Record<string, TypingState | null>>({});
  const [analytics, setAnalytics] = useState<AnalyticsSnapshot | null>(null);
  const [workspaceFingerprint, setWorkspaceFingerprint] = useState<string>('');
  const [loadingMessages, setLoadingMessages] = useState(false);

  const wsRef = useRef<WebSocket | null>(null);
  const identityRef = useRef<StoredIdentity | null>(null);
  const reconnectTimerRef = useRef<number | null>(null);
  const typingTimeoutRef = useRef<number | null>(null);
  const activeRoomRef = useRef<string>(activeRoomId);
  const roomsRef = useRef<VisitorRoom[]>(rooms);
  const settingsRef = useRef<WidgetSettings>(settings);
  const seenMessageIdsRef = useRef<Set<string>>(new Set());
  const authTokenRef = useRef<string | null>(authToken);
  const onUnauthorizedRef = useRef(onUnauthorized);

  activeRoomRef.current = activeRoomId;
  roomsRef.current = rooms;
  settingsRef.current = settings;
  authTokenRef.current = authToken;
  onUnauthorizedRef.current = onUnauthorized;

  const decryptEnvelope = useCallback(
    async (msg: ChatMessage, roomFallbackPubKey?: JsonWebKey): Promise<DecryptedChatMessage> => {
      if (!msg.encrypted) {
        const plainAttachments =
          msg.attachments && msg.attachments.length > 0
            ? msg.attachments
            : msg.attachment
              ? [msg.attachment]
              : [];
        return {
          ...msg,
          displayText: msg.plaintext ?? '',
          displayAttachments: plainAttachments,
          decryptionStatus: 'plaintext',
        };
      }

      const identity = identityRef.current;
      const peerJwk = msg.senderPublicKey || roomFallbackPubKey;

      if (!identity || !peerJwk || !msg.ciphertext || !msg.iv) {
        return {
          ...msg,
          displayText: 'Payload terenkripsi (menunggu kunci publik sesi)',
          displayAttachments: [],
          decryptionStatus: 'pending',
        };
      }

      try {
        // When agent sends a message encrypted for a visitor, msg.senderPublicKey is workspace public key.
        // We derive using the room's visitor public key so the agent can also read its own sent messages.
        const isSelfSent =
          msg.senderRole === 'agent' &&
          peerJwk.x === identity.publicJwk.x &&
          peerJwk.y === identity.publicJwk.y;
        const targetJwk = isSelfSent ? roomFallbackPubKey : peerJwk;

        if (!targetJwk) {
          return {
            ...msg,
            displayText: 'Pesan terenkripsi keluar (ECDH P-256)',
            displayAttachments: [],
            decryptionStatus: 'pending',
          };
        }

        const peerKey = await importPublicKeyJWK(targetJwk);
        const aesKey = await deriveSharedAESKey(identity.keyPair.privateKey, peerKey);
        const plain = await decryptWithAESGCM(aesKey, msg.ciphertext, msg.iv);
        const decoded = decodeChatPayload(plain);
        return {
          ...msg,
          displayText: decoded.text,
          displayAttachments: decoded.attachments,
          decryptionStatus: 'decrypted',
        };
      } catch {
        return {
          ...msg,
          displayText: 'Tidak dapat mendekripsi dengan kunci lokal saat ini',
          displayAttachments: [],
          decryptionStatus: 'unreadable',
        };
      }
    },
    []
  );

  const loadRoomMessages = useCallback(
    async (roomId: string, visitorPubKey?: JsonWebKey, silent = false) => {
      const token = authTokenRef.current;
      if (!token) return;
      if (!silent) setLoadingMessages(true);
      try {
        const res = await fetch(`/api/rooms/${encodeURIComponent(roomId)}/messages`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.status === 401) {
          onUnauthorizedRef.current?.();
          return;
        }
        if (!res.ok) return;
        const data = (await res.json()) as { messages: ChatMessage[] };
        const roomObj = roomsRef.current.find((r) => r.id === roomId);
        const fallbackKey = visitorPubKey || roomObj?.visitorPublicKey;
        const decrypted = await Promise.all(
          data.messages.map((m) => decryptEnvelope(m, fallbackKey))
        );
        for (const m of decrypted) {
          seenMessageIdsRef.current.add(m.id);
        }
        setMessagesMap((prev) => ({
          ...prev,
          [roomId]: decrypted,
        }));
      } finally {
        if (!silent) setLoadingMessages(false);
      }
    },
    [decryptEnvelope]
  );

  const selectRoom = useCallback(
    (roomId: string) => {
      setActiveRoomId(roomId);
      const room = roomsRef.current.find((r) => r.id === roomId);
      void loadRoomMessages(roomId, room?.visitorPublicKey);
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'room:read', roomId }));
      }
      setRooms((prev) =>
        prev.map((r) => (r.id === roomId ? { ...r, unreadCount: 0 } : r))
      );
    },
    [loadRoomMessages]
  );

  useEffect(() => {
    if (!authToken) {
      setConnected(false);
      wsRef.current?.close();
      wsRef.current = null;
      return;
    }

    let cancelled = false;
    installAudioUnlockListeners();

    async function bootstrap() {
      const identity = await getOrCreateWorkspaceIdentity();
      if (cancelled) return;
      identityRef.current = identity;
      setWorkspaceFingerprint(identity.fingerprint);

      // Register workspace public key with server (private key stays strictly in browser)
      const keyRes = await fetch('/api/workspace-key', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({
          publicKey: identity.publicJwk,
          fingerprint: identity.fingerprint,
        }),
      }).catch(() => null);
      if (keyRes?.status === 401) {
        onUnauthorizedRef.current?.();
        return;
      }

      function connectSocket() {
        if (cancelled) return;
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
        wsRef.current = ws;

        ws.onopen = () => {
          setConnected(true);
          ws.send(JSON.stringify({ type: 'join', role: 'agent', token: authToken }));
        };

        ws.onmessage = async (event) => {
          try {
            const payload = JSON.parse(event.data as string) as Record<string, unknown>;
            const type = payload.type;

            if (type === 'auth:error') {
              onUnauthorizedRef.current?.();
              return;
            }

            if (type === 'init') {
              const incomingSettings = payload.settings as WidgetSettings | undefined;
              const incomingRooms = (payload.rooms as VisitorRoom[]) ?? [];
              const incomingAnalytics = payload.analytics as AnalyticsSnapshot | undefined;

              if (incomingSettings) {
                setSettings({
                  ...DEFAULT_SETTINGS,
                  ...incomingSettings,
                  preChatFields: Array.isArray(incomingSettings.preChatFields)
                    ? incomingSettings.preChatFields
                    : DEFAULT_SETTINGS.preChatFields,
                });
              }
              setRooms(incomingRooms);
              if (incomingAnalytics) setAnalytics(incomingAnalytics);

              const currentId =
                incomingRooms.some((r) => r.id === activeRoomRef.current)
                  ? activeRoomRef.current
                  : incomingRooms[0]?.id ?? '';
              if (currentId) {
                setActiveRoomId(currentId);
                const target = incomingRooms.find((r) => r.id === currentId);
                void loadRoomMessages(currentId, target?.visitorPublicKey);
              }
              for (const r of incomingRooms) {
                if (r.id !== currentId) {
                  void loadRoomMessages(r.id, r.visitorPublicKey, true);
                }
              }
            } else if (type === 'settings:updated') {
              if (payload.settings) {
                const incoming = payload.settings as WidgetSettings;
                setSettings({
                  ...DEFAULT_SETTINGS,
                  ...incoming,
                  preChatFields: Array.isArray(incoming.preChatFields)
                    ? incoming.preChatFields
                    : DEFAULT_SETTINGS.preChatFields,
                });
              }
            } else if (type === 'room:updated') {
              const updatedRoom = payload.room as VisitorRoom | undefined;
              if (updatedRoom) {
                setRooms((prev) => {
                  const exists = prev.some((r) => r.id === updatedRoom.id);
                  const next = exists
                    ? prev.map((r) => (r.id === updatedRoom.id ? updatedRoom : r))
                    : [updatedRoom, ...prev];
                  return [...next].sort((a, b) => b.lastActivityAt - a.lastActivityAt);
                });
                if (updatedRoom.visitorPublicKey) {
                  setMessagesMap((prev) => {
                    const list = prev[updatedRoom.id];
                    if (list && list.some((m) => m.decryptionStatus === 'pending')) {
                      void loadRoomMessages(updatedRoom.id, updatedRoom.visitorPublicKey, true);
                    }
                    return prev;
                  });
                }
              }
              if (payload.analytics) {
                setAnalytics(payload.analytics as AnalyticsSnapshot);
              }
            } else if (type === 'message:new') {
              const rawMsg = payload.message as ChatMessage | undefined;
              if (!rawMsg) return;
              const isNewlyAdded = !seenMessageIdsRef.current.has(rawMsg.id);
              seenMessageIdsRef.current.add(rawMsg.id);

              const room = roomsRef.current.find((r) => r.id === rawMsg.roomId);
              const dec = await decryptEnvelope(rawMsg, room?.visitorPublicKey);

              setMessagesMap((prev) => {
                const existing = prev[rawMsg.roomId] ?? [];
                if (existing.some((m) => m.id === rawMsg.id)) {
                  return prev;
                }
                return {
                  ...prev,
                  [rawMsg.roomId]: [...existing, dec],
                };
              });

              if (
                isNewlyAdded &&
                rawMsg.senderRole === 'visitor' &&
                settingsRef.current.adminSoundEnabled
              ) {
                void playNotificationSound(
                  settingsRef.current.soundPreset,
                  settingsRef.current.soundVolume
                );
              }

              if (
                rawMsg.roomId === activeRoomRef.current &&
                rawMsg.senderRole === 'visitor' &&
                ws.readyState === WebSocket.OPEN
              ) {
                ws.send(JSON.stringify({ type: 'room:read', roomId: rawMsg.roomId }));
              }
            } else if (type === 'typing:state') {
              const typing = payload.typing as TypingState | undefined;
              if (!typing) return;
              if (typing.senderRole === 'agent') return;
              setTypingMap((prev) => ({
                ...prev,
                [typing.roomId]: typing.isTyping ? typing : null,
              }));
            } else if (type === 'room:read') {
              const rId = payload.roomId as string;
              setMessagesMap((prev) => {
                const list = prev[rId];
                if (!list) return prev;
                return {
                  ...prev,
                  [rId]: list.map((m) => ({ ...m, read: true })),
                };
              });
            } else if (type === 'message:deleted') {
              const rId = payload.roomId as string;
              const mId = payload.messageId as string;
              if (rId && mId) {
                setMessagesMap((prev) => {
                  const list = prev[rId];
                  if (!list) return prev;
                  return {
                    ...prev,
                    [rId]: list.filter((m) => m.id !== mId),
                  };
                });
              }
            }
          } catch {
            // Ignore malformed socket events
          }
        };

        ws.onclose = () => {
          setConnected(false);
          if (!cancelled) {
            reconnectTimerRef.current = window.setTimeout(connectSocket, 2000);
          }
        };
      }

      connectSocket();
    }

    void bootstrap();

    return () => {
      cancelled = true;
      if (reconnectTimerRef.current) {
        clearTimeout(reconnectTimerRef.current);
      }
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      wsRef.current?.close();
    };
  }, [authToken, decryptEnvelope, loadRoomMessages]);

  const sendAgentMessage = useCallback(
    async (roomId: string, text: string, attachments: ImageAttachment[] = []) => {
      const trimmed = text.trim();
      const hasAttachments = attachments.length > 0;
      if (
        (!trimmed && !hasAttachments) ||
        !wsRef.current ||
        wsRef.current.readyState !== WebSocket.OPEN
      ) {
        return;
      }

      const room = roomsRef.current.find((r) => r.id === roomId);
      const identity = identityRef.current;
      const canEncrypt = Boolean(
        settings.enforceE2EE && identity && room?.visitorPublicKey
      );

      const senderLabel = settings.agentName?.trim() || 'Citra Pratama';
      let envelope: ChatMessage;
      if (canEncrypt && identity && room?.visitorPublicKey) {
        const peerKey = await importPublicKeyJWK(room.visitorPublicKey);
        const aesKey = await deriveSharedAESKey(identity.keyPair.privateKey, peerKey);
        const encodedPayload = encodeChatPayload(trimmed, attachments);
        const { ciphertext, iv } = await encryptWithAESGCM(aesKey, encodedPayload);
        envelope = {
          id: `msg_${crypto.randomUUID()}`,
          roomId,
          senderId: 'agent-citra',
          senderName: senderLabel,
          senderRole: 'agent',
          encrypted: true,
          ciphertext,
          iv,
          senderPublicKey: identity.publicJwk,
          keyFingerprint: room.keyFingerprint || identity.fingerprint,
          timestamp: Date.now(),
          read: true,
        };
      } else {
        envelope = {
          id: `msg_${crypto.randomUUID()}`,
          roomId,
          senderId: 'agent-citra',
          senderName: senderLabel,
          senderRole: 'agent',
          encrypted: false,
          plaintext: trimmed,
          attachment: attachments[0],
          attachments: hasAttachments ? attachments : undefined,
          keyFingerprint: room?.keyFingerprint || identity?.fingerprint,
          timestamp: Date.now(),
          read: true,
        };
      }

      // Optimistic add
      seenMessageIdsRef.current.add(envelope.id);
      const optimistic: DecryptedChatMessage = {
        ...envelope,
        displayText: trimmed,
        displayAttachments: attachments,
        decryptionStatus: envelope.encrypted ? 'decrypted' : 'plaintext',
      };
      setMessagesMap((prev) => {
        const current = prev[roomId] ?? [];
        if (current.some((m) => m.id === optimistic.id)) return prev;
        return { ...prev, [roomId]: [...current, optimistic] };
      });

      wsRef.current.send(
        JSON.stringify({
          type: 'message:send',
          message: envelope,
        })
      );
    },
    [settings.enforceE2EE, settings.agentName]
  );

  const emitAgentTyping = useCallback((roomId: string, isTyping: boolean) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    wsRef.current.send(
      JSON.stringify({
        type: 'typing:update',
        roomId,
        senderId: 'agent-citra',
        senderName: 'Citra Pratama',
        senderRole: 'agent',
        isTyping,
      })
    );

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    if (isTyping) {
      typingTimeoutRef.current = window.setTimeout(() => {
        if (wsRef.current?.readyState === WebSocket.OPEN) {
          wsRef.current.send(
            JSON.stringify({
              type: 'typing:update',
              roomId,
              senderId: 'agent-citra',
              senderName: 'Citra Pratama',
              senderRole: 'agent',
              isTyping: false,
            })
          );
        }
      }, 2200);
    }
  }, []);

  const updateRoomStatus = useCallback(
    async (roomId: string, status: VisitorRoom['status']) => {
      const token = authTokenRef.current;
      if (!token) return;
      const res = await fetch(`/api/rooms/${encodeURIComponent(roomId)}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status }),
      });
      if (res.status === 401) {
        onUnauthorizedRef.current?.();
        return;
      }
      if (res.ok) {
        const data = (await res.json()) as { room: VisitorRoom };
        setRooms((prev) => prev.map((r) => (r.id === roomId ? data.room : r)));
      }
    },
    []
  );

  const saveSettings = useCallback(async (nextSettings: WidgetSettings) => {
    const token = authTokenRef.current;
    if (!token) return false;
    const res = await fetch('/api/settings', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(nextSettings),
    });
    if (res.status === 401) {
      onUnauthorizedRef.current?.();
      return false;
    }
    if (res.ok) {
      const data = (await res.json()) as { settings: WidgetSettings };
      setSettings(data.settings);
      return true;
    }
    return false;
  }, []);

  const deleteMessage = useCallback(async (roomId: string, messageId: string) => {
    const token = authTokenRef.current;
    if (!token) return;
    const res = await fetch(
      `/api/rooms/${encodeURIComponent(roomId)}/messages/${encodeURIComponent(messageId)}`,
      {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    if (res.status === 401) {
      onUnauthorizedRef.current?.();
      return;
    }
    if (res.ok) {
      setMessagesMap((prev) => {
        const list = prev[roomId];
        if (!list) return prev;
        return {
          ...prev,
          [roomId]: list.filter((m) => m.id !== messageId),
        };
      });
    }
  }, []);

  const refreshAnalytics = useCallback(async () => {
    const token = authTokenRef.current;
    if (!token) return;
    const res = await fetch('/api/analytics', {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.status === 401) {
      onUnauthorizedRef.current?.();
      return;
    }
    if (res.ok) {
      const data = (await res.json()) as { analytics: AnalyticsSnapshot };
      setAnalytics(data.analytics);
    }
  }, []);

  const decryptedPreviews = useMemo(() => {
    const map: Record<string, string> = {};
    for (const [rId, list] of Object.entries(messagesMap)) {
      for (let i = list.length - 1; i >= 0; i--) {
        const preview = formatPreviewFromMessage(list[i]);
        if (preview) {
          map[rId] = preview;
          break;
        }
      }
    }
    return map;
  }, [messagesMap]);

  return {
    connected,
    settings,
    rooms,
    activeRoomId,
    selectRoom,
    messages: messagesMap[activeRoomId] ?? [],
    decryptedPreviews,
    loadingMessages,
    typingMap,
    analytics,
    workspaceFingerprint,
    sendAgentMessage,
    deleteMessage,
    emitAgentTyping,
    updateRoomStatus,
    saveSettings,
    refreshAnalytics,
  };
}
