import {
  ArrowDown,
  ArrowUp,
  Camera,
  Check,
  ImagePlus,
  KeyRound,
  ListChecks,
  MessageSquare,
  Minimize2,
  Palette,
  Plus,
  RotateCcw,
  Save,
  Trash2,
  UserCircle2,
  Volume2,
  X,
} from 'lucide-react';
import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { validateAndSanitizeImageFile } from '../lib/imageSecurity';
import { playNotificationSound } from '../lib/soundNotifier';
import type {
  BorderRadiusScale,
  CustomFormField,
  CustomFormFieldType,
  EntranceAnimationStyle,
  LauncherImageShape,
  LogoStyle,
  NotificationSoundPreset,
  SurfaceContrast,
  TypingAnimationStyle,
  WidgetSettings,
} from '../types/chat';
import { BrandLogo } from './BrandLogo';
import { WidgetLauncherButton } from './LiveVisitorWidget';
import { TypingIndicator } from './TypingIndicator';

interface AdminStudioViewProps {
  settings: WidgetSettings;
  onSaveSettings: (next: WidgetSettings) => Promise<boolean>;
  authToken?: string;
  envManaged?: boolean;
  onUnauthorized?: () => void;
}

const ACCENT_PRESETS = [
  { name: 'Emerald', hex: '#10B981' },
  { name: 'Sky', hex: '#38BDF8' },
  { name: 'Amber', hex: '#F59E0B' },
  { name: 'Rose', hex: '#F43F5E' },
  { name: 'Indigo', hex: '#818CF8' },
  { name: 'Pearl', hex: '#E2E8F0' },
];

const SURFACE_MAP: Record<SurfaceContrast, { bg: string; card: string; label: string }> = {
  obsidian: { bg: '#090A0D', card: '#11141B', label: 'Obsidian (#090A0D)' },
  slate: { bg: '#0F172A', card: '#1E293B', label: 'Deep Slate (#0F172A)' },
  midnight: { bg: '#050507', card: '#121217', label: 'Midnight (#050507)' },
};

const RADIUS_PX: Record<BorderRadiusScale, string> = {
  sharp: '6px',
  balanced: '12px',
  soft: '18px',
};

const DEFAULT_AGENT_AVATAR = '/src/assets/images/avatar_admin_agent_1795413952963.jpg';

type StudioTab = 'identity' | 'appearance' | 'messages' | 'prechat';

export function AdminStudioView({
  settings,
  onSaveSettings,
  authToken,
  envManaged = false,
  onUnauthorized,
}: AdminStudioViewProps) {
  const [draft, setDraft] = useState<WidgetSettings>(settings);
  const [studioTab, setStudioTab] = useState<StudioTab>('identity');
  const [saving, setSaving] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);
  const [launcherError, setLauncherError] = useState<string | null>(null);
  const [uploadingLauncher, setUploadingLauncher] = useState(false);
  const [agentAvatarError, setAgentAvatarError] = useState<string | null>(null);
  const [uploadingAgentAvatar, setUploadingAgentAvatar] = useState(false);
  const [agentPreviewImgError, setAgentPreviewImgError] = useState(false);
  const [previewMode, setPreviewMode] = useState<'closed' | 'prechat' | 'chat'>('closed');

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [changingPassword, setChangingPassword] = useState(false);
  const [passwordStatus, setPasswordStatus] = useState<{
    type: 'ok' | 'err';
    text: string;
  } | null>(null);

  const launcherFileRef = useRef<HTMLInputElement | null>(null);
  const agentAvatarFileRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setDraft(settings);
    setAgentPreviewImgError(false);
  }, [settings]);

  useEffect(() => {
    setAgentPreviewImgError(false);
  }, [draft.agentAvatarUrl]);

  const handleSave = async () => {
    setSaving(true);
    setLauncherError(null);
    setAgentAvatarError(null);
    const ok = await onSaveSettings(draft);
    setSaving(false);
    if (ok) {
      setSavedNotice(true);
      window.setTimeout(() => setSavedNotice(false), 2400);
    } else {
      setLauncherError('Gagal menyimpan pengaturan. Pastikan URL atau gambar yang diunggah valid.');
    }
  };

  const handleReset = () => {
    setDraft(settings);
    setLauncherError(null);
    setAgentAvatarError(null);
  };

  const handleLauncherImageUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setLauncherError(null);
    setUploadingLauncher(true);
    try {
      const sanitized = await validateAndSanitizeImageFile(file);
      setDraft((prev) => ({
        ...prev,
        launcherMode: 'image',
        launcherImageUrl: sanitized.dataUrl,
      }));
      setPreviewMode('closed');
    } catch (err) {
      setLauncherError(
        err instanceof Error ? err.message : 'File gambar/GIF launcher ditolak.'
      );
    } finally {
      setUploadingLauncher(false);
    }
  };

  const handleAgentAvatarUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setAgentAvatarError(null);
    setUploadingAgentAvatar(true);
    try {
      const sanitized = await validateAndSanitizeImageFile(file);
      setDraft((prev) => ({
        ...prev,
        agentAvatarUrl: sanitized.dataUrl,
      }));
      setAgentPreviewImgError(false);
      setPreviewMode('chat');
    } catch (err) {
      setAgentAvatarError(
        err instanceof Error ? err.message : 'Foto profil CS ditolak oleh filter keamanan.'
      );
    } finally {
      setUploadingAgentAvatar(false);
    }
  };

  const handleChangePassword = async (e: FormEvent) => {
    e.preventDefault();
    setPasswordStatus(null);
    if (!authToken) {
      setPasswordStatus({ type: 'err', text: 'Sesi login tidak ditemukan.' });
      return;
    }
    if (!currentPassword) {
      setPasswordStatus({ type: 'err', text: 'Masukkan kata sandi saat ini.' });
      return;
    }
    if (newPassword.length < 8) {
      setPasswordStatus({ type: 'err', text: 'Kata sandi baru minimal 8 karakter.' });
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setPasswordStatus({ type: 'err', text: 'Konfirmasi kata sandi baru tidak cocok.' });
      return;
    }

    setChangingPassword(true);
    try {
      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      if (res.status === 401 && res.headers.get('content-type')?.includes('application/json')) {
        const errBody = (await res.json()) as { error?: string };
        if (errBody.error?.includes('Autentikasi admin')) {
          onUnauthorized?.();
          return;
        }
        setPasswordStatus({
          type: 'err',
          text: errBody.error || 'Kata sandi saat ini tidak sesuai.',
        });
        return;
      }
      const data = (await res.json()) as { ok?: boolean; message?: string; error?: string };
      if (!res.ok) {
        setPasswordStatus({
          type: 'err',
          text: data.error || 'Gagal memperbarui kata sandi.',
        });
        return;
      }
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      setPasswordStatus({
        type: 'ok',
        text: data.message || 'Kata sandi admin berhasil diperbarui.',
      });
    } catch {
      setPasswordStatus({ type: 'err', text: 'Gagal menghubungi server.' });
    } finally {
      setChangingPassword(false);
    }
  };

  const addCustomField = (type: CustomFormFieldType = 'text') => {
    const idx = draft.preChatFields.length + 1;
    const isChoice = type === 'select' || type === 'radio';
    const newField: CustomFormField = {
      id: `field_${Date.now().toString(36)}_${idx}`,
      label: isChoice ? `Pilihan Opsi ${idx}` : `Input ${idx}`,
      key: isChoice ? `opsi_${idx}` : `input_${idx}`,
      type,
      placeholder: isChoice ? undefined : 'Ketik jawaban di sini...',
      required: true,
      options: isChoice ? ['Opsi A', 'Opsi B', 'Opsi C'] : undefined,
    };
    setDraft({
      ...draft,
      preChatFormEnabled: true,
      preChatFields: [...draft.preChatFields, newField],
    });
    setPreviewMode('prechat');
  };

  const updateField = (id: string, patch: Partial<CustomFormField>) => {
    setDraft({
      ...draft,
      preChatFields: draft.preChatFields.map((f) => {
        if (f.id !== id) return f;
        const updated = { ...f, ...patch };
        if (patch.label !== undefined && !patch.key) {
          const slug = patch.label
            .toLowerCase()
            .trim()
            .replace(/[^a-z0-9]+/g, '_')
            .replace(/^_|_$/g, '');
          if (slug) updated.key = slug;
        }
        if (
          (patch.type === 'select' || patch.type === 'radio') &&
          (!updated.options || updated.options.length === 0)
        ) {
          updated.options = ['Opsi 1', 'Opsi 2'];
        }
        return updated;
      }),
    });
  };

  const moveField = (index: number, direction: -1 | 1) => {
    const target = index + direction;
    if (target < 0 || target >= draft.preChatFields.length) return;
    const next = [...draft.preChatFields];
    const [item] = next.splice(index, 1);
    next.splice(target, 0, item);
    setDraft({ ...draft, preChatFields: next });
  };

  const removeField = (id: string) => {
    setDraft({
      ...draft,
      preChatFields: draft.preChatFields.filter((f) => f.id !== id),
    });
  };

  const previewSurface = SURFACE_MAP[draft.surfaceContrast];
  const previewRadius = RADIUS_PX[draft.borderRadius];

  return (
    <div className="h-full overflow-y-auto p-6 lg:p-8 bg-[#090A0D]">
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Configuration Controls */}
        <div className="lg:col-span-7 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/[0.08]">
            <div>
              <h1 className="text-lg font-semibold text-slate-100">
                Studio Pengaturan Widget & Tampilan
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                Semua perubahan disiarkan secara real-time ke widget tersemat di situs pihak ketiga.
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleReset}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-white/[0.1] bg-[#12151D] text-xs font-medium text-slate-300 hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
              <button
                type="button"
                onClick={() => void handleSave()}
                disabled={saving}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-slate-950 transition-opacity disabled:opacity-50 whitespace-nowrap shrink-0"
                style={{ backgroundColor: draft.accentColor }}
              >
                {savedNotice ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
                <span>
                  {saving ? 'Menyimpan...' : savedNotice ? 'Tersimpan' : 'Simpan & Terapkan'}
                </span>
              </button>
            </div>
          </div>

          {/* Studio Sub-Navigation Tabs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-1.5 rounded-xl border border-white/[0.08] bg-[#0F1218]">
            {(
              [
                { id: 'identity', label: 'Identitas & Foto', icon: UserCircle2 },
                { id: 'appearance', label: 'Warna & Animasi', icon: Palette },
                { id: 'messages', label: 'Pesan & Notifikasi', icon: MessageSquare },
                {
                  id: 'prechat',
                  label: `Form & Input (${draft.preChatFields.length})`,
                  icon: ListChecks,
                },
              ] as Array<{ id: StudioTab; label: string; icon: typeof UserCircle2 }>
            ).map((tab) => {
              const Icon = tab.icon;
              const active = studioTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setStudioTab(tab.id);
                    if (tab.id === 'prechat') setPreviewMode('prechat');
                    if (tab.id === 'messages') setPreviewMode('chat');
                  }}
                  className={`flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-[#1A1F2B] text-white border border-white/[0.14]'
                      : 'text-slate-400 hover:text-slate-200 border border-transparent'
                  }`}
                >
                  <Icon
                    className="w-3.5 h-3.5 shrink-0"
                    style={active ? { color: draft.accentColor } : undefined}
                  />
                  <span className="truncate">{tab.label}</span>
                </button>
              );
            })}
          </div>

          {studioTab === 'identity' && (
          <div className="space-y-6">
          {/* Section 1: Brand, Agent Photo & Launcher */}
          <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-5">
            <h2 className="text-sm font-semibold text-slate-100">Identitas Brand & Posisi</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5" htmlFor="brand-name-input">
                  Nama Brand / Workspace
                </label>
                <input
                  id="brand-name-input"
                  type="text"
                  value={draft.brandName}
                  onChange={(e) => setDraft({ ...draft, brandName: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 focus:outline-none focus:border-white/25"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5" htmlFor="launcher-pos">
                  Posisi Launcher Widget
                </label>
                <select
                  id="launcher-pos"
                  value={draft.launcherPosition}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      launcherPosition: e.target.value as 'bottom-right' | 'bottom-left',
                    })
                  }
                  className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 focus:outline-none focus:border-white/25"
                >
                  <option value="bottom-right">Kanan Bawah</option>
                  <option value="bottom-left">Kiri Bawah</option>
                </select>
              </div>
            </div>

            <div>
              <span className="block text-xs text-slate-400 mb-2">Gaya Ikon Logo</span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(
                  [
                    { id: 'shield', label: 'Perisai E2EE' },
                    { id: 'waveform', label: 'Gelombang' },
                    { id: 'hexagon', label: 'Heksagon' },
                    { id: 'custom', label: 'URL Kustom' },
                  ] as Array<{ id: LogoStyle; label: string }>
                ).map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setDraft({ ...draft, logoStyle: item.id })}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-medium transition-colors whitespace-nowrap ${
                      draft.logoStyle === item.id
                        ? 'border-white/30 bg-[#1A1F2B] text-white'
                        : 'border-white/[0.07] bg-[#131720] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <BrandLogo
                      logoStyle={item.id}
                      accentColor={draft.accentColor}
                      customLogoUrl={draft.customLogoUrl}
                      size={20}
                    />
                    <span className="truncate">{item.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {draft.logoStyle === 'custom' && (
              <div>
                <label className="block text-xs text-slate-400 mb-1.5" htmlFor="custom-logo-url">
                  URL Gambar Logo (HTTPS)
                </label>
                <input
                  id="custom-logo-url"
                  type="url"
                  value={draft.customLogoUrl}
                  onChange={(e) => setDraft({ ...draft, customLogoUrl: e.target.value })}
                  placeholder="https://domainanda.com/logo.png"
                  className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-white/25"
                />
              </div>
            )}

            {/* Agent / CS Profile Photo & Display Name */}
            <div className="pt-4 border-t border-white/[0.07] space-y-3.5">
              <div>
                <h3 className="text-xs font-semibold text-slate-200">
                  Profil & Foto CS / Admin di Obrolan Livechat
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Foto dan nama ini ditampilkan pada header jendela chat dan di samping pesan balasan ke pengunjung.
                </p>
              </div>

              {agentAvatarError && (
                <div className="px-3 py-2 rounded-lg border border-rose-500/30 bg-rose-500/10 text-xs text-rose-300 flex items-center justify-between gap-2">
                  <span>{agentAvatarError}</span>
                  <button
                    type="button"
                    onClick={() => setAgentAvatarError(null)}
                    aria-label="Tutup pesan error foto CS"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              <div className="flex flex-col sm:flex-row sm:items-center gap-4 p-3.5 rounded-lg border border-white/[0.08] bg-[#12161F]">
                <div className="flex items-center gap-3 shrink-0">
                  {draft.agentAvatarUrl && !agentPreviewImgError ? (
                    <img
                      src={draft.agentAvatarUrl}
                      alt={draft.agentName || 'Foto CS'}
                      referrerPolicy="no-referrer"
                      onError={() => setAgentPreviewImgError(true)}
                      className="w-14 h-14 rounded-full object-cover border border-white/15 bg-black/30"
                    />
                  ) : (
                    <div className="w-14 h-14 rounded-full bg-[#1B202C] border border-white/10 flex items-center justify-center text-slate-400">
                      <UserCircle2 className="w-7 h-7" />
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <input
                      ref={agentAvatarFileRef}
                      type="file"
                      accept="image/png,image/jpeg,image/webp,image/gif"
                      onChange={(e) => void handleAgentAvatarUpload(e)}
                      className="hidden"
                    />
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        disabled={uploadingAgentAvatar}
                        onClick={() => agentAvatarFileRef.current?.click()}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/[0.12] bg-[#181D29] text-xs font-medium text-slate-100 hover:border-white/25 transition-colors"
                      >
                        <Camera className="w-3.5 h-3.5" style={{ color: draft.accentColor }} />
                        <span>
                          {uploadingAgentAvatar ? 'Memvalidasi...' : 'Unggah Foto CS'}
                        </span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setDraft({ ...draft, agentAvatarUrl: DEFAULT_AGENT_AVATAR });
                          setAgentPreviewImgError(false);
                          setPreviewMode('chat');
                        }}
                        className="px-2.5 py-1.5 rounded-lg border border-white/[0.08] bg-[#141821] text-[11px] text-slate-300 hover:text-white transition-colors"
                      >
                        Gunakan Foto Bawaan
                      </button>
                      {draft.agentAvatarUrl && (
                        <button
                          type="button"
                          onClick={() => setDraft({ ...draft, agentAvatarUrl: '' })}
                          className="text-[11px] text-slate-400 hover:text-rose-300 px-1.5 py-1"
                        >
                          Hapus Foto
                        </button>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500">
                      PNG, JPG, WebP, atau GIF tervalidasi ketat (maks 2 MB).
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1" htmlFor="agent-display-name">
                    Nama Tampilan CS / Admin
                  </label>
                  <input
                    id="agent-display-name"
                    type="text"
                    maxLength={60}
                    value={draft.agentName}
                    onChange={(e) => setDraft({ ...draft, agentName: e.target.value })}
                    placeholder="Contoh: Citra Pratama"
                    className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-white/25"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1" htmlFor="agent-avatar-url">
                    Atau Tempel URL Foto CS (HTTPS)
                  </label>
                  <input
                    id="agent-avatar-url"
                    type="url"
                    value={
                      draft.agentAvatarUrl.startsWith('data:')
                        ? ''
                        : draft.agentAvatarUrl
                    }
                    onChange={(e) => {
                      setDraft({ ...draft, agentAvatarUrl: e.target.value });
                      setAgentPreviewImgError(false);
                    }}
                    placeholder="https://domainanda.com/foto-cs.jpg"
                    className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-white/25"
                  />
                </div>
              </div>
            </div>

            {/* Closed Widget Launcher (GIF / Image Mode) */}
            <div className="pt-4 border-t border-white/[0.07] space-y-3.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-xs font-semibold text-slate-200">
                    Tampilan Widget Saat Tertutup (Tombol / GIF Maskot)
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Ganti tombol default dengan gambar atau GIF animasi (misalnya karakter maskot)
                    yang akan membuka obrolan saat diklik.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setDraft({ ...draft, launcherMode: 'button' });
                    setPreviewMode('closed');
                  }}
                  className={`px-3 py-2 rounded-lg border text-xs font-medium transition-colors text-left ${
                    draft.launcherMode === 'button'
                      ? 'border-white/30 bg-[#1A1F2B] text-white'
                      : 'border-white/[0.07] bg-[#131720] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Tombol Ikon Standar
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDraft({ ...draft, launcherMode: 'image' });
                    setPreviewMode('closed');
                  }}
                  className={`px-3 py-2 rounded-lg border text-xs font-medium transition-colors text-left ${
                    draft.launcherMode === 'image'
                      ? 'border-white/30 bg-[#1A1F2B] text-white'
                      : 'border-white/[0.07] bg-[#131720] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Gambar / GIF Kustom
                </button>
              </div>

              {draft.launcherMode === 'image' && (
                <div className="p-3.5 rounded-lg border border-white/[0.08] bg-[#12161F] space-y-3.5">
                  {launcherError && (
                    <div className="px-3 py-2 rounded-lg border border-rose-500/30 bg-rose-500/10 text-xs text-rose-300 flex items-center justify-between gap-2">
                      <span>{launcherError}</span>
                      <button
                        type="button"
                        onClick={() => setLauncherError(null)}
                        aria-label="Tutup pesan error launcher"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  <div className="flex flex-wrap items-center gap-3">
                    <input
                      ref={launcherFileRef}
                      type="file"
                      accept="image/gif,image/png,image/jpeg,image/webp"
                      onChange={(e) => void handleLauncherImageUpload(e)}
                      className="hidden"
                    />
                    <button
                      type="button"
                      disabled={uploadingLauncher}
                      onClick={() => launcherFileRef.current?.click()}
                      className="inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-white/[0.12] bg-[#181D29] text-xs font-medium text-slate-100 hover:border-white/25 transition-colors"
                    >
                      <ImagePlus className="w-4 h-4" style={{ color: draft.accentColor }} />
                      <span>
                        {uploadingLauncher
                          ? 'Memvalidasi GIF/Gambar...'
                          : draft.launcherImageUrl
                            ? 'Ganti File GIF / Gambar'
                            : 'Unggah GIF / Gambar (Maks 2 MB)'}
                      </span>
                    </button>

                    {draft.launcherImageUrl && (
                      <div className="flex items-center gap-2">
                        <img
                          src={draft.launcherImageUrl}
                          alt="Pratinjau launcher"
                          className="w-10 h-10 rounded-lg object-contain bg-black/30 border border-white/10"
                        />
                        <button
                          type="button"
                          onClick={() => setDraft({ ...draft, launcherImageUrl: '' })}
                          className="text-xs text-slate-400 hover:text-rose-300"
                        >
                          Hapus
                        </button>
                      </div>
                    )}
                  </div>

                  <div>
                    <label
                      className="block text-[11px] text-slate-400 mb-1"
                      htmlFor="launcher-img-url"
                    >
                      Atau Tempel URL Gambar / GIF Langsung (HTTPS)
                    </label>
                    <input
                      id="launcher-img-url"
                      type="url"
                      value={
                        draft.launcherImageUrl.startsWith('data:')
                          ? ''
                          : draft.launcherImageUrl
                      }
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          launcherMode: 'image',
                          launcherImageUrl: e.target.value,
                        })
                      }
                      placeholder="https://media.domainanda.com/maskot-livechat.gif"
                      className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#0B0D12] text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-white/25"
                    />
                    <p className="mt-1 text-[11px] text-slate-500">
                      Mendukung file .gif animasi, .png, .webp, dan .jpg (untuk sumber .gifv, simpan/ekspor sebagai .gif agar animasi berjalan langsung tanpa blokir keamanan).
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <span className="block text-[11px] text-slate-400 mb-1.5">
                        Bentuk Bingkai Launcher
                      </span>
                      <div className="grid grid-cols-3 gap-1.5">
                        {(
                          [
                            { id: 'floating', label: 'Melayang' },
                            { id: 'circle', label: 'Lingkaran' },
                            { id: 'rounded', label: 'Kotak' },
                          ] as Array<{ id: LauncherImageShape; label: string }>
                        ).map((shape) => (
                          <button
                            key={shape.id}
                            type="button"
                            onClick={() =>
                              setDraft({ ...draft, launcherImageShape: shape.id })
                            }
                            className={`px-2 py-1.5 rounded border text-[11px] font-medium transition-colors ${
                              draft.launcherImageShape === shape.id
                                ? 'border-white/30 bg-[#1B202C] text-white'
                                : 'border-white/[0.07] bg-[#0B0D12] text-slate-400'
                            }`}
                          >
                            {shape.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
                        <span>Ukuran Gambar</span>
                        <span className="font-mono text-slate-200">
                          {draft.launcherImageSize}px
                        </span>
                      </div>
                      <input
                        type="range"
                        min={52}
                        max={116}
                        step={4}
                        value={draft.launcherImageSize}
                        onChange={(e) =>
                          setDraft({
                            ...draft,
                            launcherImageSize: Number(e.target.value),
                          })
                        }
                        className="w-full accent-emerald-400 cursor-pointer"
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      className="block text-[11px] text-slate-400 mb-1"
                      htmlFor="launcher-bubble-text"
                    >
                      Teks Balon Sapaan di Samping GIF (Opsional)
                    </label>
                    <input
                      id="launcher-bubble-text"
                      type="text"
                      maxLength={60}
                      value={draft.launcherBubbleText}
                      onChange={(e) =>
                        setDraft({ ...draft, launcherBubbleText: e.target.value })
                      }
                      placeholder="Contoh: Butuh bantuan? Klik saya!"
                      className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#0B0D12] text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-white/25"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {authToken && (
            <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-4">
              <div className="flex items-start gap-2.5">
                <KeyRound className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h2 className="text-sm font-semibold text-slate-100">
                    Ubah Kata Sandi Login Dashboard
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {envManaged
                      ? 'Kata sandi saat ini dikelola via variabel server ADMIN_PASSCODE di file .env / Secrets.'
                      : 'Perbarui kata sandi akun admin Anda (minimal 8 karakter, misalnya kombinasi angka atau huruf).'}
                  </p>
                </div>
              </div>

              {passwordStatus && (
                <div
                  className={`px-3 py-2 rounded-lg border text-xs ${
                    passwordStatus.type === 'ok'
                      ? 'border-emerald-500/35 bg-emerald-500/10 text-emerald-200'
                      : 'border-rose-500/35 bg-rose-500/10 text-rose-200'
                  }`}
                >
                  {passwordStatus.text}
                </div>
              )}

              {!envManaged && (
                <form onSubmit={(e) => void handleChangePassword(e)} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1" htmlFor="curr-pass">
                        Kata Sandi Saat Ini
                      </label>
                      <input
                        id="curr-pass"
                        type="password"
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        placeholder="Sandi sekarang"
                        className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-white/25"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1" htmlFor="new-pass">
                        Kata Sandi Baru (Min. 8)
                      </label>
                      <input
                        id="new-pass"
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Minimal 8 karakter"
                        className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-white/25"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1" htmlFor="confirm-new-pass">
                        Ulangi Sandi Baru
                      </label>
                      <input
                        id="confirm-new-pass"
                        type="password"
                        value={confirmNewPassword}
                        onChange={(e) => setConfirmNewPassword(e.target.value)}
                        placeholder="Ketik ulang sandi"
                        className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-white/25"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={changingPassword}
                      className="px-4 py-2 rounded-lg border border-white/[0.12] bg-[#181D29] hover:border-white/25 text-xs font-medium text-slate-100 transition-colors disabled:opacity-50 whitespace-nowrap"
                    >
                      {changingPassword ? 'Menyimpan...' : 'Simpan Kata Sandi Baru'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}
          </div>
          )}

          {studioTab === 'appearance' && (
          <div className="space-y-6">
          {/* Section 2: Colors & Surface */}
          <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-4">
            <h2 className="text-sm font-semibold text-slate-100">Warna, Kontras & Radius</h2>

            <div>
              <span className="block text-xs text-slate-400 mb-2">Warna Aksen Utama</span>
              <div className="flex flex-wrap items-center gap-2">
                {ACCENT_PRESETS.map((preset) => (
                  <button
                    key={preset.hex}
                    type="button"
                    onClick={() => setDraft({ ...draft, accentColor: preset.hex })}
                    className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs transition-colors ${
                      draft.accentColor.toLowerCase() === preset.hex.toLowerCase()
                        ? 'border-white/35 bg-[#1B202C] text-white'
                        : 'border-white/[0.07] bg-[#131720] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span
                      className="w-3 h-3 rounded-full shrink-0"
                      style={{ backgroundColor: preset.hex }}
                    />
                    <span>{preset.name}</span>
                  </button>
                ))}
                <label className="inline-flex items-center gap-2 px-2.5 py-1.5 rounded-lg border border-white/[0.08] bg-[#131720] text-xs text-slate-300 cursor-pointer">
                  <input
                    type="color"
                    value={draft.accentColor}
                    onChange={(e) => setDraft({ ...draft, accentColor: e.target.value })}
                    className="w-4 h-4 bg-transparent border-0 cursor-pointer"
                    aria-label="Pilih warna aksen kustom"
                  />
                  <span className="font-mono">{draft.accentColor.toUpperCase()}</span>
                </label>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <span className="block text-xs text-slate-400 mb-2">Permukaan Mode Gelap</span>
                <div className="space-y-1.5">
                  {(['obsidian', 'slate', 'midnight'] as SurfaceContrast[]).map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setDraft({ ...draft, surfaceContrast: s })}
                      className={`w-full text-left px-3 py-2 rounded-lg border text-xs transition-colors ${
                        draft.surfaceContrast === s
                          ? 'border-white/30 bg-[#1A1F2B] text-white'
                          : 'border-white/[0.06] bg-[#131720] text-slate-400'
                      }`}
                    >
                      {SURFACE_MAP[s].label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="block text-xs text-slate-400 mb-2">Kelengkungan Sudut</span>
                <div className="space-y-1.5">
                  {(
                    [
                      { id: 'sharp', label: 'Tajam (6px)' },
                      { id: 'balanced', label: 'Seimbang (12px)' },
                      { id: 'soft', label: 'Halus (18px)' },
                    ] as Array<{ id: BorderRadiusScale; label: string }>
                  ).map((r) => (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => setDraft({ ...draft, borderRadius: r.id })}
                      className={`w-full text-left px-3 py-2 rounded-lg border text-xs transition-colors ${
                        draft.borderRadius === r.id
                          ? 'border-white/30 bg-[#1A1F2B] text-white'
                          : 'border-white/[0.06] bg-[#131720] text-slate-400'
                      }`}
                    >
                      {r.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Animations & Typing Status */}
          <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-4">
            <h2 className="text-sm font-semibold text-slate-100">
              Animasi & Indikator Pengetikan
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <span className="block text-xs text-slate-400 mb-2">
                  Gaya Indikator Pengetikan
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {(
                    [
                      { id: 'wave', label: 'Gelombang' },
                      { id: 'pulse-bar', label: 'Spektrum Bar' },
                      { id: 'dots', label: 'Denyut Halus' },
                      { id: 'minimal', label: 'Kursor Teks' },
                    ] as Array<{ id: TypingAnimationStyle; label: string }>
                  ).map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setDraft({ ...draft, typingAnimation: t.id })}
                      className={`px-3 py-2 rounded-lg border text-xs font-medium transition-colors text-left ${
                        draft.typingAnimation === t.id
                          ? 'border-white/30 bg-[#1A1F2B] text-white'
                          : 'border-white/[0.06] bg-[#131720] text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="block text-xs text-slate-400 mb-2">
                  Transisi Pembukaan Widget
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { id: 'spring', label: 'Spring' },
                      { id: 'slide', label: 'Slide' },
                      { id: 'fade', label: 'Fade' },
                    ] as Array<{ id: EntranceAnimationStyle; label: string }>
                  ).map((anim) => (
                    <button
                      key={anim.id}
                      type="button"
                      onClick={() => setDraft({ ...draft, entranceAnimation: anim.id })}
                      className={`px-3 py-2 rounded-lg border text-xs font-medium transition-colors text-center ${
                        draft.entranceAnimation === anim.id
                          ? 'border-white/30 bg-[#1A1F2B] text-white'
                          : 'border-white/[0.06] bg-[#131720] text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {anim.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
          </div>
          )}

          {studioTab === 'messages' && (
          <div className="space-y-6">
          {/* Section 4: Messaging & Privacy */}
          <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-4">
            <h2 className="text-sm font-semibold text-slate-100">
              Pengaturan Pesan & Privasi E2EE
            </h2>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5" htmlFor="welcome-msg">
                Pesan Sambutan Otomatis
              </label>
              <textarea
                id="welcome-msg"
                rows={2}
                value={draft.welcomeMessage}
                onChange={(e) => setDraft({ ...draft, welcomeMessage: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 focus:outline-none focus:border-white/25"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5" htmlFor="placeholder-msg">
                  Placeholder Kolom Input
                </label>
                <input
                  id="placeholder-msg"
                  type="text"
                  value={draft.inputPlaceholder}
                  onChange={(e) => setDraft({ ...draft, inputPlaceholder: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 focus:outline-none focus:border-white/25"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1.5" htmlFor="offline-msg">
                  Pesan Saat Operator Offline
                </label>
                <input
                  id="offline-msg"
                  type="text"
                  value={draft.offlineMessage}
                  onChange={(e) => setDraft({ ...draft, offlineMessage: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 focus:outline-none focus:border-white/25"
                />
              </div>
            </div>

            <div className="pt-2 flex flex-wrap gap-6">
              <label className="inline-flex items-center gap-2.5 cursor-pointer text-xs text-slate-200">
                <input
                  type="checkbox"
                  checked={draft.enforceE2EE}
                  onChange={(e) => setDraft({ ...draft, enforceE2EE: e.target.checked })}
                  className="w-4 h-4 rounded border-white/20 bg-[#141821]"
                />
                <span>Wajibkan Enkripsi End-to-End (ECDH + AES-256-GCM)</span>
              </label>

              <label className="inline-flex items-center gap-2.5 cursor-pointer text-xs text-slate-200">
                <input
                  type="checkbox"
                  checked={draft.showReadReceipts}
                  onChange={(e) => setDraft({ ...draft, showReadReceipts: e.target.checked })}
                  className="w-4 h-4 rounded border-white/20 bg-[#141821]"
                />
                <span>Tampilkan Status Pesan Dibaca</span>
              </label>
            </div>
          </div>

          {/* Sound Notification Settings */}
          <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-100">
                  Notifikasi Suara Pesan Masuk
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Putar efek suara notifikasi saat pesan baru diterima di panel admin maupun widget pengunjung.
                </p>
              </div>
              <button
                type="button"
                onClick={() => void playNotificationSound(draft.soundPreset, draft.soundVolume)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/[0.12] bg-[#181D29] text-xs font-medium text-slate-100 hover:border-white/25 transition-colors whitespace-nowrap shrink-0"
              >
                <Volume2 className="w-3.5 h-3.5" style={{ color: draft.accentColor }} />
                <span>Tes Suara Notif</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="flex items-start gap-2.5 p-3 rounded-lg border border-white/[0.08] bg-[#131720] cursor-pointer">
                <input
                  type="checkbox"
                  checked={draft.adminSoundEnabled}
                  onChange={(e) => setDraft({ ...draft, adminSoundEnabled: e.target.checked })}
                  className="mt-0.5 w-4 h-4 rounded border-white/20 bg-[#141821] shrink-0"
                />
                <div>
                  <div className="text-xs font-medium text-slate-100">
                    Suara di Dashboard Admin (Live Inbox)
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Berbunyi otomatis saat ada pesan masuk dari pengunjung.
                  </div>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-3 rounded-lg border border-white/[0.08] bg-[#131720] cursor-pointer">
                <input
                  type="checkbox"
                  checked={draft.widgetSoundEnabled}
                  onChange={(e) => setDraft({ ...draft, widgetSoundEnabled: e.target.checked })}
                  className="mt-0.5 w-4 h-4 rounded border-white/20 bg-[#141821] shrink-0"
                />
                <div>
                  <div className="text-xs font-medium text-slate-100">
                    Suara di Widget Livechat Pengunjung
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Berbunyi di browser pengunjung saat menerima balasan CS.
                  </div>
                </div>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <div>
                <span className="block text-xs text-slate-400 mb-2">
                  Pilihan Nada Notifikasi
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {(
                    [
                      { id: 'chime', label: 'Chime Lembut' },
                      { id: 'pop', label: 'Pop Gelembung' },
                      { id: 'bell', label: 'Bell Resepsionis' },
                      { id: 'subtle', label: 'Subtle Minimal' },
                    ] as Array<{ id: NotificationSoundPreset; label: string }>
                  ).map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        setDraft({ ...draft, soundPreset: preset.id });
                        void playNotificationSound(preset.id, draft.soundVolume);
                      }}
                      className={`px-3 py-2 rounded-lg border text-xs font-medium transition-colors text-left whitespace-nowrap ${
                        draft.soundPreset === preset.id
                          ? 'border-white/30 bg-[#1A1F2B] text-white'
                          : 'border-white/[0.06] bg-[#131720] text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                  <span>Volume Suara Notifikasi</span>
                  <span className="font-mono tabular-nums text-slate-200">
                    {draft.soundVolume}%
                  </span>
                </div>
                <div className="p-3 rounded-lg border border-white/[0.07] bg-[#131720] space-y-2">
                  <input
                    type="range"
                    min={10}
                    max={100}
                    step={5}
                    value={draft.soundVolume}
                    onChange={(e) =>
                      setDraft({ ...draft, soundVolume: Number(e.target.value) })
                    }
                    className="w-full accent-emerald-400 cursor-pointer"
                    aria-label="Volume suara notifikasi"
                  />
                  <div className="flex justify-between text-[11px] font-mono tabular-nums text-slate-500">
                    <span>10%</span>
                    <span>50%</span>
                    <span>100%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </div>
          )}

          {studioTab === 'prechat' && (
          /* Section 5: Pre-Chat Custom Form Builder */
          <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-100">
                  Formulir Pra-Chat & Elemen Input Kustom
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Tambahkan elemen input (misalnya Username, Email, Dropdown, atau Pilihan Opsi)
                  saat pengunjung pertama kali membuka widget.
                </p>
              </div>
              <label className="inline-flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-200 shrink-0">
                <input
                  type="checkbox"
                  checked={draft.preChatFormEnabled}
                  onChange={(e) => {
                    setDraft({ ...draft, preChatFormEnabled: e.target.checked });
                    if (e.target.checked) setPreviewMode('prechat');
                  }}
                  className="w-4 h-4 rounded border-white/20 bg-[#141821]"
                />
                <span>Aktifkan Formulir</span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1" htmlFor="prechat-title">
                  Judul Formulir
                </label>
                <input
                  id="prechat-title"
                  type="text"
                  value={draft.preChatFormTitle}
                  onChange={(e) => setDraft({ ...draft, preChatFormTitle: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 focus:outline-none focus:border-white/25"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1" htmlFor="prechat-submit">
                  Teks Tombol Mulai
                </label>
                <input
                  id="prechat-submit"
                  type="text"
                  value={draft.preChatSubmitLabel}
                  onChange={(e) => setDraft({ ...draft, preChatSubmitLabel: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 focus:outline-none focus:border-white/25"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1" htmlFor="prechat-desc">
                Deskripsi Singkat
              </label>
              <input
                id="prechat-desc"
                type="text"
                value={draft.preChatFormDescription}
                onChange={(e) => setDraft({ ...draft, preChatFormDescription: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 focus:outline-none focus:border-white/25"
              />
            </div>

            {/* Dynamic Field List */}
            <div className="space-y-3 pt-1">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-medium text-slate-300">
                  Daftar Elemen Input ({draft.preChatFields.length})
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => addCustomField('text')}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-white/[0.1] bg-[#141821] text-xs font-medium text-slate-200 hover:bg-[#1B202C] transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Input Teks</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => addCustomField('radio')}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-white/[0.1] bg-[#141821] text-xs font-medium text-slate-200 hover:bg-[#1B202C] transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Pilihan Opsi</span>
                  </button>
                </div>
              </div>

              {draft.preChatFields.length === 0 ? (
                <div className="p-4 rounded-lg border border-dashed border-white/[0.1] text-center text-xs text-slate-500">
                  Belum ada elemen input. Tambahkan Input Teks (seperti Username) atau Pilihan Opsi.
                </div>
              ) : (
                <div className="space-y-3">
                  {draft.preChatFields.map((field, index) => {
                    const hasOptions = field.type === 'select' || field.type === 'radio';
                    return (
                      <div
                        key={field.id}
                        className="p-3.5 rounded-lg border border-white/[0.08] bg-[#12161F] space-y-3"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="text-[11px] font-mono text-slate-400">
                            Elemen #{index + 1} · key: {field.key}
                          </span>
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => moveField(index, -1)}
                              disabled={index === 0}
                              aria-label="Naikkan urutan"
                              className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-30"
                            >
                              <ArrowUp className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => moveField(index, 1)}
                              disabled={index === draft.preChatFields.length - 1}
                              aria-label="Turunkan urutan"
                              className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-30"
                            >
                              <ArrowDown className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => removeField(field.id)}
                              aria-label={`Hapus elemen ${field.label}`}
                              className="p-1 rounded text-slate-400 hover:text-rose-400"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                          <div>
                            <label className="block text-[11px] text-slate-400 mb-1">
                              Label Input
                            </label>
                            <input
                              type="text"
                              value={field.label}
                              onChange={(e) => updateField(field.id, { label: e.target.value })}
                              className="w-full px-2.5 py-1.5 rounded border border-white/[0.08] bg-[#0B0D12] text-xs text-slate-100"
                            />
                          </div>

                          <div>
                            <label className="block text-[11px] text-slate-400 mb-1">
                              Tipe Elemen
                            </label>
                            <select
                              value={field.type}
                              onChange={(e) =>
                                updateField(field.id, {
                                  type: e.target.value as CustomFormFieldType,
                                })
                              }
                              className="w-full px-2.5 py-1.5 rounded border border-white/[0.08] bg-[#0B0D12] text-xs text-slate-100"
                            >
                              <option value="text">Input Teks (Username/Nama)</option>
                              <option value="email">Input Email</option>
                              <option value="number">Input Angka</option>
                              <option value="textarea">Area Teks Panjang</option>
                              <option value="radio">Pilihan Opsi (Tombol Radio)</option>
                              <option value="select">Dropdown Pilihan (Select)</option>
                            </select>
                          </div>

                          {!hasOptions ? (
                            <div>
                              <label className="block text-[11px] text-slate-400 mb-1">
                                Placeholder
                              </label>
                              <input
                                type="text"
                                value={field.placeholder ?? ''}
                                onChange={(e) =>
                                  updateField(field.id, { placeholder: e.target.value })
                                }
                                placeholder="Contoh: Masukkan username..."
                                className="w-full px-2.5 py-1.5 rounded border border-white/[0.08] bg-[#0B0D12] text-xs text-slate-100"
                              />
                            </div>
                          ) : (
                            <div className="flex items-end pb-1">
                              <label className="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                                <input
                                  type="checkbox"
                                  checked={field.required}
                                  onChange={(e) =>
                                    updateField(field.id, { required: e.target.checked })
                                  }
                                  className="w-3.5 h-3.5 rounded border-white/20 bg-[#0B0D12]"
                                />
                                <span>Wajib dipilih</span>
                              </label>
                            </div>
                          )}
                        </div>

                        {!hasOptions && (
                          <div className="flex items-center justify-between">
                            <label className="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                              <input
                                type="checkbox"
                                checked={field.required}
                                onChange={(e) =>
                                  updateField(field.id, { required: e.target.checked })
                                }
                                className="w-3.5 h-3.5 rounded border-white/20 bg-[#0B0D12]"
                              />
                              <span>Wajib diisi sebelum obrolan dimulai</span>
                            </label>
                          </div>
                        )}

                        {hasOptions && (
                          <div className="pt-2 border-t border-white/[0.06] space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-[11px] text-slate-400">
                                Daftar Pilihan Opsi
                              </span>
                              <button
                                type="button"
                                onClick={() => {
                                  const curr = field.options ?? [];
                                  updateField(field.id, {
                                    options: [...curr, `Opsi ${curr.length + 1}`],
                                  });
                                }}
                                className="text-[11px] font-medium hover:underline"
                                style={{ color: draft.accentColor }}
                              >
                                + Tambah Opsi
                              </button>
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {(field.options ?? []).map((opt, optIdx) => (
                                <div key={optIdx} className="flex items-center gap-1.5">
                                  <input
                                    type="text"
                                    value={opt}
                                    onChange={(e) => {
                                      const nextOpts = [...(field.options ?? [])];
                                      nextOpts[optIdx] = e.target.value;
                                      updateField(field.id, { options: nextOpts });
                                    }}
                                    className="flex-1 px-2.5 py-1 rounded border border-white/[0.08] bg-[#0B0D12] text-xs text-slate-100"
                                  />
                                  <button
                                    type="button"
                                    disabled={(field.options?.length ?? 0) <= 1}
                                    onClick={() => {
                                      const nextOpts = (field.options ?? []).filter(
                                        (_, i) => i !== optIdx
                                      );
                                      updateField(field.id, { options: nextOpts });
                                    }}
                                    aria-label="Hapus opsi"
                                    className="p-1 text-slate-500 hover:text-rose-400 disabled:opacity-30"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
          )}
        </div>

        {/* Right: Live Widget Preview */}
        <div className="lg:col-span-5 lg:sticky lg:top-6 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
            <span className="font-medium text-slate-300">Pratinjau Langsung Widget</span>
            <div className="flex items-center gap-1 p-0.5 rounded-lg bg-[#12151D] border border-white/[0.08]">
              <button
                type="button"
                onClick={() => setPreviewMode('closed')}
                className={`px-2 py-1 rounded-md text-[11px] font-medium transition-colors whitespace-nowrap ${
                  previewMode === 'closed'
                    ? 'bg-[#1D222E] text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Saat Tertutup
              </button>
              <button
                type="button"
                onClick={() => setPreviewMode('prechat')}
                className={`px-2 py-1 rounded-md text-[11px] font-medium transition-colors whitespace-nowrap ${
                  previewMode === 'prechat'
                    ? 'bg-[#1D222E] text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Formulir Pra-Chat
              </button>
              <button
                type="button"
                onClick={() => setPreviewMode('chat')}
                className={`px-2 py-1 rounded-md text-[11px] font-medium transition-colors whitespace-nowrap ${
                  previewMode === 'chat'
                    ? 'bg-[#1D222E] text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Obrolan
              </button>
            </div>
          </div>

          {previewMode === 'closed' ? (
            <div className="relative h-[420px] rounded-xl border border-white/[0.1] bg-[#0B0E14] overflow-hidden shadow-2xl p-5 flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-white/15" />
                  <span className="w-2.5 h-2.5 rounded-full bg-white/15" />
                  <span className="w-2.5 h-2.5 rounded-full bg-white/15" />
                  <span className="ml-2 text-[11px] font-mono text-slate-500">
                    Simulasi Halaman Website Pengunjung
                  </span>
                </div>
                <div className="h-3 w-2/3 rounded bg-white/[0.04]" />
                <div className="h-3 w-1/2 rounded bg-white/[0.03]" />
              </div>

              <div className="text-center px-4">
                <p className="text-xs text-slate-400">
                  Klik launcher {draft.launcherMode === 'image' ? 'gambar / GIF' : 'tombol'} di
                  sudut bawah untuk menguji animasi pembukaan livechat.
                </p>
              </div>

              <div
                className={`flex ${
                  draft.launcherPosition === 'bottom-left' ? 'justify-start' : 'justify-end'
                }`}
              >
                <WidgetLauncherButton
                  settings={draft}
                  onClick={() =>
                    setPreviewMode(draft.preChatFormEnabled ? 'prechat' : 'chat')
                  }
                />
              </div>
            </div>
          ) : (
            <div
              className="border border-white/[0.1] overflow-hidden shadow-2xl"
              style={{
                backgroundColor: previewSurface.bg,
                borderRadius: previewRadius,
              }}
            >
              {/* Preview Header */}
              <div
                className="px-4 py-3.5 border-b border-white/[0.08] flex items-center justify-between"
                style={{ backgroundColor: previewSurface.card }}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  {draft.agentAvatarUrl && !agentPreviewImgError ? (
                    <div className="relative shrink-0">
                      <img
                        src={draft.agentAvatarUrl}
                        alt={draft.agentName || draft.brandName}
                        referrerPolicy="no-referrer"
                        onError={() => setAgentPreviewImgError(true)}
                        className="w-9 h-9 rounded-full object-cover border border-white/15"
                      />
                      <span
                        className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2"
                        style={{ borderColor: previewSurface.card }}
                      />
                    </div>
                  ) : (
                    <BrandLogo
                      logoStyle={draft.logoStyle}
                      accentColor={draft.accentColor}
                      customLogoUrl={draft.customLogoUrl}
                      brandName={draft.brandName}
                      size={30}
                    />
                  )}
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-slate-100 truncate">
                      {draft.brandName || 'SandiChat'}
                    </div>
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                      <span className="truncate">
                        {draft.agentName || 'Tim Support'} · Online
                      </span>
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setPreviewMode('closed')}
                  title="Perkecil ke tampilan launcher"
                  aria-label="Perkecil ke tampilan launcher"
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/[0.08] transition-colors"
                >
                  <Minimize2 className="w-4 h-4" />
                </button>
              </div>

            {previewMode === 'prechat' ? (
              !draft.preChatFormEnabled ? (
                <div className="p-6 min-h-[320px] flex flex-col items-center justify-center text-center space-y-3">
                  <p className="text-xs text-slate-400 max-w-[260px] leading-relaxed">
                    Formulir pra-chat saat ini sedang dinonaktifkan sehingga pengunjung langsung masuk ke obrolan.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setDraft({ ...draft, preChatFormEnabled: true });
                      setStudioTab('prechat');
                    }}
                    className="px-3.5 py-2 text-xs font-semibold text-slate-950 transition-opacity hover:opacity-90"
                    style={{
                      backgroundColor: draft.accentColor,
                      borderRadius: previewRadius,
                    }}
                  >
                    Aktifkan Formulir Pra-Chat
                  </button>
                </div>
              ) : (
                <div className="p-4 space-y-3.5 min-h-[320px]">
                  <div>
                    <div className="text-sm font-semibold text-slate-100">
                      {draft.preChatFormTitle || 'Mulai Percakapan'}
                    </div>
                    {draft.preChatFormDescription && (
                      <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                        {draft.preChatFormDescription}
                      </p>
                    )}
                  </div>

                  {draft.preChatFields.length === 0 ? (
                    <div className="p-4 rounded-lg border border-dashed border-white/[0.12] text-center text-xs text-slate-500">
                      Belum ada elemen input di formulir. Tambahkan melalui tombol + Input Teks atau + Pilihan Opsi di panel kiri.
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {draft.preChatFields.map((field) => (
                        <div key={field.id} className="space-y-1.5">
                          <div className="text-[11px] font-medium text-slate-300">
                            {field.label}
                            {field.required && <span className="text-rose-400 ml-0.5">*</span>}
                          </div>

                          {field.type === 'radio' ? (
                            <div className="space-y-1.5">
                              {(field.options ?? []).map((opt, idx) => (
                                <div
                                  key={idx}
                                  className="px-3 py-2 border text-xs flex items-center gap-2"
                                  style={{
                                    backgroundColor:
                                      idx === 0 ? `${draft.accentColor}16` : previewSurface.card,
                                    borderColor:
                                      idx === 0 ? `${draft.accentColor}66` : 'rgba(255,255,255,0.08)',
                                    borderRadius: previewRadius,
                                  }}
                                >
                                  <span
                                    className="w-3 h-3 rounded-full border flex items-center justify-center shrink-0"
                                    style={{
                                      borderColor:
                                        idx === 0 ? draft.accentColor : 'rgba(255,255,255,0.25)',
                                    }}
                                  >
                                    {idx === 0 && (
                                      <span
                                        className="w-1.5 h-1.5 rounded-full"
                                        style={{ backgroundColor: draft.accentColor }}
                                      />
                                    )}
                                  </span>
                                  <span className="text-slate-200">{opt}</span>
                                </div>
                              ))}
                            </div>
                          ) : field.type === 'select' ? (
                            <div
                              className="px-3 py-2 border border-white/[0.1] text-xs text-slate-300 flex items-center justify-between"
                              style={{
                                backgroundColor: previewSurface.card,
                                borderRadius: previewRadius,
                              }}
                            >
                              <span>{field.options?.[0] ?? 'Pilih opsi...'}</span>
                              <span className="text-slate-500">▾</span>
                            </div>
                          ) : field.type === 'textarea' ? (
                            <div
                              className="px-3 py-2 border border-white/[0.1] text-xs text-slate-500 h-14"
                              style={{
                                backgroundColor: previewSurface.card,
                                borderRadius: previewRadius,
                              }}
                            >
                              {field.placeholder || 'Ketik jawaban...'}
                            </div>
                          ) : (
                            <div
                              className="px-3 py-2 border border-white/[0.1] text-xs text-slate-500"
                              style={{
                                backgroundColor: previewSurface.card,
                                borderRadius: previewRadius,
                              }}
                            >
                              {field.placeholder || `Masukkan ${field.label.toLowerCase()}...`}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  <button
                    type="button"
                    disabled
                    className="w-full py-2.5 text-xs font-semibold text-slate-950"
                    style={{
                      backgroundColor: draft.accentColor,
                      borderRadius: previewRadius,
                    }}
                  >
                    {draft.preChatSubmitLabel || 'Mulai Obrolan'}
                  </button>
                </div>
              )
            ) : (
              <>
                {/* Preview Messages */}
                <div className="p-4 space-y-3.5 min-h-[260px]">
                  <div className="flex items-end gap-2 max-w-[90%]">
                    {draft.agentAvatarUrl && !agentPreviewImgError && (
                      <img
                        src={draft.agentAvatarUrl}
                        alt={draft.agentName || 'CS'}
                        referrerPolicy="no-referrer"
                        className="w-6 h-6 rounded-full object-cover border border-white/10 shrink-0 mb-0.5"
                      />
                    )}
                    <div
                      className="p-3 border border-white/[0.07] text-xs text-slate-200 leading-relaxed"
                      style={{
                        backgroundColor: previewSurface.card,
                        borderRadius: previewRadius,
                      }}
                    >
                      {draft.welcomeMessage}
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <div
                      className="p-3 border text-xs text-slate-100 max-w-[82%]"
                      style={{
                        backgroundColor: `${draft.accentColor}1E`,
                        borderColor: `${draft.accentColor}44`,
                        borderRadius: previewRadius,
                      }}
                    >
                      Halo, apakah bisa bantu cek pesanan saya?
                    </div>
                  </div>

                  <div className="pt-1">
                    <TypingIndicator
                      style={draft.typingAnimation}
                      accentColor={draft.accentColor}
                      senderName={draft.agentName || 'Citra Pratama'}
                    />
                  </div>
                </div>

                {/* Preview Composer */}
                <div
                  className="p-3 border-t border-white/[0.08] flex items-center gap-2"
                  style={{ backgroundColor: previewSurface.card }}
                >
                  <div
                    className="flex-1 px-3 py-2 border border-white/[0.08] text-xs text-slate-500 truncate"
                    style={{
                      backgroundColor: previewSurface.bg,
                      borderRadius: previewRadius,
                    }}
                  >
                    {draft.inputPlaceholder}
                  </div>
                  <button
                    type="button"
                    disabled
                    className="px-3.5 py-2 text-xs font-semibold text-slate-950 shrink-0"
                    style={{
                      backgroundColor: draft.accentColor,
                      borderRadius: previewRadius,
                    }}
                  >
                    Kirim
                  </button>
                </div>
              </>
            )}
          </div>
          )}
        </div>
      </div>
    </div>
  );
}
