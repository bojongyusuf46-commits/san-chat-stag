import { ChevronLeft, ChevronRight, ImagePlus, Minimize2, RotateCcw, Send, X } from 'lucide-react';
import { motion } from 'motion/react';
import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import {
  decryptWithAESGCM,
  deriveSharedAESKey,
  encryptWithAESGCM,
  getOrCreateVisitorIdentity,
  importPublicKeyJWK,
  type StoredIdentity,
} from '../lib/crypto';
import { MAX_CHAT_IMAGES, validateMultipleImageFiles } from '../lib/imageSecurity';
import { decodeChatPayload, encodeChatPayload } from '../lib/payloadCodec';
import { installAudioUnlockListeners, playNotificationSound } from '../lib/soundNotifier';
import type { ChatMessage, ImageAttachment, TypingState, WidgetSettings } from '../types/chat';
import { BrandLogo } from './BrandLogo';
import { TypingIndicator } from './TypingIndicator';

interface LiveVisitorWidgetProps {
  open: boolean;
  onClose: () => void;
  settings: WidgetSettings;
  onSettingsUpdated?: (next: WidgetSettings) => void;
  onOpenRoomInInbox?: (roomId: string) => void;
  embedded?: boolean;
}

interface WidgetMessage extends ChatMessage {
  displayText: string;
  displayAttachments: ImageAttachment[];
}

const SURFACE_STYLE = {
  obsidian: { bg: '#0A0C10', card: '#13161E' },
  slate: { bg: '#0F172A', card: '#1E293B' },
  midnight: { bg: '#050507', card: '#121218' },
};

const RADIUS_STYLE = {
  sharp: '6px',
  balanced: '12px',
  soft: '18px',
};

function createVisitorRoomId(): string {
  const uniquePart =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID().slice(0, 12)
      : `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  return `room-${uniquePart}`;
}

export function LiveVisitorWidget({
  open,
  onClose,
  settings,
  onSettingsUpdated,
  onOpenRoomInInbox,
  embedded = false,
}: LiveVisitorWidgetProps) {
  const [roomId, setRoomId] = useState<string>(() => {
    const saved = sessionStorage.getItem('sandichat_widget_room_id');
    if (saved) return saved;
    const created = createVisitorRoomId();
    sessionStorage.setItem('sandichat_widget_room_id', created);
    return created;
  });

  const [messages, setMessages] = useState<WidgetMessage[]>([]);
  const [draft, setDraft] = useState('');
  const [agentTyping, setAgentTyping] = useState<TypingState | null>(null);
  const [connected, setConnected] = useState(false);
  const [agentAvatarError, setAgentAvatarError] = useState(false);
  const [pendingImages, setPendingImages] = useState<ImageAttachment[]>([]);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [validatingImage, setValidatingImage] = useState(false);
  const [lightboxGallery, setLightboxGallery] = useState<{
    images: ImageAttachment[];
    index: number;
  } | null>(null);

  const [preChatSubmitted, setPreChatSubmitted] = useState<boolean>(() => {
    return Boolean(sessionStorage.getItem(`sandichat_prechat_${roomId}`));
  });
  const [preChatValues, setPreChatValues] = useState<Record<string, string>>(() => {
    try {
      const saved = sessionStorage.getItem(`sandichat_prechat_${roomId}`);
      return saved ? (JSON.parse(saved) as Record<string, string>) : {};
    } catch {
      return {};
    }
  });
  const [preChatError, setPreChatError] = useState<string | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const identityRef = useRef<StoredIdentity | null>(null);
  const workspacePubKeyRef = useRef<JsonWebKey | null>(null);
  const typingTimerRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const endRef = useRef<HTMLDivElement | null>(null);
  const settingsRef = useRef<WidgetSettings>(settings);
  const seenMessageIdsRef = useRef<Set<string>>(new Set());
  settingsRef.current = settings;

  useEffect(() => {
    installAudioUnlockListeners();
  }, []);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, agentTyping?.isTyping, open]);

  useEffect(() => {
    setAgentAvatarError(false);
  }, [settings.agentAvatarUrl]);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;

    async function connectVisitor() {
      const identity = await getOrCreateVisitorIdentity(roomId);
      if (cancelled) return;
      identityRef.current = identity;

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
      wsRef.current = ws;

      const decryptForVisitor = async (msg: ChatMessage): Promise<WidgetMessage> => {
        if (!msg.encrypted) {
          const plainAttachments =
            msg.attachments && msg.attachments.length > 0
              ? msg.attachments
              : msg.attachment
                ? [msg.attachment]
                : [];
          return {
            ...msg,
            displayText: msg.plaintext ?? '',
            displayAttachments: plainAttachments,
          };
        }
        const peerJwk =
          msg.senderRole === 'visitor'
            ? workspacePubKeyRef.current
            : msg.senderPublicKey || workspacePubKeyRef.current;

        if (!peerJwk || !msg.ciphertext || !msg.iv) {
          return {
            ...msg,
            displayText: 'Pesan terenkripsi (ECDH P-256)',
            displayAttachments: [],
          };
        }

        try {
          const peerKey = await importPublicKeyJWK(peerJwk);
          const aesKey = await deriveSharedAESKey(identity.keyPair.privateKey, peerKey);
          const plain = await decryptWithAESGCM(aesKey, msg.ciphertext, msg.iv);
          const decoded = decodeChatPayload(plain);
          return {
            ...msg,
            displayText: decoded.text,
            displayAttachments: decoded.attachments,
          };
        } catch {
          return {
            ...msg,
            displayText: 'Gagal mendekripsi pesan sesi',
            displayAttachments: [],
          };
        }
      };

      ws.onopen = () => {
        setConnected(true);
        const displayVisitorName =
          preChatValues.username ||
          preChatValues.nama ||
          preChatValues.name ||
          Object.values(preChatValues)[0] ||
          'Pengunjung Widget';
        ws.send(
          JSON.stringify({
            type: 'join',
            role: 'visitor',
            roomId,
            publicKey: identity.publicJwk,
            fingerprint: identity.fingerprint,
            visitorInfo: {
              name: displayVisitorName,
              currentPage: '/produk/demo-live',
              location: 'Jakarta, ID',
              device: 'Desktop',
              browser: navigator.userAgent.includes('Chrome') ? 'Chrome' : 'Web Browser',
            },
          })
        );
        if (Object.keys(preChatValues).length > 0) {
          ws.send(
            JSON.stringify({
              type: 'visitor:prechat',
              roomId,
              customAttributes: preChatValues,
            })
          );
        }
      };

      ws.onmessage = async (event) => {
        try {
          const data = JSON.parse(event.data as string) as Record<string, unknown>;
          if (data.type === 'init') {
            if (data.settings) {
              onSettingsUpdated?.(data.settings as WidgetSettings);
            }
            if (data.workspacePublicKey) {
              workspacePubKeyRef.current = data.workspacePublicKey as JsonWebKey;
            }
            const rawList = (data.messages as ChatMessage[]) ?? [];
            const decList = await Promise.all(rawList.map(decryptForVisitor));
            for (const m of decList) {
              seenMessageIdsRef.current.add(m.id);
            }
            setMessages(decList);
          } else if (data.type === 'settings:updated') {
            if (data.settings) {
              onSettingsUpdated?.(data.settings as WidgetSettings);
            }
          } else if (data.type === 'workspace:key') {
            workspacePubKeyRef.current = data.workspacePublicKey as JsonWebKey;
          } else if (data.type === 'message:new') {
            const msg = data.message as ChatMessage | undefined;
            if (!msg || msg.roomId !== roomId) return;
            const isNewlyAdded = !seenMessageIdsRef.current.has(msg.id);
            seenMessageIdsRef.current.add(msg.id);
            const dec = await decryptForVisitor(msg);
            setMessages((prev) => (prev.some((m) => m.id === dec.id) ? prev : [...prev, dec]));
            if (
              isNewlyAdded &&
              msg.senderRole !== 'visitor' &&
              settingsRef.current.widgetSoundEnabled
            ) {
              void playNotificationSound(
                settingsRef.current.soundPreset,
                settingsRef.current.soundVolume
              );
            }
          } else if (data.type === 'message:deleted') {
            const mId = data.messageId as string | undefined;
            if (data.roomId === roomId && mId) {
              setMessages((prev) => prev.filter((m) => m.id !== mId));
            }
          } else if (data.type === 'typing:state') {
            const t = data.typing as TypingState | undefined;
            if (t && t.roomId === roomId && t.senderRole === 'agent') {
              setAgentTyping(t.isTyping ? t : null);
            }
          } else if (data.type === 'error' && typeof data.error === 'string') {
            setUploadError(data.error);
          }
        } catch {
          // Ignore malformed event
        }
      };

      ws.onclose = () => {
        setConnected(false);
      };
    }

    void connectVisitor();

    return () => {
      cancelled = true;
      if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
      wsRef.current?.close();
    };
  }, [open, roomId]);

  const emitVisitorTyping = (isTyping: boolean) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    wsRef.current.send(
      JSON.stringify({
        type: 'typing:update',
        roomId,
        senderId: roomId,
        senderName: 'Pengunjung Widget',
        senderRole: 'visitor',
        isTyping,
      })
    );
    if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
    if (isTyping) {
      typingTimerRef.current = window.setTimeout(() => {
        if (wsRef.current?.readyState === WebSocket.OPEN) {
          wsRef.current.send(
            JSON.stringify({
              type: 'typing:update',
              roomId,
              senderId: roomId,
              senderName: 'Pengunjung Widget',
              senderRole: 'visitor',
              isTyping: false,
            })
          );
        }
      }, 2000);
    }
  };

  const handlePreChatSubmit = (e: FormEvent) => {
    e.preventDefault();
    setPreChatError(null);

    const normalized: Record<string, string> = {};
    for (const field of settings.preChatFields) {
      let val = (preChatValues[field.key] ?? '').trim();
      if (!val && (field.type === 'select' || field.type === 'radio') && field.options?.[0]) {
        val = field.options[0];
      }
      if (field.required && !val) {
        setPreChatError(`Kolom "${field.label}" wajib diisi terlebih dahulu.`);
        return;
      }
      if (val) {
        normalized[field.key] = val;
      }
    }

    setPreChatValues(normalized);
    setPreChatSubmitted(true);
    try {
      sessionStorage.setItem(`sandichat_prechat_${roomId}`, JSON.stringify(normalized));
    } catch {
      // Ignore storage error
    }

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          type: 'visitor:prechat',
          roomId,
          customAttributes: normalized,
        })
      );
    }
    onOpenRoomInInbox?.(roomId);
  };

  const handleImageSelect = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const selectedFiles = Array.from(files);
    e.target.value = '';
    setUploadError(null);
    setValidatingImage(true);
    try {
      const { accepted, errors } = await validateMultipleImageFiles(
        selectedFiles,
        pendingImages.length,
        MAX_CHAT_IMAGES
      );
      if (accepted.length > 0) {
        setPendingImages((prev) => [...prev, ...accepted].slice(0, MAX_CHAT_IMAGES));
      }
      if (errors.length > 0) {
        setUploadError(errors[0]);
      }
    } finally {
      setValidatingImage(false);
    }
  };

  const handleSend = async (e: FormEvent) => {
    e.preventDefault();
    const trimmed = draft.trim();
    const hasAttachments = pendingImages.length > 0;
    if (
      (!trimmed && !hasAttachments) ||
      !wsRef.current ||
      wsRef.current.readyState !== WebSocket.OPEN
    ) {
      return;
    }

    const atts = pendingImages;
    setDraft('');
    setPendingImages([]);
    setUploadError(null);
    emitVisitorTyping(false);

    const identity = identityRef.current;
    const workspacePub = workspacePubKeyRef.current;
    const canEncrypt = Boolean(settings.enforceE2EE && identity && workspacePub);
    const visitorSenderName =
      preChatValues.username ||
      preChatValues.nama ||
      preChatValues.name ||
      Object.values(preChatValues)[0] ||
      'Pengunjung Widget';

    let envelope: ChatMessage;
    if (canEncrypt && identity && workspacePub) {
      const peerKey = await importPublicKeyJWK(workspacePub);
      const aesKey = await deriveSharedAESKey(identity.keyPair.privateKey, peerKey);
      const encodedPayload = encodeChatPayload(trimmed, atts);
      const { ciphertext, iv } = await encryptWithAESGCM(aesKey, encodedPayload);
      envelope = {
        id: `vmsg_${crypto.randomUUID()}`,
        roomId,
        senderId: roomId,
        senderName: visitorSenderName,
        senderRole: 'visitor',
        encrypted: true,
        ciphertext,
        iv,
        senderPublicKey: identity.publicJwk,
        keyFingerprint: identity.fingerprint,
        timestamp: Date.now(),
      };
    } else {
      envelope = {
        id: `vmsg_${crypto.randomUUID()}`,
        roomId,
        senderId: roomId,
        senderName: visitorSenderName,
        senderRole: 'visitor',
        encrypted: false,
        plaintext: trimmed,
        attachment: atts[0],
        attachments: hasAttachments ? atts : undefined,
        keyFingerprint: identity?.fingerprint,
        timestamp: Date.now(),
      };
    }

    seenMessageIdsRef.current.add(envelope.id);
    setMessages((prev) =>
      prev.some((m) => m.id === envelope.id)
        ? prev
        : [...prev, { ...envelope, displayText: trimmed, displayAttachments: atts }]
    );

    wsRef.current.send(JSON.stringify({ type: 'message:send', message: envelope }));
    onOpenRoomInInbox?.(roomId);
  };

  const handleResetTestSession = () => {
    try {
      sessionStorage.removeItem(`sandichat_prechat_${roomId}`);
    } catch {
      // Ignore storage error
    }
    const nextRoomId = createVisitorRoomId();
    try {
      sessionStorage.setItem('sandichat_widget_room_id', nextRoomId);
    } catch {
      // Ignore storage error
    }
    seenMessageIdsRef.current.clear();
    setMessages([]);
    setDraft('');
    setPendingImages([]);
    setUploadError(null);
    setPreChatValues({});
    setPreChatError(null);
    setPreChatSubmitted(false);
    setAgentTyping(null);
    setRoomId(nextRoomId);
  };

  if (!open) return null;

  const hasMissingRequiredField = settings.preChatFields.some(
    (f) => f.required && !(preChatValues[f.key] ?? '').trim()
  );
  const showPreChatForm =
    settings.preChatFormEnabled &&
    settings.preChatFields.length > 0 &&
    (!preChatSubmitted || hasMissingRequiredField);

  const surface = SURFACE_STYLE[settings.surfaceContrast];
  const radius = RADIUS_STYLE[settings.borderRadius];
  const positionClass =
    settings.launcherPosition === 'bottom-left' ? 'left-6 bottom-6' : 'right-6 bottom-6';

  const motionInitial =
    settings.entranceAnimation === 'spring'
      ? { opacity: 0, scale: 0.92, y: 18 }
      : settings.entranceAnimation === 'slide'
        ? { opacity: 0, y: 28 }
        : { opacity: 0 };

  return (
    <motion.div
      initial={motionInitial}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={
        settings.entranceAnimation === 'spring'
          ? { type: 'spring', stiffness: 360, damping: 28 }
          : { duration: 0.18 }
      }
      className={
        embedded
          ? 'w-full h-screen overflow-hidden flex flex-col'
          : `fixed ${positionClass} z-50 w-[360px] max-w-[calc(100vw-2rem)] border border-white/[0.12] shadow-2xl overflow-hidden flex flex-col`
      }
      style={{
        backgroundColor: surface.bg,
        borderRadius: embedded ? '0px' : radius,
        height: embedded ? '100vh' : '500px',
      }}
      role="dialog"
      aria-label="Pratinjau Live Widget Pengunjung"
    >
      {/* Widget Header */}
      <div
        className="px-4 py-3.5 border-b border-white/[0.08] flex items-center justify-between gap-2"
        style={{ backgroundColor: surface.card }}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          {settings.agentAvatarUrl && !agentAvatarError ? (
            <div className="relative shrink-0">
              <img
                src={settings.agentAvatarUrl}
                alt={settings.agentName || settings.brandName}
                referrerPolicy="no-referrer"
                onError={() => setAgentAvatarError(true)}
                className="w-9 h-9 rounded-full object-cover border border-white/15"
              />
              <span
                className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 ${
                  connected ? 'bg-emerald-400' : 'bg-amber-400'
                }`}
                style={{ borderColor: surface.card }}
              />
            </div>
          ) : (
            <BrandLogo
              logoStyle={settings.logoStyle}
              accentColor={settings.accentColor}
              customLogoUrl={settings.customLogoUrl}
              brandName={settings.brandName}
              size={34}
            />
          )}
          <div className="min-w-0">
            <div className="text-sm font-semibold text-slate-100 truncate">
              {settings.brandName}
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
              <span
                className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                  connected ? 'bg-emerald-400' : 'bg-amber-400'
                }`}
              />
              <span className="truncate">
                {connected
                  ? `${settings.agentName || 'Tim Support'} · Online`
                  : 'Menghubungkan...'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1">
          {!embedded && (
            <button
              type="button"
              onClick={handleResetTestSession}
              title="Mulai sesi uji baru (tampilkan ulang formulir pra-chat)"
              aria-label="Mulai sesi uji baru"
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/[0.06] transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            aria-label="Perkecil widget"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/[0.06] transition-colors"
          >
            <Minimize2 className="w-4 h-4" />
          </button>
          {!embedded && (
            <button
              type="button"
              onClick={onClose}
              aria-label="Tutup widget"
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/[0.06] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {showPreChatForm ? (
        <form
          onSubmit={handlePreChatSubmit}
          className="flex-1 overflow-y-auto p-4 flex flex-col justify-between gap-4"
        >
          <div className="space-y-3.5">
            <div>
              <h3 className="text-sm font-semibold text-slate-100">
                {settings.preChatFormTitle || 'Mulai Percakapan'}
              </h3>
              {settings.preChatFormDescription && (
                <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                  {settings.preChatFormDescription}
                </p>
              )}
            </div>

            {settings.preChatFields.map((field) => {
              const currentValue =
                preChatValues[field.key] ??
                ((field.type === 'select' || field.type === 'radio') ? field.options?.[0] ?? '' : '');

              return (
                <div key={field.id} className="space-y-1.5">
                  <label
                    htmlFor={`widget-field-${field.id}`}
                    className="block text-xs font-medium text-slate-300"
                  >
                    {field.label}
                    {field.required && <span className="text-rose-400 ml-0.5">*</span>}
                  </label>

                  {field.type === 'radio' ? (
                    <div className="space-y-1.5">
                      {(field.options ?? []).map((opt, idx) => {
                        const selected = currentValue === opt;
                        return (
                          <button
                            key={idx}
                            type="button"
                            onClick={() =>
                              setPreChatValues((prev) => ({ ...prev, [field.key]: opt }))
                            }
                            className="w-full text-left px-3 py-2 border text-xs flex items-center gap-2.5 transition-colors"
                            style={{
                              backgroundColor: selected
                                ? `${settings.accentColor}1A`
                                : surface.card,
                              borderColor: selected
                                ? `${settings.accentColor}66`
                                : 'rgba(255,255,255,0.08)',
                              borderRadius: radius,
                            }}
                          >
                            <span
                              className="w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0"
                              style={{
                                borderColor: selected
                                  ? settings.accentColor
                                  : 'rgba(255,255,255,0.28)',
                              }}
                            >
                              {selected && (
                                <span
                                  className="w-1.5 h-1.5 rounded-full"
                                  style={{ backgroundColor: settings.accentColor }}
                                />
                              )}
                            </span>
                            <span className="text-slate-100">{opt}</span>
                          </button>
                        );
                      })}
                    </div>
                  ) : field.type === 'select' ? (
                    <select
                      id={`widget-field-${field.id}`}
                      value={currentValue}
                      onChange={(e) =>
                        setPreChatValues((prev) => ({ ...prev, [field.key]: e.target.value }))
                      }
                      className="w-full px-3 py-2 border border-white/[0.1] text-xs text-slate-100 focus:outline-none focus:border-white/25"
                      style={{ backgroundColor: surface.card, borderRadius: radius }}
                    >
                      {(field.options ?? []).map((opt, idx) => (
                        <option key={idx} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                  ) : field.type === 'textarea' ? (
                    <textarea
                      id={`widget-field-${field.id}`}
                      rows={2}
                      value={currentValue}
                      onChange={(e) =>
                        setPreChatValues((prev) => ({ ...prev, [field.key]: e.target.value }))
                      }
                      placeholder={field.placeholder || `Masukkan ${field.label.toLowerCase()}...`}
                      className="w-full px-3 py-2 border border-white/[0.1] text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-white/25 resize-none"
                      style={{ backgroundColor: surface.card, borderRadius: radius }}
                    />
                  ) : (
                    <input
                      id={`widget-field-${field.id}`}
                      type={field.type === 'email' ? 'email' : field.type === 'number' ? 'number' : 'text'}
                      value={currentValue}
                      onChange={(e) =>
                        setPreChatValues((prev) => ({ ...prev, [field.key]: e.target.value }))
                      }
                      placeholder={field.placeholder || `Masukkan ${field.label.toLowerCase()}...`}
                      className="w-full px-3 py-2 border border-white/[0.1] text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-white/25"
                      style={{ backgroundColor: surface.card, borderRadius: radius }}
                    />
                  )}
                </div>
              );
            })}

            {preChatError && <p className="text-xs text-rose-400">{preChatError}</p>}
          </div>

          <button
            type="submit"
            className="w-full py-2.5 text-xs font-semibold text-slate-950 transition-opacity hover:opacity-90"
            style={{ backgroundColor: settings.accentColor, borderRadius: radius }}
          >
            {settings.preChatSubmitLabel || 'Mulai Obrolan'}
          </button>
        </form>
      ) : (
        <>
          {/* Widget Message Stream */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            <div className="flex items-end gap-2 max-w-[90%]">
              {settings.agentAvatarUrl && !agentAvatarError && (
                <img
                  src={settings.agentAvatarUrl}
                  alt={settings.agentName || 'CS'}
                  referrerPolicy="no-referrer"
                  className="w-6 h-6 rounded-full object-cover border border-white/10 shrink-0 mb-0.5"
                />
              )}
              <div
                className="p-3 border border-white/[0.08] text-xs text-slate-200 leading-relaxed"
                style={{ backgroundColor: surface.card, borderRadius: radius }}
              >
                {settings.welcomeMessage}
              </div>
            </div>

            {messages.map((msg) => {
              const isVisitor = msg.senderRole === 'visitor';
              return (
                <div key={msg.id} className={`flex flex-col ${isVisitor ? 'items-end' : 'items-start'}`}>
                  <div className={`flex items-end gap-2 max-w-[88%] ${isVisitor ? 'flex-row-reverse' : 'flex-row'}`}>
                    {!isVisitor && settings.agentAvatarUrl && !agentAvatarError && (
                      <img
                        src={settings.agentAvatarUrl}
                        alt={msg.senderName}
                        referrerPolicy="no-referrer"
                        className="w-6 h-6 rounded-full object-cover border border-white/10 shrink-0 mb-0.5"
                      />
                    )}
                    <div
                      className="px-3.5 py-2.5 border text-xs leading-relaxed text-slate-100"
                      style={
                        isVisitor
                          ? {
                              backgroundColor: `${settings.accentColor}20`,
                              borderColor: `${settings.accentColor}44`,
                              borderRadius: radius,
                            }
                          : {
                              backgroundColor: surface.card,
                              borderColor: 'rgba(255,255,255,0.08)',
                              borderRadius: radius,
                            }
                      }
                    >
                      {msg.displayAttachments.length > 0 && (
                        <div
                          className={`mb-1.5 grid gap-1.5 ${
                            msg.displayAttachments.length === 1 ? 'grid-cols-1' : 'grid-cols-2'
                          }`}
                        >
                          {msg.displayAttachments.map((att, idx) => (
                            <button
                              key={`${msg.id}-att-${idx}`}
                              type="button"
                              onClick={() =>
                                setLightboxGallery({
                                  images: msg.displayAttachments,
                                  index: idx,
                                })
                              }
                              className="block overflow-hidden rounded-lg border border-white/10 focus:outline-none bg-black/40"
                            >
                              <img
                                src={att.dataUrl}
                                alt={att.fileName}
                                className={
                                  msg.displayAttachments.length === 1
                                    ? 'max-h-44 w-full object-contain'
                                    : 'h-24 w-full object-cover'
                                }
                              />
                            </button>
                          ))}
                        </div>
                      )}
                      {msg.displayText && <span>{msg.displayText}</span>}
                    </div>
                  </div>
                  <span
                    className={`mt-1 text-[10px] font-mono text-slate-500 ${
                      !isVisitor && settings.agentAvatarUrl && !agentAvatarError ? 'pl-8' : ''
                    }`}
                  >
                    {new Date(msg.timestamp).toLocaleTimeString('id-ID', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
              );
            })}

            {agentTyping?.isTyping && (
              <TypingIndicator
                style={settings.typingAnimation}
                accentColor={settings.accentColor}
                senderName={agentTyping.senderName}
              />
            )}
            <div ref={endRef} />
          </div>

          {/* Widget Composer */}
          <form
            onSubmit={(e) => void handleSend(e)}
            className="p-3 border-t border-white/[0.08] space-y-2"
            style={{ backgroundColor: surface.card }}
          >
            {uploadError && (
              <div className="px-2.5 py-1.5 rounded-lg border border-rose-500/30 bg-rose-500/10 text-[11px] text-rose-300 flex items-center justify-between gap-2">
                <span className="leading-snug">{uploadError}</span>
                <button
                  type="button"
                  onClick={() => setUploadError(null)}
                  aria-label="Tutup error"
                  className="text-rose-300 hover:text-white shrink-0"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}

            {pendingImages.length > 0 && (
              <div className="p-2 rounded-lg border border-white/[0.08] bg-black/25 space-y-1.5">
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span>
                    {pendingImages.length}/{MAX_CHAT_IMAGES} gambar siap dikirim
                  </span>
                  <button
                    type="button"
                    onClick={() => setPendingImages([])}
                    className="hover:text-white"
                  >
                    Hapus semua
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {pendingImages.map((img, idx) => (
                    <div
                      key={`${img.fileName}-${idx}`}
                      className="relative w-12 h-12 rounded overflow-hidden border border-white/10 bg-black/40 shrink-0"
                    >
                      <img
                        src={img.dataUrl}
                        alt={img.fileName}
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setPendingImages((prev) => prev.filter((_, i) => i !== idx))
                        }
                        aria-label={`Hapus ${img.fileName}`}
                        className="absolute top-0.5 right-0.5 p-0.5 rounded-full bg-black/80 text-slate-200 hover:text-white"
                      >
                        <X className="w-2.5 h-2.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex items-center gap-2">
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="image/png,image/jpeg,image/webp,image/gif"
                onChange={(e) => void handleImageSelect(e)}
                className="hidden"
              />
              <button
                type="button"
                disabled={validatingImage || pendingImages.length >= MAX_CHAT_IMAGES}
                onClick={() => fileInputRef.current?.click()}
                aria-label="Unggah beberapa gambar"
                title={`Unggah gambar (maks ${MAX_CHAT_IMAGES} gambar: PNG, JPG, WebP, GIF)`}
                className="relative p-2 border border-white/[0.08] text-slate-300 hover:text-white hover:border-white/20 transition-colors shrink-0 disabled:opacity-50"
                style={{ backgroundColor: surface.bg, borderRadius: radius }}
              >
                <ImagePlus className="w-4 h-4" />
                {pendingImages.length > 0 && (
                  <span
                    className="absolute -top-1.5 -right-1.5 min-w-[16px] h-4 px-1 rounded-full text-[10px] font-bold text-slate-950 flex items-center justify-center"
                    style={{ backgroundColor: settings.accentColor }}
                  >
                    {pendingImages.length}
                  </span>
                )}
              </button>
              <input
                type="text"
                value={draft}
                onChange={(e) => {
                  setDraft(e.target.value);
                  emitVisitorTyping(e.target.value.trim().length > 0);
                }}
                placeholder={validatingImage ? 'Memvalidasi gambar...' : settings.inputPlaceholder}
                className="flex-1 min-w-0 px-3 py-2 border border-white/[0.08] text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-white/25"
                style={{ backgroundColor: surface.bg, borderRadius: radius }}
              />
              <button
                type="submit"
                disabled={!draft.trim() && pendingImages.length === 0}
                aria-label="Kirim pesan widget"
                className="p-2 text-slate-950 disabled:opacity-40 transition-opacity shrink-0"
                style={{ backgroundColor: settings.accentColor, borderRadius: radius }}
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </form>
        </>
      )}

      {lightboxGallery && lightboxGallery.images[lightboxGallery.index] && (
        <div
          className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4"
          onClick={() => setLightboxGallery(null)}
        >
          <div
            className="relative max-w-full max-h-[85vh] rounded-xl border border-white/15 bg-[#0C0E13] p-2.5 space-y-2"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between gap-3">
              <span className="text-[11px] font-mono text-slate-300 truncate">
                {lightboxGallery.images[lightboxGallery.index].fileName}
                {lightboxGallery.images.length > 1
                  ? ` (${lightboxGallery.index + 1}/${lightboxGallery.images.length})`
                  : ''}
              </span>
              <div className="flex items-center gap-1">
                {lightboxGallery.images.length > 1 && (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        setLightboxGallery((prev) =>
                          prev
                            ? {
                                ...prev,
                                index:
                                  (prev.index - 1 + prev.images.length) % prev.images.length,
                              }
                            : null
                        )
                      }
                      aria-label="Gambar sebelumnya"
                      className="p-1 rounded text-slate-400 hover:text-white"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setLightboxGallery((prev) =>
                          prev
                            ? {
                                ...prev,
                                index: (prev.index + 1) % prev.images.length,
                              }
                            : null
                        )
                      }
                      aria-label="Gambar berikutnya"
                      className="p-1 rounded text-slate-400 hover:text-white"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => setLightboxGallery(null)}
                  aria-label="Tutup gambar"
                  className="p-1 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
            <img
              src={lightboxGallery.images[lightboxGallery.index].dataUrl}
              alt={lightboxGallery.images[lightboxGallery.index].fileName}
              className="max-h-[70vh] max-w-full rounded object-contain"
            />
          </div>
        </div>
      )}
    </motion.div>
  );
}

interface WidgetLauncherButtonProps {
  settings: WidgetSettings;
  onClick: () => void;
  className?: string;
}

export function WidgetLauncherButton({
  settings,
  onClick,
  className = '',
}: WidgetLauncherButtonProps) {
  const isImage =
    settings.launcherMode === 'image' && Boolean(settings.launcherImageUrl?.trim());
  const isLeft = settings.launcherPosition === 'bottom-left';
  const size = Math.min(128, Math.max(48, settings.launcherImageSize || 72));
  const shape = settings.launcherImageShape || 'floating';

  return (
    <div
      className={`inline-flex items-center gap-2.5 ${
        isLeft ? 'flex-row-reverse' : 'flex-row'
      } ${className}`}
    >
      {isImage && settings.launcherBubbleText && (
        <button
          type="button"
          onClick={onClick}
          className="px-3 py-1.5 rounded-xl border border-white/[0.14] bg-[#0F1218] text-xs font-medium text-slate-100 shadow-xl hover:border-white/30 transition-colors max-w-[200px] truncate"
        >
          {settings.launcherBubbleText}
        </button>
      )}

      {isImage ? (
        <button
          type="button"
          onClick={onClick}
          aria-label={`Buka ${settings.brandName || 'Livechat'}`}
          className={`inline-flex items-center justify-center transition-transform hover:scale-105 focus:outline-none cursor-pointer ${
            shape === 'circle'
              ? 'rounded-full overflow-hidden bg-[#0F1218] shadow-2xl border-2'
              : shape === 'rounded'
                ? 'rounded-2xl overflow-hidden bg-[#0F1218] shadow-2xl border border-white/[0.16]'
                : 'bg-transparent border-0 drop-shadow-[0_12px_24px_rgba(0,0,0,0.55)]'
          }`}
          style={{
            width: `${size}px`,
            height: `${size}px`,
            borderColor: shape === 'circle' ? settings.accentColor : undefined,
          }}
        >
          <img
            src={settings.launcherImageUrl}
            alt={settings.brandName || 'Live Chat Launcher'}
            className={`w-full h-full pointer-events-none ${
              shape === 'floating' ? 'object-contain' : 'object-cover'
            }`}
          />
        </button>
      ) : (
        <button
          type="button"
          onClick={onClick}
          aria-label={`Buka ${settings.brandName || 'Livechat'}`}
          className="inline-flex items-center gap-2.5 px-4 py-2.5 rounded-xl border border-white/[0.14] bg-[#0F1218] text-[13px] font-semibold text-slate-100 shadow-2xl hover:border-white/30 transition-transform hover:scale-[1.03] cursor-pointer"
        >
          <BrandLogo
            logoStyle={settings.logoStyle}
            accentColor={settings.accentColor}
            customLogoUrl={settings.customLogoUrl}
            brandName={settings.brandName}
            size={20}
          />
          <span>{settings.brandName || 'Live Chat'}</span>
        </button>
      )}
    </div>
  );
}
