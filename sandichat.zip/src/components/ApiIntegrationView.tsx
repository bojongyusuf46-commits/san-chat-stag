import { Check, Copy, Key, Play, Plus, Server, Trash2, Webhook } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import type { ApiKeyRecord, VisitorRoom, WebhookConfig, WidgetSettings } from '../types/chat';

interface ApiIntegrationViewProps {
  settings: WidgetSettings;
  rooms: VisitorRoom[];
  authToken: string;
  onUnauthorized?: () => void;
}

export function ApiIntegrationView({
  settings,
  rooms,
  authToken,
  onUnauthorized,
}: ApiIntegrationViewProps) {
  const [keys, setKeys] = useState<ApiKeyRecord[]>([]);
  const [newKeyName, setNewKeyName] = useState('');
  const [newlyCreatedSecret, setNewlyCreatedSecret] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const [webhooks, setWebhooks] = useState<WebhookConfig[]>([]);
  const [webhookUrl, setWebhookUrl] = useState('');
  const [webhookError, setWebhookError] = useState<string | null>(null);

  const [mainTab, setMainTab] = useState<'embed' | 'developer' | 'hosting'>('embed');
  const [hostingTab, setHostingTab] = useState<'aapanel' | 'cpanel' | 'vps'>('aapanel');
  const [sdkTab, setSdkTab] = useState<'script' | 'react' | 'rest'>('script');

  // Interactive API Playground state
  const [testEndpoint, setTestEndpoint] = useState<'analytics' | 'message' | 'config'>('analytics');
  const [testApiKey, setTestApiKey] = useState('');
  const [testRoomId, setTestRoomId] = useState(rooms[0]?.id ?? 'room-nadia-841');
  const [testMessageBody, setTestMessageBody] = useState(
    'Notifikasi sistem: Pembayaran invoice #INV-2026-09 telah terverifikasi.'
  );
  const [testResult, setTestResult] = useState<{
    status: number;
    body: string;
  } | null>(null);
  const [runningTest, setRunningTest] = useState(false);

  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://app.sandichat.id';

  const fetchKeysAndHooks = useCallback(async () => {
    const headers = { Authorization: `Bearer ${authToken}` };
    const [kRes, wRes] = await Promise.all([
      fetch('/api/keys', { headers }),
      fetch('/api/webhooks', { headers }),
    ]);
    if (kRes.status === 401 || wRes.status === 401) {
      onUnauthorized?.();
      return;
    }
    if (kRes.ok) {
      const data = (await kRes.json()) as { keys: ApiKeyRecord[] };
      setKeys(data.keys);
    }
    if (wRes.ok) {
      const data = (await wRes.json()) as { webhooks: WebhookConfig[] };
      setWebhooks(data.webhooks);
    }
  }, [authToken, onUnauthorized]);

  useEffect(() => {
    void fetchKeysAndHooks();
  }, [fetchKeysAndHooks]);

  const handleCreateKey = async () => {
    const res = await fetch('/api/keys', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${authToken}`,
      },
      body: JSON.stringify({
        name: newKeyName.trim() || 'Integrasi Aplikasi Web',
        scopes: ['messages:write', 'analytics:read', 'widget:read'],
      }),
    });
    if (res.status === 401) {
      onUnauthorized?.();
      return;
    }
    if (res.ok) {
      const data = (await res.json()) as { key: ApiKeyRecord; secret: string };
      setKeys((prev) => [data.key, ...prev]);
      setNewlyCreatedSecret(data.secret);
      setTestApiKey(data.secret);
      setNewKeyName('');
    }
  };

  const handleRevokeKey = async (id: string) => {
    const res = await fetch(`/api/keys/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${authToken}` },
    });
    if (res.status === 401) {
      onUnauthorized?.();
      return;
    }
    if (res.ok) {
      setKeys((prev) => prev.filter((k) => k.id !== id));
    }
  };

  const handleAddWebhook = async () => {
    setWebhookError(null);
    const res = await fetch('/api/webhooks', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${authToken}`,
      },
      body: JSON.stringify({
        url: webhookUrl,
        events: ['message.encrypted', 'session.started', 'typing.updated'],
      }),
    });
    if (res.status === 401) {
      onUnauthorized?.();
      return;
    }
    if (!res.ok) {
      const err = (await res.json()) as { error?: string };
      setWebhookError(err.error ?? 'Gagal menyimpan webhook.');
      return;
    }
    const data = (await res.json()) as { webhook: WebhookConfig };
    setWebhooks((prev) => [data.webhook, ...prev]);
    setWebhookUrl('');
  };

  const handleDeleteWebhook = async (id: string) => {
    const res = await fetch(`/api/webhooks/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${authToken}` },
    });
    if (res.status === 401) {
      onUnauthorized?.();
      return;
    }
    if (res.ok) {
      setWebhooks((prev) => prev.filter((w) => w.id !== id));
    }
  };

  const handleCopy = (id: string, text: string) => {
    void navigator.clipboard.writeText(text);
    setCopiedId(id);
    window.setTimeout(() => setCopiedId(null), 1800);
  };

  const handleRunPlayground = async () => {
    setRunningTest(true);
    try {
      let res: Response;
      if (testEndpoint === 'config') {
        res = await fetch('/api/v1/widget-config');
      } else if (testEndpoint === 'analytics') {
        res = await fetch('/api/v1/analytics', {
          headers: { 'x-api-key': testApiKey.trim() },
        });
      } else {
        res = await fetch('/api/v1/messages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': testApiKey.trim(),
          },
          body: JSON.stringify({
            roomId: testRoomId,
            senderName: 'Sistem Eksternal',
            plaintext: testMessageBody,
          }),
        });
      }
      const json = await res.json();
      setTestResult({
        status: res.status,
        body: JSON.stringify(json, null, 2),
      });
    } catch (err) {
      setTestResult({
        status: 0,
        body: err instanceof Error ? err.message : 'Network error',
      });
    } finally {
      setRunningTest(false);
    }
  };

  const oneLineScript = `<script src="${origin}/embed.js" defer></script>`;

  const scriptSnippet = `<!-- Cukup tempel 1 baris ini sebelum tag </body> di website lain (tanpa API Key) -->
<script src="${origin}/embed.js" defer></script>`;

  const reactSnippet = `import { useEffect } from 'react';

export function SandiChatWidget() {
  useEffect(() => {
    const script = document.createElement('script');
    script.src = '${origin}/embed.js';
    script.defer = true;
    document.body.appendChild(script);
    return () => { script.remove(); };
  }, []);

  return null;
}`;

  const restSnippet = `curl -X POST "${origin}/api/v1/messages" \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: ${testApiKey || 'MASUKKAN_API_KEY_ANDA'}" \\
  -d '{
    "roomId": "${testRoomId}",
    "senderName": "Order Bot",
    "plaintext": "Pesanan #ORD-882 telah dikirim."
  }'`;

  const envSnippet = `PORT=3000
NODE_ENV=production
APP_URL=https://chat.domainanda.com
ADMIN_EMAIL=admin@domainanda.com
ADMIN_PASSCODE=GantiKataSandiKuatMin12Karakter`;

  const nginxWsSnippet = `location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 86400s;
    proxy_send_timeout 86400s;
    client_max_body_size 10M;
}`;

  const cpanelBuildCmd = `npm install
npm run build
npx esbuild server.ts --bundle --platform=node --format=esm --packages=external --outfile=server.mjs`;

  return (
    <div className="h-full overflow-y-auto p-6 lg:p-8 bg-[#090A0D]">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/[0.08]">
          <div>
            <h1 className="text-lg font-semibold text-slate-100">
              Pasang Widget, API &amp; Panduan Hosting
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Tempel 1 baris script di situs lain, kelola API pengembang, atau ikuti panduan deploy ke aaPanel / cPanel / VPS.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-1 p-1 rounded-lg bg-[#0F1218] border border-white/[0.08]">
            <button
              type="button"
              onClick={() => setMainTab('embed')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                mainTab === 'embed'
                  ? 'bg-[#1B202C] text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Pasang di Web (Tanpa API)
            </button>
            <button
              type="button"
              onClick={() => setMainTab('developer')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                mainTab === 'developer'
                  ? 'bg-[#1B202C] text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              API &amp; Webhook
            </button>
            <button
              type="button"
              onClick={() => setMainTab('hosting')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                mainTab === 'hosting'
                  ? 'bg-[#1B202C] text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Panduan Hosting (aaPanel / cPanel)
            </button>
          </div>
        </div>

        {mainTab === 'embed' && (
          <div className="space-y-6">
            {/* Zero-Integration 1-Line Install Banner */}
            <div className="p-5 rounded-xl border border-white/[0.1] bg-[#0F1218] space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-sm font-semibold text-slate-100">
                    Pasang Instan Tanpa Integrasi (1 Baris Script)
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Tempel di HTML, WordPress, Laravel, atau Shopify sebelum tag{' '}
                    <code className="text-slate-300">&lt;/body&gt;</code>. Logo, foto agen,
                    launcher GIF, form pra-chat, dan tema otomatis mengikuti pengaturan Studio Anda.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy('oneline', oneLineScript)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold text-slate-950 transition-opacity hover:opacity-90 whitespace-nowrap shrink-0"
                  style={{ backgroundColor: settings.accentColor }}
                >
                  {copiedId === 'oneline' ? (
                    <Check className="w-3.5 h-3.5" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>{copiedId === 'oneline' ? 'Script Disalin' : 'Salin Script Widget'}</span>
                </button>
              </div>

              <div className="rounded-lg border border-white/[0.08] bg-[#090B0F] px-4 py-3 overflow-x-auto">
                <code className="font-mono text-xs text-slate-200 whitespace-nowrap">
                  {oneLineScript}
                </code>
              </div>
            </div>

            {/* Embed Snippets */}
            <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-sm font-semibold text-slate-100">
                    Panduan Tempel per Framework
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Tanpa API Key untuk embed widget · Warna aksen aktif: {settings.accentColor}
                  </p>
                </div>
                <div className="flex items-center gap-1 p-1 rounded-lg bg-[#141821] border border-white/[0.06]">
                  {(
                    [
                      { id: 'script', label: 'HTML Script' },
                      { id: 'react', label: 'React / Next.js' },
                    ] as const
                  ).map((tab) => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setSdkTab(tab.id)}
                      className={`px-2.5 py-1 rounded text-xs font-medium transition-colors whitespace-nowrap ${
                        sdkTab === tab.id
                          ? 'bg-[#1E2430] text-white'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="relative rounded-lg border border-white/[0.08] bg-[#090B0F] p-4">
                <button
                  type="button"
                  onClick={() =>
                    handleCopy(
                      'snippet',
                      sdkTab === 'react' ? reactSnippet : scriptSnippet
                    )
                  }
                  className="absolute top-3 right-3 inline-flex items-center gap-1.5 px-2.5 py-1 rounded border border-white/10 bg-[#141821] text-[11px] font-medium text-slate-300 hover:text-white transition-colors"
                >
                  {copiedId === 'snippet' ? (
                    <Check className="w-3 h-3 text-emerald-400" />
                  ) : (
                    <Copy className="w-3 h-3" />
                  )}
                  <span>{copiedId === 'snippet' ? 'Disalin' : 'Salin'}</span>
                </button>
                <pre className="font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed pr-16">
                  {sdkTab === 'react' ? reactSnippet : scriptSnippet}
                </pre>
              </div>
            </div>
          </div>
        )}

        {mainTab === 'developer' && (
          <div className="space-y-6">
            {/* Row 1: REST Snippet & API Keys */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-7 p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-4">
                <div>
                  <h2 className="text-sm font-semibold text-slate-100">
                    Contoh Kirim Pesan via REST API (cURL)
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Opsional untuk otomasi sistem backend atau bot notifikasi
                  </p>
                </div>

                <div className="relative rounded-lg border border-white/[0.08] bg-[#090B0F] p-4">
                  <button
                    type="button"
                    onClick={() => handleCopy('rest', restSnippet)}
                    className="absolute top-3 right-3 inline-flex items-center gap-1.5 px-2.5 py-1 rounded border border-white/10 bg-[#141821] text-[11px] font-medium text-slate-300 hover:text-white transition-colors"
                  >
                    {copiedId === 'rest' ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                    <span>{copiedId === 'rest' ? 'Disalin' : 'Salin'}</span>
                  </button>
                  <pre className="font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed pr-16">
                    {restSnippet}
                  </pre>
                </div>
              </div>

          {/* API Key Management */}
          <div className="lg:col-span-5 p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-4">
            <div className="flex items-center gap-2">
              <Key className="w-4 h-4" style={{ color: settings.accentColor }} />
              <h2 className="text-sm font-semibold text-slate-100">Manajemen API Key</h2>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                value={newKeyName}
                onChange={(e) => setNewKeyName(e.target.value)}
                placeholder="Nama aplikasi (mis. Portal Kasir)"
                className="flex-1 px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-white/25"
              />
              <button
                type="button"
                onClick={() => void handleCreateKey()}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold text-slate-950 whitespace-nowrap shrink-0"
                style={{ backgroundColor: settings.accentColor }}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Buat Key</span>
              </button>
            </div>

            {newlyCreatedSecret && (
              <div className="p-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 space-y-1.5">
                <div className="text-[11px] font-medium text-emerald-300">
                  Simpan secret key ini sekarang (hanya ditampilkan sekali):
                </div>
                <div className="flex items-center justify-between gap-2">
                  <code className="font-mono text-[11px] text-white break-all">
                    {newlyCreatedSecret}
                  </code>
                  <button
                    type="button"
                    onClick={() => handleCopy('secret', newlyCreatedSecret)}
                    className="px-2 py-1 rounded border border-white/15 bg-black/30 text-[11px] text-slate-200 shrink-0"
                  >
                    {copiedId === 'secret' ? 'Disalin' : 'Salin'}
                  </button>
                </div>
              </div>
            )}

            <div className="divide-y divide-white/[0.06] max-h-56 overflow-y-auto">
              {keys.length === 0 ? (
                <div className="py-6 text-center text-xs text-slate-500">
                  Belum ada API key aktif. Klik &quot;Buat Key&quot; untuk memulai integrasi.
                </div>
              ) : (
                keys.map((k) => (
                  <div key={k.id} className="py-2.5 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="text-xs font-medium text-slate-200 truncate">{k.name}</div>
                      <div className="text-[11px] font-mono text-slate-500">
                        {k.prefix} · {k.requestsCount} req
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => void handleRevokeKey(k.id)}
                      aria-label={`Cabut API key ${k.name}`}
                      className="p-1.5 rounded hover:bg-white/[0.06] text-slate-400 hover:text-rose-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Row 2: Live REST API Playground + Webhooks */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Interactive Endpoint Tester */}
          <div className="lg:col-span-7 p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-100">
                  Playground Uji Endpoint Langsung
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Jalankan request HTTP nyata ke server SandiChat dan lihat respons JSON secara
                  langsung
                </p>
              </div>
              <button
                type="button"
                onClick={() => void handleRunPlayground()}
                disabled={runningTest}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold text-slate-950 whitespace-nowrap shrink-0"
                style={{ backgroundColor: settings.accentColor }}
              >
                <Play className="w-3.5 h-3.5" />
                <span>{runningTest ? 'Mengirim...' : 'Kirim Request'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1" htmlFor="pg-endpoint">
                  Endpoint
                </label>
                <select
                  id="pg-endpoint"
                  value={testEndpoint}
                  onChange={(e) =>
                    setTestEndpoint(e.target.value as 'analytics' | 'message' | 'config')
                  }
                  className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs font-mono text-slate-100"
                >
                  <option value="analytics">GET /api/v1/analytics</option>
                  <option value="message">POST /api/v1/messages</option>
                  <option value="config">GET /api/v1/widget-config</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[11px] text-slate-400 mb-1" htmlFor="pg-key">
                  Header x-api-key {testEndpoint === 'config' && '(Opsional untuk config publik)'}
                </label>
                <input
                  id="pg-key"
                  type="text"
                  value={testApiKey}
                  onChange={(e) => setTestApiKey(e.target.value)}
                  placeholder="Buat key di kanan atas untuk otomatis mengisi..."
                  className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs font-mono text-slate-100 placeholder:text-slate-600"
                />
              </div>
            </div>

            {testEndpoint === 'message' && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1" htmlFor="pg-room">
                    Target Room ID
                  </label>
                  <select
                    id="pg-room"
                    value={testRoomId}
                    onChange={(e) => setTestRoomId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs font-mono text-slate-100"
                  >
                    {rooms.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.visitorName} ({r.id})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-[11px] text-slate-400 mb-1" htmlFor="pg-msg">
                    Isi Pesan (plaintext)
                  </label>
                  <input
                    id="pg-msg"
                    type="text"
                    value={testMessageBody}
                    onChange={(e) => setTestMessageBody(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100"
                  />
                </div>
              </div>
            )}

            <div className="rounded-lg border border-white/[0.08] bg-[#090B0F] p-3.5 min-h-[140px]">
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 mb-2">
                <span>Respons Server</span>
                {testResult && (
                  <span
                    className={
                      testResult.status >= 200 && testResult.status < 300
                        ? 'text-emerald-400'
                        : 'text-amber-400'
                    }
                  >
                    HTTP {testResult.status}
                  </span>
                )}
              </div>
              <pre className="font-mono text-xs text-slate-300 overflow-x-auto max-h-48">
                {testResult
                  ? testResult.body
                  : '// Klik "Kirim Request" untuk melihat respons JSON langsung dari API'}
              </pre>
            </div>
          </div>

          {/* Webhooks Configuration */}
          <div className="lg:col-span-5 p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-4">
            <div className="flex items-center gap-2">
              <Webhook className="w-4 h-4" style={{ color: settings.accentColor }} />
              <h2 className="text-sm font-semibold text-slate-100">Webhook Event Eksternal</h2>
            </div>
            <p className="text-xs text-slate-400">
              Terima notifikasi real-time untuk event <code className="text-slate-300">message.encrypted</code>,{' '}
              <code className="text-slate-300">session.started</code>, dan{' '}
              <code className="text-slate-300">typing.updated</code>.
            </p>

            <div className="flex items-center gap-2">
              <input
                type="url"
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
                placeholder="https://api.bisnisanda.com/webhooks/chat"
                className="flex-1 px-3 py-2 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-white/25"
              />
              <button
                type="button"
                onClick={() => void handleAddWebhook()}
                className="px-3.5 py-2 rounded-lg border border-white/[0.12] bg-[#181D27] text-xs font-medium text-slate-100 hover:bg-[#202634] transition-colors whitespace-nowrap shrink-0"
              >
                Tambah
              </button>
            </div>

            {webhookError && <div className="text-xs text-rose-400">{webhookError}</div>}

            <div className="divide-y divide-white/[0.06]">
              {webhooks.length === 0 ? (
                <div className="py-6 text-center text-xs text-slate-500">
                  Belum ada endpoint webhook terdaftar.
                </div>
              ) : (
                webhooks.map((hook) => (
                  <div key={hook.id} className="py-2.5 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-mono text-xs text-slate-200 truncate">{hook.url}</div>
                      <div className="text-[11px] text-slate-500">
                        {hook.events.join(' · ')}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => void handleDeleteWebhook(hook.id)}
                      aria-label={`Hapus webhook ${hook.url}`}
                      className="p-1.5 rounded hover:bg-white/[0.06] text-slate-400 hover:text-rose-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
          </div>
          </div>
        )}

        {mainTab === 'hosting' && (
          <div className="space-y-6">
            {/* Hosting Platform Switcher + Overview */}
            <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <Server className="w-4 h-4 shrink-0" style={{ color: settings.accentColor }} />
                  <div>
                    <h2 className="text-sm font-semibold text-slate-100">
                      Panduan Deploy Server Produksi (Dokumentasi: <code className="font-mono text-slate-300">docs/INSTALASI-HOSTING.md</code>)
                    </h2>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Wajib menggunakan HTTPS (SSL) agar fitur E2EE Web Crypto dan koneksi WebSocket (<code className="text-slate-300">wss://</code>) berjalan di browser pengunjung.
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1 p-1 rounded-lg bg-[#141821] border border-white/[0.06]">
                  {(
                    [
                      { id: 'aapanel', label: 'aaPanel' },
                      { id: 'cpanel', label: 'cPanel' },
                      { id: 'vps', label: 'VPS (PM2 + Nginx)' },
                    ] as const
                  ).map((h) => (
                    <button
                      key={h.id}
                      type="button"
                      onClick={() => setHostingTab(h.id)}
                      className={`px-3 py-1.5 rounded text-xs font-medium transition-colors whitespace-nowrap ${
                        hostingTab === h.id
                          ? 'bg-[#1E2430] text-white'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {h.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* .env Configuration Shared Card */}
              <div className="space-y-2">
                <div className="text-xs font-medium text-slate-200">
                  1. Buat file <code className="font-mono text-slate-300">.env</code> di root project (isi kredensial login admin)
                </div>
                <div className="relative rounded-lg border border-white/[0.08] bg-[#090B0F] p-4">
                  <button
                    type="button"
                    onClick={() => handleCopy('env', envSnippet)}
                    className="absolute top-3 right-3 inline-flex items-center gap-1.5 px-2.5 py-1 rounded border border-white/10 bg-[#141821] text-[11px] font-medium text-slate-300 hover:text-white transition-colors"
                  >
                    {copiedId === 'env' ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                    <span>{copiedId === 'env' ? 'Disalin' : 'Salin'}</span>
                  </button>
                  <pre className="font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed pr-16">
                    {envSnippet}
                  </pre>
                </div>
              </div>
            </div>

            {hostingTab === 'aapanel' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-6 p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-3">
                  <h3 className="text-sm font-semibold text-slate-100">
                    Langkah Instalasi di aaPanel (Disarankan)
                  </h3>
                  <ol className="list-decimal list-inside space-y-2 text-xs text-slate-300 leading-relaxed">
                    <li>
                      Buka <strong>App Store</strong> di aaPanel, pastikan <strong>Nginx</strong> terpasang, lalu buka <strong>Website → Node project → Node version manager</strong> dan pasang <strong>Node.js v22 LTS</strong>.
                    </li>
                    <li>
                      Unggah source code ke <code className="font-mono text-slate-200">/www/wwwroot/chat.domainanda.com</code>, lalu buka Terminal dan jalankan <code className="font-mono text-slate-200">npm install &amp;&amp; npm run build</code>.
                    </li>
                    <li>
                      Klik <strong>Add Node project</strong>, arahkan <strong>Path</strong> ke folder tersebut, isi <strong>Port</strong> <code className="font-mono text-slate-200">3000</code>, lalu gunakan start command <code className="font-mono text-slate-200">./node_modules/.bin/tsx server.ts</code> (atau <code className="font-mono text-slate-200">node server.ts</code> di Node 22.18+).
                    </li>
                    <li>
                      Tambahkan domain Anda (mis. <code className="font-mono text-slate-200">chat.domainanda.com</code>), centang <strong>Auto start on boot</strong>, lalu klik <strong>Settings → SSL → Let&apos;s Encrypt</strong> dan aktifkan <strong>Force HTTPS</strong>.
                    </li>
                    <li>
                      Tambahkan header WebSocket &amp; batas upload 10MB pada config Nginx situs (kode di samping).
                    </li>
                  </ol>
                </div>

                <div className="lg:col-span-6 p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-3">
                  <h3 className="text-sm font-semibold text-slate-100">
                    Konfigurasi Nginx WebSocket &amp; Upload 10MB
                  </h3>
                  <p className="text-xs text-slate-400">
                    Tempel di tab Config / Reverse Proxy aaPanel agar obrolan real-time (<code className="font-mono">/ws</code>) dan upload foto/GIF berjalan lancar.
                  </p>
                  <div className="relative rounded-lg border border-white/[0.08] bg-[#090B0F] p-4">
                    <button
                      type="button"
                      onClick={() => handleCopy('nginx', nginxWsSnippet)}
                      className="absolute top-3 right-3 inline-flex items-center gap-1.5 px-2.5 py-1 rounded border border-white/10 bg-[#141821] text-[11px] font-medium text-slate-300 hover:text-white transition-colors"
                    >
                      {copiedId === 'nginx' ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                      <span>{copiedId === 'nginx' ? 'Disalin' : 'Salin'}</span>
                    </button>
                    <pre className="font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed pr-16">
                      {nginxWsSnippet}
                    </pre>
                  </div>
                </div>
              </div>
            )}

            {hostingTab === 'cpanel' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-6 p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-3">
                  <h3 className="text-sm font-semibold text-slate-100">
                    Langkah Instalasi di cPanel (Setup Node.js App)
                  </h3>
                  <ol className="list-decimal list-inside space-y-2 text-xs text-slate-300 leading-relaxed">
                    <li>
                      Unggah file project (tanpa <code className="font-mono">node_modules</code>) ke folder <code className="font-mono text-slate-200">/home/user/sandichat</code> dan simpan file <code className="font-mono">.env</code>.
                    </li>
                    <li>
                      Masuk ke <strong>Terminal cPanel</strong> dan jalankan perintah build serta bundle <code className="font-mono text-slate-200">server.mjs</code> di samping agar kompatibel penuh dengan CloudLinux Phusion Passenger.
                    </li>
                    <li>
                      Buka <strong>Setup Node.js App → Create Application</strong>: pilih Node <strong>20.x / 22.x</strong>, Mode <strong>Production</strong>, Application root <code className="font-mono text-slate-200">sandichat</code>, dan Startup file <code className="font-mono text-slate-200">server.mjs</code>.
                    </li>
                    <li>
                      Klik <strong>Restart</strong> pada aplikasi dan pastikan AutoSSL (<code className="font-mono">https://</code>) aktif.
                    </li>
                  </ol>
                  <p className="text-[11px] text-amber-300/90 pt-1">
                    Catatan shared hosting: sebagian paket cPanel shared membatasi koneksi WebSocket Upgrade. Jika chat real-time tertahan oleh proxy Apache/LiteSpeed, disarankan memakai VPS + aaPanel.
                  </p>
                </div>

                <div className="lg:col-span-6 p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-3">
                  <h3 className="text-sm font-semibold text-slate-100">
                    Perintah Build &amp; Bundle untuk cPanel
                  </h3>
                  <p className="text-xs text-slate-400">
                    Jalankan di Terminal cPanel agar Passenger dapat langsung mengeksekusi <code className="font-mono">server.mjs</code>.
                  </p>
                  <div className="relative rounded-lg border border-white/[0.08] bg-[#090B0F] p-4">
                    <button
                      type="button"
                      onClick={() => handleCopy('cpanel', cpanelBuildCmd)}
                      className="absolute top-3 right-3 inline-flex items-center gap-1.5 px-2.5 py-1 rounded border border-white/10 bg-[#141821] text-[11px] font-medium text-slate-300 hover:text-white transition-colors"
                    >
                      {copiedId === 'cpanel' ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                      <span>{copiedId === 'cpanel' ? 'Disalin' : 'Salin'}</span>
                    </button>
                    <pre className="font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed pr-16">
                      {cpanelBuildCmd}
                    </pre>
                  </div>
                </div>
              </div>
            )}

            {hostingTab === 'vps' && (
              <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-3">
                <h3 className="text-sm font-semibold text-slate-100">
                  Deploy VPS Ubuntu / Debian dengan PM2 + Nginx + Certbot
                </h3>
                <div className="relative rounded-lg border border-white/[0.08] bg-[#090B0F] p-4">
                  <button
                    type="button"
                    onClick={() =>
                      handleCopy(
                        'vps',
                        `npm install && npm run build\nNODE_ENV=production pm2 start ./node_modules/.bin/tsx --name sandichat -- server.ts\npm2 save && pm2 startup\nsudo certbot --nginx -d chat.domainanda.com`
                      )
                    }
                    className="absolute top-3 right-3 inline-flex items-center gap-1.5 px-2.5 py-1 rounded border border-white/10 bg-[#141821] text-[11px] font-medium text-slate-300 hover:text-white transition-colors"
                  >
                    {copiedId === 'vps' ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                    <span>{copiedId === 'vps' ? 'Disalin' : 'Salin'}</span>
                  </button>
                  <pre className="font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed pr-16">
{`npm install && npm run build
NODE_ENV=production pm2 start ./node_modules/.bin/tsx --name sandichat -- server.ts
pm2 save && pm2 startup
sudo certbot --nginx -d chat.domainanda.com`}
                  </pre>
                </div>
                <p className="text-xs text-slate-400">
                  Gunakan blok konfigurasi Nginx yang sama seperti tab <strong>aaPanel</strong> (dengan <code className="font-mono">Upgrade $http_upgrade</code> dan <code className="font-mono">client_max_body_size 10M;</code>) lalu jalankan <code className="font-mono">certbot --nginx</code> untuk mengaktifkan SSL.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
