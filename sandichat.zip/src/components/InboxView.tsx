import {
  ArrowLeft,
  Check,
  CheckCheck,
  ChevronLeft,
  ChevronRight,
  Eye,
  EyeOff,
  Globe,
  ImagePlus,
  KeyRound,
  Lock,
  Monitor,
  Search,
  Send,
  ShieldCheck,
  Trash2,
  X,
} from 'lucide-react';
import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type FormEvent,
  type KeyboardEvent,
} from 'react';
import type { DecryptedChatMessage } from '../hooks/useLiveChatSocket';
import { MAX_CHAT_IMAGES, validateMultipleImageFiles } from '../lib/imageSecurity';
import type { ImageAttachment, TypingState, VisitorRoom, WidgetSettings } from '../types/chat';
import { TypingIndicator } from './TypingIndicator';

interface InboxViewProps {
  rooms: VisitorRoom[];
  activeRoomId: string;
  onSelectRoom: (roomId: string) => void;
  messages: DecryptedChatMessage[];
  decryptedPreviews: Record<string, string>;
  loadingMessages: boolean;
  typingMap: Record<string, TypingState | null>;
  settings: WidgetSettings;
  workspaceFingerprint: string;
  onSendMessage: (roomId: string, text: string, attachments?: ImageAttachment[]) => Promise<void>;
  onDeleteMessage: (roomId: string, messageId: string) => Promise<void>;
  onEmitTyping: (roomId: string, isTyping: boolean) => void;
  onUpdateRoomStatus: (roomId: string, status: VisitorRoom['status']) => Promise<void>;
}

function formatTime(ts: number): string {
  return new Date(ts).toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatRelativeDuration(startedAt: number): string {
  const diffMin = Math.max(1, Math.floor((Date.now() - startedAt) / 60_000));
  if (diffMin < 60) return `${diffMin}m`;
  const hrs = Math.floor(diffMin / 60);
  return `${hrs}j ${diffMin % 60}m`;
}

export function InboxView({
  rooms,
  activeRoomId,
  onSelectRoom,
  messages,
  decryptedPreviews,
  loadingMessages,
  typingMap,
  settings,
  workspaceFingerprint,
  onSendMessage,
  onDeleteMessage,
  onEmitTyping,
  onUpdateRoomStatus,
}: InboxViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'resolved'>('all');
  const [draft, setDraft] = useState('');
  const [inspectCipher, setInspectCipher] = useState(false);
  const [visitorImgError, setVisitorImgError] = useState(false);
  const [mobileShowThread, setMobileShowThread] = useState(false);
  const [pendingImages, setPendingImages] = useState<ImageAttachment[]>([]);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [validatingImage, setValidatingImage] = useState(false);
  const [lightboxGallery, setLightboxGallery] = useState<{
    images: ImageAttachment[];
    index: number;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const scrollEndRef = useRef<HTMLDivElement | null>(null);

  const activeRoom = useMemo(
    () => rooms.find((r) => r.id === activeRoomId) ?? rooms[0] ?? null,
    [rooms, activeRoomId]
  );

  const filteredRooms = useMemo(() => {
    return rooms.filter((room) => {
      if (statusFilter === 'active' && room.status === 'resolved') return false;
      if (statusFilter === 'resolved' && room.status !== 'resolved') return false;
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        room.visitorName.toLowerCase().includes(q) ||
        room.currentPage.toLowerCase().includes(q) ||
        room.location.toLowerCase().includes(q)
      );
    });
  }, [rooms, statusFilter, searchQuery]);

  const activeTyping = activeRoom ? typingMap[activeRoom.id] : null;

  useEffect(() => {
    setVisitorImgError(false);
    setPendingImages([]);
    setUploadError(null);
  }, [activeRoom?.id]);

  useEffect(() => {
    scrollEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, activeTyping?.isTyping]);

  const handleImageSelect = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const selectedFiles = Array.from(files);
    e.target.value = '';
    setUploadError(null);
    setValidatingImage(true);
    try {
      const { accepted, errors } = await validateMultipleImageFiles(
        selectedFiles,
        pendingImages.length,
        MAX_CHAT_IMAGES
      );
      if (accepted.length > 0) {
        setPendingImages((prev) => [...prev, ...accepted].slice(0, MAX_CHAT_IMAGES));
      }
      if (errors.length > 0) {
        setUploadError(errors[0]);
      }
    } finally {
      setValidatingImage(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!activeRoom || (!draft.trim() && pendingImages.length === 0)) return;
    const text = draft;
    const atts = pendingImages;
    setDraft('');
    setPendingImages([]);
    setUploadError(null);
    onEmitTyping(activeRoom.id, false);
    await onSendMessage(activeRoom.id, text, atts);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      void handleSubmit(e);
    }
  };

  const handleDraftChange = (val: string) => {
    setDraft(val);
    if (activeRoom) {
      onEmitTyping(activeRoom.id, val.trim().length > 0);
    }
  };

  return (
    <div className="flex h-full min-h-0 bg-[#090A0D]">
      {/* Column 1: Conversation Queue */}
      <section
        className={`${
          mobileShowThread ? 'hidden md:flex' : 'flex'
        } w-full md:w-[310px] shrink-0 border-r border-white/[0.08] bg-[#0B0D12] flex-col min-h-0`}
        aria-label="Daftar Percakapan"
      >
        <div className="p-4 border-b border-white/[0.07] space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari pengunjung atau halaman..."
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-white/[0.08] bg-[#11141B] text-[13px] text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-white/25"
            />
          </div>

          <div className="flex items-center gap-1 p-1 rounded-lg bg-[#11141B] border border-white/[0.06]">
            {(
              [
                { id: 'all', label: 'Semua' },
                { id: 'active', label: 'Aktif' },
                { id: 'resolved', label: 'Selesai' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setStatusFilter(tab.id)}
                className={`flex-1 py-1.5 px-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  statusFilter === tab.id
                    ? 'bg-[#1B202B] text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-white/[0.05]">
          {filteredRooms.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">
              Tidak ada percakapan yang cocok dengan filter saat ini.
            </div>
          ) : (
            filteredRooms.map((room) => {
              const isSelected = activeRoom?.id === room.id;
              const isTyping = Boolean(typingMap[room.id]?.isTyping);
              return (
                <button
                  key={room.id}
                  type="button"
                  onClick={() => {
                    onSelectRoom(room.id);
                    setMobileShowThread(true);
                  }}
                  className={`w-full text-left px-4 py-3.5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-white/25 ${
                    isSelected ? 'bg-[#141821]' : 'hover:bg-white/[0.025]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                          room.online
                            ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.75)]'
                            : 'bg-rose-500'
                        }`}
                        title={room.online ? 'Online' : 'Offline'}
                      />
                      <span className="text-[13px] font-semibold text-slate-100 truncate">
                        {room.visitorName}
                      </span>
                    </div>
                    <span className="text-[11px] font-mono tabular-nums text-slate-500 shrink-0">
                      {formatTime(room.lastActivityAt)}
                    </span>
                  </div>

                  <div className="mt-1 flex items-center justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      {isTyping ? (
                        <TypingIndicator
                          style={settings.typingAnimation}
                          accentColor={settings.accentColor}
                          compact
                        />
                      ) : (
                        <p className="text-xs text-slate-300 truncate">
                          {decryptedPreviews[room.id] ||
                            (room.messageCount === 0
                              ? 'Belum ada pesan dari pengunjung'
                              : room.lastMessagePreview)}
                        </p>
                      )}
                    </div>
                    {room.unreadCount > 0 && (
                      <span
                        className="text-[11px] font-mono tabular-nums font-semibold px-1.5 py-0.5 rounded shrink-0"
                        style={{
                          backgroundColor: `${settings.accentColor}26`,
                          color: settings.accentColor,
                        }}
                      >
                        {room.unreadCount}
                      </span>
                    )}
                  </div>

                  <div className="mt-1.5 flex items-center gap-1.5 text-[11px] text-slate-500 truncate">
                    <span
                      className={`font-medium ${
                        room.online ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {room.online ? 'Online' : 'Offline'}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="truncate">{room.currentPage}</span>
                    <span aria-hidden="true">·</span>
                    <span>{room.e2eeVerified ? 'E2EE' : 'Standar'}</span>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </section>

      {/* Column 2: Active Conversation Stream */}
      <section
        className={`${
          mobileShowThread ? 'flex' : 'hidden md:flex'
        } flex-1 flex-col min-w-0 min-h-0 bg-[#090A0D]`}
      >
        {activeRoom ? (
          <>
            {/* Thread Header */}
            <header className="px-4 md:px-6 py-3.5 border-b border-white/[0.08] bg-[#0B0D12] flex items-center justify-between gap-4">
              <div className="flex items-center gap-3 min-w-0">
                <button
                  type="button"
                  onClick={() => setMobileShowThread(false)}
                  aria-label="Kembali ke daftar percakapan"
                  className="md:hidden p-1.5 rounded-lg border border-white/10 text-slate-300 hover:text-white"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <div className="min-w-0">
                  <div className="flex items-center gap-2.5">
                    <h2 className="text-[15px] font-semibold text-slate-100 truncate">
                      {activeRoom.visitorName}
                    </h2>
                    <span
                      className={`inline-flex items-center gap-1.5 text-xs font-medium whitespace-nowrap shrink-0 ${
                        activeRoom.online ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      <span
                        className={`w-2 h-2 rounded-full ${
                          activeRoom.online
                            ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.75)]'
                            : 'bg-rose-500'
                        }`}
                      />
                      {activeRoom.online ? 'Online' : 'Offline'}
                    </span>
                  </div>
                  <div className="mt-0.5 flex items-center gap-2 text-xs text-slate-400">
                    <Lock className="w-3.5 h-3.5 shrink-0" style={{ color: settings.accentColor }} />
                    <span className="truncate">
                      Enkripsi End-to-End ECDH P-256 · {activeRoom.currentPage}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setInspectCipher((prev) => !prev)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/[0.1] bg-[#12151D] text-xs font-medium text-slate-300 hover:text-white hover:border-white/20 transition-colors whitespace-nowrap shrink-0"
                >
                  {inspectCipher ? (
                    <EyeOff className="w-3.5 h-3.5" />
                  ) : (
                    <Eye className="w-3.5 h-3.5" />
                  )}
                  <span>{inspectCipher ? 'Sembunyikan Ciphertext' : 'Inspeksi Ciphertext'}</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    void onUpdateRoomStatus(
                      activeRoom.id,
                      activeRoom.status === 'resolved' ? 'active' : 'resolved'
                    )
                  }
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/[0.1] bg-[#12151D] text-xs font-medium text-slate-200 hover:bg-[#191D28] transition-colors whitespace-nowrap shrink-0"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>
                    {activeRoom.status === 'resolved' ? 'Buka Kembali' : 'Tandai Selesai'}
                  </span>
                </button>
              </div>
            </header>

            {/* Message Feed */}
            <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
              <div className="mx-auto max-w-xl py-2.5 px-4 rounded-lg border border-white/[0.06] bg-[#0F1218] text-center text-xs text-slate-400">
                Pesan live pada sesi ini dienkripsi di browser pengirim dengan kunci AES-256-GCM.
                Server hanya meneruskan ciphertext tanpa akses plaintext.
              </div>

              {loadingMessages ? (
                <div className="space-y-3 py-4">
                  <div className="h-12 w-2/3 rounded-xl bg-white/[0.04] animate-pulse" />
                  <div className="h-12 w-1/2 ml-auto rounded-xl bg-white/[0.04] animate-pulse" />
                </div>
              ) : messages.length === 0 ? (
                <div className="py-16 text-center text-sm text-slate-500">
                  Belum ada pesan di ruangan ini. Mulai percakapan terenkripsi di bawah.
                </div>
              ) : (
                messages.map((msg) => {
                  const isAgent = msg.senderRole === 'agent' || msg.senderRole === 'api';
                  return (
                    <div
                      key={msg.id}
                      className={`group flex flex-col ${isAgent ? 'items-end' : 'items-start'}`}
                    >
                      <div className="mb-1 flex items-center gap-2 text-[11px] text-slate-500">
                        <span className="font-medium text-slate-400">{msg.senderName}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums">{formatTime(msg.timestamp)}</span>
                        {msg.encrypted && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="inline-flex items-center gap-1 text-slate-400">
                              <Lock className="w-3 h-3" style={{ color: settings.accentColor }} />
                              AES-GCM
                            </span>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => void onDeleteMessage(activeRoom.id, msg.id)}
                          title="Hapus pesan"
                          aria-label="Hapus pesan"
                          className="ml-1 inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 opacity-75 sm:opacity-0 sm:group-hover:opacity-100 focus:opacity-100 transition-all"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Hapus</span>
                        </button>
                      </div>

                      <div
                        className={`max-w-[74%] px-4 py-2.5 rounded-xl border text-[14px] leading-relaxed ${
                          isAgent
                            ? 'text-slate-100 border-white/[0.1]'
                            : 'bg-[#13161F] text-slate-100 border-white/[0.07]'
                        }`}
                        style={
                          isAgent
                            ? {
                                backgroundColor: `${settings.accentColor}16`,
                                borderColor: `${settings.accentColor}38`,
                              }
                            : undefined
                        }
                      >
                        {msg.displayAttachments.length > 0 && (
                          <div
                            className={`mb-2 grid gap-1.5 ${
                              msg.displayAttachments.length === 1 ? 'grid-cols-1' : 'grid-cols-2'
                            }`}
                          >
                            {msg.displayAttachments.map((att, idx) => (
                              <button
                                key={`${msg.id}-att-${idx}`}
                                type="button"
                                onClick={() =>
                                  setLightboxGallery({
                                    images: msg.displayAttachments,
                                    index: idx,
                                  })
                                }
                                className="block overflow-hidden rounded-lg border border-white/10 focus:outline-none focus:ring-2 focus:ring-white/30 bg-black/40"
                              >
                                <img
                                  src={att.dataUrl}
                                  alt={att.fileName}
                                  className={
                                    msg.displayAttachments.length === 1
                                      ? 'max-h-56 w-full object-contain'
                                      : 'h-32 w-full object-cover'
                                  }
                                />
                              </button>
                            ))}
                          </div>
                        )}
                        {msg.displayText && (
                          <p className="whitespace-pre-wrap break-words">{msg.displayText}</p>
                        )}

                        {inspectCipher && msg.encrypted && msg.ciphertext && (
                          <div className="mt-2.5 pt-2 border-t border-white/[0.08] font-mono text-[11px] text-slate-400 space-y-1 break-all">
                            <div>
                              <span className="text-slate-500">IV: </span>
                              {msg.iv}
                            </div>
                            <div>
                              <span className="text-slate-500">Ciphertext: </span>
                              {msg.ciphertext}
                            </div>
                          </div>
                        )}
                      </div>

                      {isAgent && settings.showReadReceipts && (
                        <div className="mt-1 flex items-center gap-1 text-[11px] text-slate-500">
                          <CheckCheck
                            className="w-3.5 h-3.5"
                            style={msg.read ? { color: settings.accentColor } : undefined}
                          />
                          <span>{msg.read ? 'Dibaca' : 'Terkirim'}</span>
                        </div>
                      )}
                    </div>
                  );
                })
              )}

              {activeTyping?.isTyping && (
                <div className="pt-1">
                  <TypingIndicator
                    style={settings.typingAnimation}
                    accentColor={settings.accentColor}
                    senderName={activeTyping.senderName}
                  />
                </div>
              )}

              <div ref={scrollEndRef} />
            </div>

            {/* Composer */}
            <form
              onSubmit={(e) => void handleSubmit(e)}
              className="p-4 border-t border-white/[0.08] bg-[#0B0D12] space-y-2.5"
            >
              {uploadError && (
                <div className="px-3 py-2 rounded-lg border border-rose-500/30 bg-rose-500/10 text-xs text-rose-300 flex items-center justify-between gap-2">
                  <span>{uploadError}</span>
                  <button
                    type="button"
                    onClick={() => setUploadError(null)}
                    aria-label="Tutup pesan error"
                    className="text-rose-300 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {pendingImages.length > 0 && (
                <div className="p-2.5 rounded-lg border border-white/[0.08] bg-[#12161F] space-y-2">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>
                      {pendingImages.length}/{MAX_CHAT_IMAGES} gambar terverifikasi siap dikirim
                    </span>
                    <button
                      type="button"
                      onClick={() => setPendingImages([])}
                      className="text-slate-400 hover:text-white"
                    >
                      Hapus semua
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {pendingImages.map((img, idx) => (
                      <div
                        key={`${img.fileName}-${idx}`}
                        className="relative group w-16 h-16 rounded-lg overflow-hidden border border-white/10 bg-black/40"
                      >
                        <img
                          src={img.dataUrl}
                          alt={img.fileName}
                          className="w-full h-full object-cover"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            setPendingImages((prev) => prev.filter((_, i) => i !== idx))
                          }
                          aria-label={`Hapus ${img.fileName}`}
                          className="absolute top-1 right-1 p-0.5 rounded-full bg-black/75 text-slate-200 hover:text-white"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="rounded-xl border border-white/[0.09] bg-[#11141B] focus-within:border-white/25 transition-colors">
                <textarea
                  rows={2}
                  value={draft}
                  onChange={(e) => handleDraftChange(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={
                    activeRoom.visitorPublicKey
                      ? 'Ketik balasan (akan dienkripsi AES-256-GCM sebelum dikirim)...'
                      : 'Ketik balasan ke pengunjung...'
                  }
                  className="w-full px-4 pt-3 pb-2 bg-transparent text-sm text-slate-100 placeholder:text-slate-500 resize-none focus:outline-none"
                />
                <div className="px-3 pb-2.5 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 min-w-0">
                    <input
                      ref={fileInputRef}
                      type="file"
                      multiple
                      accept="image/png,image/jpeg,image/webp,image/gif"
                      onChange={(e) => void handleImageSelect(e)}
                      className="hidden"
                    />
                    <button
                      type="button"
                      disabled={validatingImage || pendingImages.length >= MAX_CHAT_IMAGES}
                      onClick={() => fileInputRef.current?.click()}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-white/[0.08] bg-[#171B24] text-xs text-slate-200 hover:border-white/20 transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
                    >
                      <ImagePlus className="w-3.5 h-3.5" style={{ color: settings.accentColor }} />
                      <span>
                        {validatingImage
                          ? 'Memvalidasi...'
                          : pendingImages.length > 0
                            ? `Gambar (${pendingImages.length}/${MAX_CHAT_IMAGES})`
                            : 'Gambar'}
                      </span>
                    </button>
                    <ShieldCheck
                      className="w-3.5 h-3.5 shrink-0 hidden sm:block"
                      style={{ color: settings.accentColor }}
                    />
                    <span className="truncate hidden sm:inline">
                      {activeRoom.visitorPublicKey
                        ? 'Kunci sesi ECDH P-256 terverifikasi'
                        : 'Mode arsip / menunggu handshake sesi langsung'}
                    </span>
                  </div>
                  <button
                    type="submit"
                    disabled={!draft.trim() && pendingImages.length === 0}
                    className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold text-slate-950 transition-opacity disabled:opacity-40 whitespace-nowrap shrink-0"
                    style={{ backgroundColor: settings.accentColor }}
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Kirim Pesan</span>
                  </button>
                </div>
              </div>
            </form>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-sm text-slate-500">
            Pilih percakapan di sebelah kiri untuk mulai memantau atau membalas.
          </div>
        )}
      </section>

      {/* Column 3: Visitor Activity & E2EE Verification Inspector */}
      {activeRoom && (
        <aside
          className="hidden xl:flex w-[280px] shrink-0 border-l border-white/[0.08] bg-[#0B0D12] flex-col overflow-y-auto p-5 space-y-6"
          aria-label="Detail Pengunjung dan Keamanan"
        >
          <div className="flex items-center gap-3">
            <div className="relative shrink-0">
              {activeRoom.visitorAvatar && !visitorImgError ? (
                <img
                  src={activeRoom.visitorAvatar}
                  alt={activeRoom.visitorName}
                  referrerPolicy="no-referrer"
                  onError={() => setVisitorImgError(true)}
                  className="w-11 h-11 rounded-xl object-cover border border-white/10"
                />
              ) : (
                <div className="w-11 h-11 rounded-xl bg-[#161A24] border border-white/10 flex items-center justify-center text-sm font-semibold text-slate-200">
                  {activeRoom.visitorName
                    .split(' ')
                    .slice(0, 2)
                    .map((p) => p[0])
                    .join('')
                    .toUpperCase()}
                </div>
              )}
              <span
                className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#0B0D12] ${
                  activeRoom.online ? 'bg-emerald-400' : 'bg-rose-500'
                }`}
                title={activeRoom.online ? 'Online' : 'Offline'}
              />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-semibold text-slate-100 truncate">
                {activeRoom.visitorName}
              </div>
              <div className="text-xs text-slate-400 truncate">
                {activeRoom.visitorEmail || 'Pengunjung Widget'}
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-white/[0.07] space-y-3">
            <h3 className="text-xs font-semibold text-slate-300">Aktivitas Sesi</h3>
            <dl className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between gap-2">
                <dt className="text-slate-500">Status</dt>
                <dd
                  className={`inline-flex items-center gap-1.5 font-medium ${
                    activeRoom.online ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      activeRoom.online ? 'bg-emerald-400' : 'bg-rose-500'
                    }`}
                  />
                  <span>{activeRoom.online ? 'Online' : 'Offline'}</span>
                </dd>
              </div>
              <div className="flex items-center justify-between gap-2">
                <dt className="text-slate-500 flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5" />
                  <span>Halaman</span>
                </dt>
                <dd className="font-mono text-slate-200 truncate max-w-[140px]">
                  {activeRoom.currentPage}
                </dd>
              </div>
              <div className="flex items-center justify-between gap-2">
                <dt className="text-slate-500 flex items-center gap-1.5">
                  <Monitor className="w-3.5 h-3.5" />
                  <span>Perangkat</span>
                </dt>
                <dd className="text-slate-200 truncate">
                  {activeRoom.device} · {activeRoom.browser}
                </dd>
              </div>
              <div className="flex items-center justify-between gap-2">
                <dt className="text-slate-500">Lokasi</dt>
                <dd className="text-slate-200">{activeRoom.location}</dd>
              </div>
              <div className="flex items-center justify-between gap-2">
                <dt className="text-slate-500">Durasi Sesi</dt>
                <dd className="font-mono tabular-nums text-slate-200">
                  {formatRelativeDuration(activeRoom.startedAt)}
                </dd>
              </div>
              <div className="flex items-center justify-between gap-2">
                <dt className="text-slate-500">Total Pesan</dt>
                <dd className="font-mono tabular-nums text-slate-200">
                  {activeRoom.messageCount}
                </dd>
              </div>
            </dl>
          </div>

          {activeRoom.customAttributes && Object.keys(activeRoom.customAttributes).length > 0 && (
            <div className="pt-4 border-t border-white/[0.07] space-y-3">
              <h3 className="text-xs font-semibold text-slate-300">Data Formulir Kustom</h3>
              <dl className="space-y-2 text-xs">
                {Object.entries(activeRoom.customAttributes).map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between gap-2">
                    <dt className="text-slate-500 capitalize truncate">{k.replace(/_/g, ' ')}</dt>
                    <dd className="text-slate-100 font-medium truncate max-w-[145px]">{v}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}

          <div className="pt-4 border-t border-white/[0.07] space-y-3">
            <div className="flex items-center gap-2">
              <KeyRound className="w-3.5 h-3.5" style={{ color: settings.accentColor }} />
              <h3 className="text-xs font-semibold text-slate-300">Verifikasi Kunci E2EE</h3>
            </div>

            <div className="p-3 rounded-lg border border-white/[0.07] bg-[#11141B] space-y-2.5">
              <div>
                <div className="text-[11px] text-slate-500">Sidik Jari Pengunjung</div>
                <div className="mt-0.5 font-mono text-[11px] text-slate-200 tracking-wide">
                  {activeRoom.keyFingerprint || 'Belum ada handshake'}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500">Sidik Jari Workspace</div>
                <div className="mt-0.5 font-mono text-[11px] text-slate-200 tracking-wide">
                  {workspaceFingerprint || 'Menghasilkan kunci...'}
                </div>
              </div>
              <div className="pt-2 border-t border-white/[0.06] text-[11px] text-slate-400 leading-relaxed">
                Pertukaran kunci ECDH kurva P-256 dengan cipher simetris AES-256-GCM per pesan.
              </div>
            </div>
          </div>
        </aside>
      )}

      {lightboxGallery && lightboxGallery.images[lightboxGallery.index] && (
        <div
          className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-6"
          onClick={() => setLightboxGallery(null)}
        >
          <div
            className="relative max-w-3xl max-h-[88vh] rounded-xl border border-white/15 bg-[#0C0E13] p-3 space-y-2"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between gap-4 px-1">
              <span className="text-xs font-mono text-slate-300 truncate">
                {lightboxGallery.images[lightboxGallery.index].fileName}
                {lightboxGallery.images.length > 1
                  ? ` (${lightboxGallery.index + 1}/${lightboxGallery.images.length})`
                  : ''}
              </span>
              <div className="flex items-center gap-1">
                {lightboxGallery.images.length > 1 && (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        setLightboxGallery((prev) =>
                          prev
                            ? {
                                ...prev,
                                index:
                                  (prev.index - 1 + prev.images.length) % prev.images.length,
                              }
                            : null
                        )
                      }
                      aria-label="Gambar sebelumnya"
                      className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setLightboxGallery((prev) =>
                          prev
                            ? {
                                ...prev,
                                index: (prev.index + 1) % prev.images.length,
                              }
                            : null
                        )
                      }
                      aria-label="Gambar berikutnya"
                      className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => setLightboxGallery(null)}
                  aria-label="Tutup pratinjau gambar"
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
            <img
              src={lightboxGallery.images[lightboxGallery.index].dataUrl}
              alt={lightboxGallery.images[lightboxGallery.index].fileName}
              className="max-h-[76vh] max-w-full rounded-lg object-contain"
            />
          </div>
        </div>
      )}
    </div>
  );
}
