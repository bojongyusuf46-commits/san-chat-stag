import type { TypingAnimationStyle } from '../types/chat';

interface TypingIndicatorProps {
  style: TypingAnimationStyle;
  accentColor: string;
  senderName?: string;
  compact?: boolean;
}

export function TypingIndicator({
  style,
  accentColor,
  senderName,
  compact = false,
}: TypingIndicatorProps) {
  const renderAnimation = () => {
    if (style === 'wave') {
      return (
        <span className="inline-flex items-center gap-1" aria-hidden="true">
          <span
            className="h-1.5 w-1.5 rounded-full animate-typing-wave"
            style={{ backgroundColor: accentColor, animationDelay: '0ms' }}
          />
          <span
            className="h-1.5 w-1.5 rounded-full animate-typing-wave"
            style={{ backgroundColor: accentColor, animationDelay: '150ms' }}
          />
          <span
            className="h-1.5 w-1.5 rounded-full animate-typing-wave"
            style={{ backgroundColor: accentColor, animationDelay: '300ms' }}
          />
        </span>
      );
    }

    if (style === 'pulse-bar') {
      return (
        <span className="inline-flex items-end gap-[3px] h-3.5" aria-hidden="true">
          <span
            className="w-[2.5px] h-3 rounded-full animate-typing-bar"
            style={{ backgroundColor: accentColor, animationDelay: '0ms' }}
          />
          <span
            className="w-[2.5px] h-3.5 rounded-full animate-typing-bar"
            style={{ backgroundColor: accentColor, animationDelay: '140ms' }}
          />
          <span
            className="w-[2.5px] h-2.5 rounded-full animate-typing-bar"
            style={{ backgroundColor: accentColor, animationDelay: '280ms' }}
          />
          <span
            className="w-[2.5px] h-3 rounded-full animate-typing-bar"
            style={{ backgroundColor: accentColor, animationDelay: '420ms' }}
          />
        </span>
      );
    }

    if (style === 'dots') {
      return (
        <span className="inline-flex items-center gap-1" aria-hidden="true">
          <span
            className="h-1.5 w-1.5 rounded-full animate-typing-dot"
            style={{ backgroundColor: accentColor, animationDelay: '0ms' }}
          />
          <span
            className="h-1.5 w-1.5 rounded-full animate-typing-dot"
            style={{ backgroundColor: accentColor, animationDelay: '180ms' }}
          />
          <span
            className="h-1.5 w-1.5 rounded-full animate-typing-dot"
            style={{ backgroundColor: accentColor, animationDelay: '360ms' }}
          />
        </span>
      );
    }

    return (
      <span
        className="inline-block h-3 w-[2px] rounded-full animate-pulse"
        style={{ backgroundColor: accentColor }}
        aria-hidden="true"
      />
    );
  };

  if (compact) {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs text-slate-300">
        {renderAnimation()}
        <span>sedang mengetik</span>
      </span>
    );
  }

  return (
    <div
      className="inline-flex items-center gap-2.5 px-3.5 py-2 rounded-xl border border-white/[0.08] bg-[#14171F] text-xs text-slate-300 transition-opacity duration-150"
      role="status"
      aria-live="polite"
    >
      {renderAnimation()}
      <span className="truncate max-w-[240px]">
        {senderName ? `${senderName} sedang mengetik` : 'Sedang mengetik'}
      </span>
    </div>
  );
}
