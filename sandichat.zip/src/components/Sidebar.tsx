import {
  Activity,
  Code2,
  Lock,
  LogOut,
  MessageSquare,
  SlidersHorizontal,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { useState } from 'react';
import type {
  AdminAuthUser,
  AnalyticsSnapshot,
  NavSection,
  TypingState,
  VisitorRoom,
  WidgetSettings,
} from '../types/chat';
import { BrandLogo } from './BrandLogo';

interface SidebarProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  settings: WidgetSettings;
  connected: boolean;
  rooms: VisitorRoom[];
  typingMap: Record<string, TypingState | null>;
  analytics: AnalyticsSnapshot | null;
  onJumpToRoom: (roomId: string) => void;
  adminUser?: AdminAuthUser | null;
  onLogout?: () => void;
}

const NAV_GROUPS: Array<{
  title: string;
  items: Array<{
    id: NavSection;
    label: string;
    icon: typeof MessageSquare;
  }>;
}> = [
  {
    title: 'Ruang Kerja',
    items: [
      { id: 'inbox', label: 'Live Inbox', icon: MessageSquare },
      { id: 'analytics', label: 'Analitik & Aktivitas', icon: Activity },
    ],
  },
  {
    title: 'Pengaturan & Pasang',
    items: [
      { id: 'studio', label: 'Studio Widget', icon: SlidersHorizontal },
      { id: 'api', label: 'Pasang & API', icon: Code2 },
    ],
  },
];

export function Sidebar({
  activeSection,
  onSelectSection,
  settings,
  connected,
  rooms,
  typingMap,
  analytics,
  onJumpToRoom,
  adminUser,
  onLogout,
}: SidebarProps) {
  const [avatarError, setAvatarError] = useState(false);

  const totalUnread = rooms.reduce((acc, r) => acc + r.unreadCount, 0);
  const onlineRooms = rooms.filter((r) => r.online);
  const typingRooms = rooms.filter((r) => Boolean(typingMap[r.id]?.isTyping));

  return (
    <aside className="w-[260px] shrink-0 border-r border-white/[0.08] bg-[#0C0E13] flex flex-col h-full select-none">
      {/* Brand Header */}
      <div className="px-5 py-4 border-b border-white/[0.08] flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <BrandLogo
            logoStyle={settings.logoStyle}
            accentColor={settings.accentColor}
            customLogoUrl={settings.customLogoUrl}
            brandName={settings.brandName}
            size={30}
          />
          <span className="text-[15px] font-semibold tracking-tight text-slate-100 truncate">
            {settings.brandName}
          </span>
        </div>
        <span
          className="inline-flex items-center gap-1 text-[11px] font-mono text-slate-400 shrink-0"
          title={connected ? 'WebSocket terhubung' : 'Menghubungkan ulang'}
        >
          {connected ? (
            <Wifi className="w-3.5 h-3.5 text-emerald-400" />
          ) : (
            <WifiOff className="w-3.5 h-3.5 text-amber-400" />
          )}
        </span>
      </div>

      {/* Grouped Navigation */}
      <nav className="px-3 py-4 space-y-4" aria-label="Navigasi Utama">
        {NAV_GROUPS.map((group) => (
          <div key={group.title} className="space-y-1">
            <div className="px-3 text-[11px] font-medium uppercase tracking-wider text-slate-500">
              {group.title}
            </div>
            {group.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectSection(item.id)}
                  className={`w-full flex items-center justify-between gap-2.5 px-3 py-2 rounded-lg text-[13px] font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/25 ${
                    isActive
                      ? 'bg-white/[0.08] text-white'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.03]'
                  }`}
                >
                  <span className="flex items-center gap-2.5 min-w-0">
                    <Icon
                      className="w-4 h-4 shrink-0"
                      style={isActive ? { color: settings.accentColor } : undefined}
                    />
                    <span className="truncate">{item.label}</span>
                  </span>
                  {item.id === 'inbox' && totalUnread > 0 && (
                    <span
                      className="text-[11px] font-mono tabular-nums font-semibold px-1.5 py-0.5 rounded"
                      style={{
                        backgroundColor: `${settings.accentColor}22`,
                        color: settings.accentColor,
                      }}
                    >
                      {totalUnread}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Comprehensive User Activity & Message Analytics Sidebar Monitor */}
      <div className="px-4 py-4 border-t border-white/[0.07] flex-1 overflow-y-auto space-y-5">
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[12px] font-medium text-slate-400">
              Ringkasan Aktivitas
            </span>
            <span className="text-[11px] font-mono tabular-nums text-slate-500">
              Live
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="p-2.5 rounded-lg border border-white/[0.06] bg-[#11141B]">
              <div className="text-[11px] text-slate-400">Pengunjung Aktif</div>
              <div className="mt-0.5 text-lg font-semibold tabular-nums text-slate-100">
                {analytics?.activeVisitors ?? onlineRooms.length}
              </div>
            </div>
            <div className="p-2.5 rounded-lg border border-white/[0.06] bg-[#11141B]">
              <div className="text-[11px] text-slate-400">Enkripsi E2EE</div>
              <div className="mt-0.5 text-lg font-semibold tabular-nums text-slate-100">
                {analytics ? `${analytics.encryptionRate}%` : '100%'}
              </div>
            </div>
          </div>

          <div className="mt-2 p-2.5 rounded-lg border border-white/[0.06] bg-[#11141B] flex items-center justify-between text-xs">
            <span className="text-slate-400">Total Pesan</span>
            <span className="font-mono tabular-nums text-slate-200 font-medium">
              {analytics?.totalMessages ?? 0} pesan
            </span>
          </div>
        </div>

        {/* Live Visitor Session Feed */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[12px] font-medium text-slate-400">
              Sesi Pengunjung ({onlineRooms.length})
            </span>
            {typingRooms.length > 0 && (
              <span
                className="text-[11px] font-medium tabular-nums"
                style={{ color: settings.accentColor }}
              >
                {typingRooms.length} mengetik
              </span>
            )}
          </div>

          <div className="space-y-1.5">
            {rooms.slice(0, 5).map((room) => {
              const isTyping = Boolean(typingMap[room.id]?.isTyping);
              return (
                <button
                  key={room.id}
                  type="button"
                  onClick={() => onJumpToRoom(room.id)}
                  className="w-full text-left px-2.5 py-2 rounded-lg border border-transparent hover:border-white/[0.08] hover:bg-white/[0.03] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/20"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span
                        className={`w-2 h-2 rounded-full shrink-0 ${
                          room.online
                            ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.7)]'
                            : 'bg-rose-500'
                        }`}
                      />
                      <span className="text-xs font-medium text-slate-200 truncate">
                        {room.visitorName}
                      </span>
                    </div>
                    <span
                      className={`text-[11px] font-mono shrink-0 ${
                        room.online ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {room.online ? 'Online' : 'Offline'}
                    </span>
                  </div>
                  <div className="mt-0.5 flex items-center gap-1.5 text-[11px] text-slate-500 truncate">
                    {room.e2eeVerified && (
                      <Lock className="w-3 h-3 shrink-0 text-slate-400" />
                    )}
                    {isTyping ? (
                      <span style={{ color: settings.accentColor }}>
                        Sedang mengetik...
                      </span>
                    ) : (
                      <span className="truncate">
                        {room.currentPage} · {room.location}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Operator Profile Footer */}
      <div className="px-4 py-3.5 border-t border-white/[0.08] flex items-center gap-3">
        {settings.agentAvatarUrl && !avatarError ? (
          <img
            src={settings.agentAvatarUrl}
            alt={settings.agentName || adminUser?.name || 'Admin'}
            referrerPolicy="no-referrer"
            onError={() => setAvatarError(true)}
            className="w-8 h-8 rounded-full object-cover border border-white/10 shrink-0"
          />
        ) : (
          <div className="w-8 h-8 rounded-full bg-[#1A1E28] border border-white/10 flex items-center justify-center text-xs font-semibold text-slate-200 shrink-0">
            {(settings.agentName || adminUser?.name || 'CP')
              .split(' ')
              .slice(0, 2)
              .map((p) => p[0])
              .join('')
              .toUpperCase()}
          </div>
        )}
        <div className="min-w-0 flex-1">
          <div className="text-xs font-medium text-slate-100 truncate">
            {settings.agentName || adminUser?.name || 'Citra Pratama'}
          </div>
          <div className="text-[11px] text-slate-400 truncate">
            {adminUser?.email || 'Admin Support · Online'}
          </div>
        </div>
        {onLogout && (
          <button
            type="button"
            onClick={onLogout}
            title="Keluar dari dashboard"
            aria-label="Keluar dari dashboard"
            className="p-1.5 rounded-lg border border-white/[0.08] bg-[#131720] text-slate-400 hover:text-rose-300 hover:border-rose-500/30 transition-colors shrink-0"
          >
            <LogOut className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </aside>
  );
}
