import { useState } from 'react';
import type { LogoStyle } from '../types/chat';

interface BrandLogoProps {
  logoStyle: LogoStyle;
  accentColor: string;
  customLogoUrl?: string;
  brandName?: string;
  size?: number;
}

export function BrandLogo({
  logoStyle,
  accentColor,
  customLogoUrl,
  brandName = 'SandiChat',
  size = 32,
}: BrandLogoProps) {
  const [imgError, setImgError] = useState(false);

  if (logoStyle === 'custom' && customLogoUrl && !imgError) {
    return (
      <div
        className="flex items-center justify-center overflow-hidden rounded-lg border border-white/10 bg-[#14171F] shrink-0"
        style={{ width: size, height: size }}
      >
        <img
          src={customLogoUrl}
          alt={`${brandName} logo`}
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          className="h-full w-full object-cover"
        />
      </div>
    );
  }

  return (
    <div
      className="flex items-center justify-center rounded-lg border border-white/10 bg-[#14171F] shrink-0"
      style={{
        width: size,
        height: size,
        boxShadow: `inset 0 0 0 1px ${accentColor}22`,
      }}
      aria-hidden="true"
    >
      {logoStyle === 'waveform' && (
        <svg
          width={size * 0.56}
          height={size * 0.56}
          viewBox="0 0 24 24"
          fill="none"
        >
          <path
            d="M4 12V10M8 16V8M12 19V5M16 15V9M20 13V11"
            stroke={accentColor}
            strokeWidth="2.2"
            strokeLinecap="round"
          />
        </svg>
      )}
      {logoStyle === 'hexagon' && (
        <svg
          width={size * 0.56}
          height={size * 0.56}
          viewBox="0 0 24 24"
          fill="none"
        >
          <path
            d="M12 3L20 7.5V16.5L12 21L4 16.5V7.5L12 3Z"
            stroke={accentColor}
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <circle cx="12" cy="12" r="2.5" fill={accentColor} />
        </svg>
      )}
      {(logoStyle === 'shield' || (logoStyle === 'custom' && (!customLogoUrl || imgError))) && (
        <svg
          width={size * 0.56}
          height={size * 0.56}
          viewBox="0 0 24 24"
          fill="none"
        >
          <path
            d="M12 3L4.5 6.2V11.5C4.5 16.3 7.7 20.6 12 22C16.3 20.6 19.5 16.3 19.5 11.5V6.2L12 3Z"
            stroke={accentColor}
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <path
            d="M9.5 12L11.2 13.7L14.8 10.1"
            stroke={accentColor}
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )}
    </div>
  );
}
