import { ArrowRight, Check, Copy, Eye, EyeOff, KeyRound, Lock, Mail, MessageSquare, ShieldCheck, SlidersHorizontal, User } from 'lucide-react';
import { useState, type FormEvent } from 'react';
import type { AdminAuthUser, AuthStatusResponse } from '../types/chat';
import { BrandLogo } from './BrandLogo';

interface AdminLoginViewProps {
  authStatus: AuthStatusResponse;
  onAuthenticated: (token: string, user: AdminAuthUser) => void;
}

function generateRandomSimulationPassword(length = 12): string {
  const charset = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$';
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => charset[b % charset.length]).join('');
}

export function AdminLoginView({ authStatus, onAuthenticated }: AdminLoginViewProps) {
  const isSetupMode = authStatus.setupRequired;

  const [name, setName] = useState('Citra Pratama');
  const [email, setEmail] = useState(authStatus.expectedEmailHint || '');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [simFilled, setSimFilled] = useState(false);
  const [copiedSimCreds, setCopiedSimCreds] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFillSimulation = () => {
    const generatedPass = generateRandomSimulationPassword(12);
    setName('Citra Pratama');
    setEmail('admin@sandichat.local');
    setPassword(generatedPass);
    setConfirmPassword(generatedPass);
    setShowPassword(true);
    setSimFilled(true);
    setError(null);
  };

  const handleCopySimCreds = () => {
    void navigator.clipboard.writeText(`Email: ${email}\nPassword: ${password}`);
    setCopiedSimCreds(true);
    window.setTimeout(() => setCopiedSimCreds(false), 1800);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanEmail = email.trim();
    if (!cleanEmail) {
      setError('Masukkan alamat email admin.');
      return;
    }
    if (!password) {
      setError('Masukkan kata sandi admin.');
      return;
    }

    if (isSetupMode) {
      if (password.length < 8) {
        setError('Kata sandi minimal 8 karakter.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Konfirmasi kata sandi tidak cocok.');
        return;
      }
    }

    setSubmitting(true);
    try {
      const endpoint = isSetupMode ? '/api/auth/setup' : '/api/auth/login';
      const payload = isSetupMode
        ? { name: name.trim() || 'Admin Support', email: cleanEmail, password }
        : { email: cleanEmail, password };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = (await res.json()) as {
        token?: string;
        user?: AdminAuthUser;
        error?: string;
      };

      if (!res.ok || !data.token || !data.user) {
        setError(data.error || 'Gagal memproses autentikasi.');
        return;
      }

      onAuthenticated(data.token, data.user);
    } catch {
      setError('Tidak dapat terhubung ke server. Periksa koneksi jaringan Anda.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#090A0D] text-slate-100 flex flex-col justify-between p-6 lg:p-10">
      {/* Top Minimal Header */}
      <header className="max-w-5xl w-full mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <BrandLogo logoStyle="shield" accentColor="#10B981" size={28} />
          <span className="text-base font-semibold tracking-tight text-slate-100 whitespace-nowrap">
            SandiChat
          </span>
        </div>
        <span className="text-xs text-slate-400 whitespace-nowrap">
          Konsol Admin Livechat
        </span>
      </header>

      {/* Main Split Content */}
      <main className="max-w-5xl w-full mx-auto my-auto py-10 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
        {/* Left: Workspace Value Summary */}
        <section className="lg:col-span-6 space-y-6">
          <div className="space-y-3">
            <p className="text-xs font-medium text-emerald-400 tracking-wide">
              Akses Ruang Kerja Operator
            </p>
            <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight text-slate-50 leading-tight max-w-lg">
              Kelola percakapan pelanggan dan widget livechat dalam satu konsol.
            </h1>
            <p className="text-sm text-slate-400 leading-relaxed max-w-md">
              Masuk untuk memantau Live Inbox real-time, menyesuaikan tampilan widget & foto CS, serta menyalin skrip embed untuk website Anda.
            </p>
          </div>

          <div className="space-y-4 pt-2 border-t border-white/[0.08] max-w-md">
            <div className="flex items-start gap-3">
              <MessageSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-medium text-slate-200">
                  Live Inbox & Enkripsi End-to-End
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Balas pesan dan lampiran gambar terenkripsi langsung dari browser operator.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <SlidersHorizontal className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-medium text-slate-200">
                  Studio Kustomisasi Widget & Formulir
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Atur foto agen, launcher GIF, tema warna, hingga field input pra-chat secara instan.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-medium text-slate-200">
                  Proteksi Sesi Terverifikasi Server
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Widget pengunjung tetap terbuka untuk pelanggan sementara panel admin terlindungi token sesi.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Right: Login / First-Run Setup Panel */}
        <section className="lg:col-span-6">
          <div className="w-full max-w-md lg:ml-auto p-6 sm:p-8 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-6">
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h2 className="text-lg font-semibold text-slate-100">
                  {isSetupMode ? 'Buat Akun / Simulasi Admin' : 'Masuk ke Dashboard Admin'}
                </h2>
                {isSetupMode && (
                  <button
                    type="button"
                    onClick={handleFillSimulation}
                    className="px-2.5 py-1.5 rounded-lg border border-emerald-500/35 bg-emerald-500/10 text-xs font-medium text-emerald-300 hover:bg-emerald-500/20 transition-colors whitespace-nowrap shrink-0"
                  >
                    Isi Cepat Simulasi
                  </button>
                )}
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {isSetupMode
                  ? 'Kata sandi server (.env) belum diatur. Isi kredensial pilihan Anda atau klik "Isi Cepat Simulasi" untuk langsung mencoba dashboard.'
                  : 'Masukkan email dan kata sandi administrator untuk membuka Live Inbox dan pengaturan widget.'}
              </p>
            </div>

            {isSetupMode && simFilled && (
              <div className="px-3.5 py-2.5 rounded-lg border border-emerald-500/30 bg-emerald-500/10 flex items-center justify-between gap-2 text-xs text-emerald-200">
                <span>
                  Data simulasi terisi otomatis. Simpan sandi ini jika ingin login ulang setelah keluar.
                </span>
                <button
                  type="button"
                  onClick={handleCopySimCreds}
                  className="inline-flex items-center gap-1 px-2 py-1 rounded border border-emerald-400/30 bg-black/25 text-[11px] font-medium text-emerald-200 hover:text-white shrink-0"
                >
                  {copiedSimCreds ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedSimCreds ? 'Disalin' : 'Salin'}</span>
                </button>
              </div>
            )}

            {authStatus.envManaged && (
              <div className="px-3.5 py-2.5 rounded-lg border border-white/[0.08] bg-[#141822] flex items-start gap-2.5 text-xs text-slate-300">
                <KeyRound className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  Autentikasi dikelola oleh variabel lingkungan server (<code className="font-mono text-slate-200">ADMIN_PASSCODE</code>).
                </span>
              </div>
            )}

            {error && (
              <div
                role="alert"
                className="px-3.5 py-2.5 rounded-lg border border-rose-500/35 bg-rose-500/10 text-xs text-rose-200"
              >
                {error}
              </div>
            )}

            <form onSubmit={(e) => void handleSubmit(e)} className="space-y-4">
              {isSetupMode && (
                <div>
                  <label htmlFor="admin-name" className="block text-xs font-medium text-slate-300 mb-1.5">
                    Nama Operator / CS
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      id="admin-name"
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Contoh: Citra Pratama"
                      className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-white/[0.1] bg-[#141821] text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-emerald-400/70"
                    />
                  </div>
                </div>
              )}

              <div>
                <label htmlFor="admin-email" className="block text-xs font-medium text-slate-300 mb-1.5">
                  {isSetupMode ? 'Email Administrator' : 'Email / ID Administrator'}
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    id="admin-email"
                    type={isSetupMode ? 'email' : 'text'}
                    autoComplete="username"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={isSetupMode ? 'admin@domainanda.com' : 'admin@domainanda.com atau ID admin'}
                    className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-white/[0.1] bg-[#141821] text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-emerald-400/70"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="admin-password" className="block text-xs font-medium text-slate-300 mb-1.5">
                  Kata Sandi
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    id="admin-password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete={isSetupMode ? 'new-password' : 'current-password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={isSetupMode ? 'Minimal 8 karakter' : 'Masukkan kata sandi'}
                    className="w-full pl-9 pr-10 py-2.5 rounded-lg border border-white/[0.1] bg-[#141821] text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-emerald-400/70"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((prev) => !prev)}
                    aria-label={showPassword ? 'Sembunyikan kata sandi' : 'Lihat kata sandi'}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-200"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {isSetupMode && (
                <div>
                  <label
                    htmlFor="admin-password-confirm"
                    className="block text-xs font-medium text-slate-300 mb-1.5"
                  >
                    Ulangi Kata Sandi
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      id="admin-password-confirm"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="new-password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Ulangi kata sandi admin"
                      className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-white/[0.1] bg-[#141821] text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-emerald-400/70"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 px-4 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-sm font-semibold transition-colors disabled:opacity-50 inline-flex items-center justify-center gap-2 whitespace-nowrap"
              >
                <span>
                  {submitting
                    ? 'Memverifikasi...'
                    : isSetupMode
                      ? 'Simpan & Masuk Dashboard'
                      : 'Masuk Dashboard'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        </section>
      </main>

      {/* Quiet Footer */}
      <footer className="max-w-5xl w-full mx-auto pt-4 border-t border-white/[0.06] flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
        <span>SandiChat · Realtime Encrypted Livechat</span>
        <span>Untuk produksi di aaPanel / cPanel, atur ADMIN_EMAIL &amp; ADMIN_PASSCODE pada .env</span>
      </footer>
    </div>
  );
}
