import { Lock, Search, ShieldCheck, Users } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { AnalyticsSnapshot, TypingState, VisitorRoom, WidgetSettings } from '../types/chat';

interface AnalyticsViewProps {
  analytics: AnalyticsSnapshot | null;
  rooms: VisitorRoom[];
  typingMap: Record<string, TypingState | null>;
  settings: WidgetSettings;
  onJumpToRoom: (roomId: string) => void;
}

export function AnalyticsView({
  analytics,
  rooms,
  typingMap,
  settings,
  onJumpToRoom,
}: AnalyticsViewProps) {
  const [hoveredHourIdx, setHoveredHourIdx] = useState<number | null>(null);
  const [tableFilter, setTableFilter] = useState('');

  const filteredRooms = useMemo(() => {
    const q = tableFilter.trim().toLowerCase();
    if (!q) return rooms;
    return rooms.filter(
      (r) =>
        r.visitorName.toLowerCase().includes(q) ||
        r.currentPage.toLowerCase().includes(q) ||
        r.location.toLowerCase().includes(q)
    );
  }, [rooms, tableFilter]);

  if (!analytics) {
    return (
      <div className="p-8 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="h-24 rounded-xl bg-white/[0.04] animate-pulse" />
          ))}
        </div>
        <div className="h-72 rounded-xl bg-white/[0.04] animate-pulse" />
      </div>
    );
  }

  const maxBucket = Math.max(
    ...analytics.hourlyVolume.map((b) => b.totalMessages),
    10
  );

  return (
    <div className="h-full overflow-y-auto p-6 lg:p-8 space-y-6 bg-[#090A0D]">
      {/* Top 4-Column Metric Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218]">
          <div className="text-xs text-slate-400">Total Pesan Terkirim</div>
          <div className="mt-2 text-2xl font-semibold tabular-nums text-slate-100">
            {analytics.totalMessages}
          </div>
          <div className="mt-1 text-xs text-slate-500">
            Dari {analytics.totalRooms} sesi percakapan
          </div>
        </div>

        <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218]">
          <div className="text-xs text-slate-400">Cakupan Enkripsi E2EE</div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-semibold tabular-nums text-slate-100">
              {analytics.encryptionRate}%
            </span>
            <span className="text-xs font-mono tabular-nums text-slate-400">
              ({analytics.encryptedMessages} AES-GCM)
            </span>
          </div>
          <div className="mt-1 text-xs text-slate-500">
            ECDH P-256 · Zero-Knowledge Relay
          </div>
        </div>

        <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218]">
          <div className="text-xs text-slate-400">Pengunjung Online Saat Ini</div>
          <div className="mt-2 text-2xl font-semibold tabular-nums text-slate-100">
            {analytics.activeVisitors}
          </div>
          <div className="mt-1 text-xs text-slate-500">
            Dipantau langsung via WebSocket
          </div>
        </div>

        <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218]">
          <div className="text-xs text-slate-400">Rata-rata Respon Pertama</div>
          <div className="mt-2 text-2xl font-semibold tabular-nums text-slate-100">
            {analytics.avgFirstResponseSec} dtk
          </div>
          <div className="mt-1 text-xs text-slate-500">
            Target SLA operasional &lt; 30 detik
          </div>
        </div>
      </div>

      {/* Volume Chart + Page Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] flex flex-col justify-between">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
            <div>
              <h2 className="text-sm font-semibold text-slate-100">
                Volume Pesan & Traffic Terenkripsi (10 Jam Terakhir)
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Perbandingan total pesan masuk/keluar dengan pesan terenkripsi E2EE
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs text-slate-400">
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-slate-600" />
                Total Pesan
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span
                  className="w-2.5 h-2.5 rounded-sm"
                  style={{ backgroundColor: settings.accentColor }}
                />
                Terenkripsi E2EE
              </span>
            </div>
          </div>

          <div className="relative h-56 flex items-end gap-2.5 pt-6">
            {analytics.hourlyVolume.map((bucket, idx) => {
              const totalPct = Math.max(8, Math.round((bucket.totalMessages / maxBucket) * 100));
              const encPct = Math.max(4, Math.round((bucket.encryptedMessages / maxBucket) * 100));
              const isHovered = hoveredHourIdx === idx;
              return (
                <div
                  key={bucket.hour}
                  onMouseEnter={() => setHoveredHourIdx(idx)}
                  onMouseLeave={() => setHoveredHourIdx(null)}
                  className="flex-1 h-full flex flex-col items-center justify-end gap-2 group relative cursor-default"
                >
                  {isHovered && (
                    <div className="absolute -top-2 z-10 px-2.5 py-1.5 rounded-lg border border-white/15 bg-[#181C26] text-[11px] font-mono tabular-nums text-slate-100 whitespace-nowrap shadow-lg">
                      {bucket.hour} · {bucket.totalMessages} total · {bucket.encryptedMessages} E2EE
                    </div>
                  )}
                  <div className="w-full h-full flex items-end justify-center gap-1">
                    <div
                      className="w-2.5 rounded-t bg-slate-700/80 transition-all duration-150"
                      style={{ height: `${totalPct}%` }}
                    />
                    <div
                      className="w-2.5 rounded-t transition-all duration-150"
                      style={{
                        height: `${encPct}%`,
                        backgroundColor: settings.accentColor,
                        opacity: isHovered ? 1 : 0.85,
                      }}
                    />
                  </div>
                  <span className="text-[11px] font-mono tabular-nums text-slate-500">
                    {bucket.hour}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="p-5 rounded-xl border border-white/[0.08] bg-[#0F1218] space-y-5">
          <div>
            <h2 className="text-sm font-semibold text-slate-100">Halaman Paling Aktif</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Lokasi URL saat pengunjung memulai sesi chat
            </p>
          </div>

          <div className="space-y-3">
            {analytics.topPages.map((page) => (
              <div key={page.path} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-mono text-slate-200 truncate">{page.path}</span>
                  <span className="font-mono tabular-nums text-slate-400 shrink-0">
                    {page.visitors} sesi · {page.share}%
                  </span>
                </div>
                <div className="h-1.5 w-full rounded-full bg-white/[0.06] overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${page.share}%`,
                      backgroundColor: settings.accentColor,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-white/[0.07]">
            <h3 className="text-xs font-semibold text-slate-300 mb-3">Distribusi Perangkat</h3>
            <div className="space-y-2">
              {analytics.deviceSplit.map((item) => (
                <div key={item.label} className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">{item.label}</span>
                  <span className="font-mono tabular-nums text-slate-200">
                    {item.count} ({item.percentage}%)
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Live User Activity Data Grid */}
      <div className="rounded-xl border border-white/[0.08] bg-[#0F1218] overflow-hidden">
        <div className="px-5 py-4 border-b border-white/[0.08] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-slate-400" />
            <h2 className="text-sm font-semibold text-slate-100">
              Pemantauan Aktivitas Pengguna Real-Time
            </h2>
          </div>
          <div className="relative w-64">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={tableFilter}
              onChange={(e) => setTableFilter(e.target.value)}
              placeholder="Filter pengunjung..."
              className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-white/[0.08] bg-[#141821] text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-white/25"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/[0.07] text-[11px] font-medium text-slate-400 bg-[#12151D]">
                <th className="py-2.5 px-5">Pengunjung</th>
                <th className="py-2.5 px-4">Halaman Aktif</th>
                <th className="py-2.5 px-4">Lokasi & Perangkat</th>
                <th className="py-2.5 px-4">Status Sesi</th>
                <th className="py-2.5 px-4">Keamanan</th>
                <th className="py-2.5 px-5 text-right">Pesan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.05] text-xs">
              {filteredRooms.map((room) => {
                const isTyping = Boolean(typingMap[room.id]?.isTyping);
                return (
                  <tr
                    key={room.id}
                    onClick={() => onJumpToRoom(room.id)}
                    className="hover:bg-white/[0.03] cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-5">
                      <div className="font-medium text-slate-100">{room.visitorName}</div>
                      <div className="text-[11px] text-slate-500">
                        {room.visitorEmail || room.id}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-300">{room.currentPage}</td>
                    <td className="py-3 px-4 text-slate-400">
                      {room.location} · {room.device} ({room.browser})
                    </td>
                    <td className="py-3 px-4">
                      {isTyping ? (
                        <span
                          className="font-medium"
                          style={{ color: settings.accentColor }}
                        >
                          Sedang mengetik...
                        </span>
                      ) : (
                        <span
                          className={`inline-flex items-center gap-1.5 font-medium ${
                            room.online ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          <span
                            className={`w-2 h-2 rounded-full ${
                              room.online ? 'bg-emerald-400' : 'bg-rose-500'
                            }`}
                          />
                          {room.online ? 'Online' : 'Offline'}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center gap-1.5 text-slate-300">
                        {room.e2eeVerified ? (
                          <>
                            <ShieldCheck
                              className="w-3.5 h-3.5"
                              style={{ color: settings.accentColor }}
                            />
                            <span>ECDH P-256</span>
                          </>
                        ) : (
                          <>
                            <Lock className="w-3.5 h-3.5 text-slate-500" />
                            <span>Standar</span>
                          </>
                        )}
                      </span>
                    </td>
                    <td className="py-3 px-5 text-right font-mono tabular-nums text-slate-200">
                      {room.messageCount}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
