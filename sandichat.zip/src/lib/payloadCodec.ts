import type { ImageAttachment } from '../types/chat';

interface StructuredChatPayload {
  __scv: 2;
  text: string;
  attachment?: ImageAttachment;
  attachments?: ImageAttachment[];
}

const SAFE_DATA_URL_RE = /^data:image\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$/;

function isValidAttachment(att: unknown): att is ImageAttachment {
  if (!att || typeof att !== 'object') return false;
  const candidate = att as Partial<ImageAttachment>;
  return (
    typeof candidate.dataUrl === 'string' &&
    SAFE_DATA_URL_RE.test(candidate.dataUrl) &&
    typeof candidate.fileName === 'string'
  );
}

export function encodeChatPayload(
  text: string,
  attachments?: ImageAttachment[]
): string {
  const valid = (attachments ?? []).filter(isValidAttachment).slice(0, 6);
  if (valid.length === 0) return text;
  const payload: StructuredChatPayload = {
    __scv: 2,
    text,
    attachments: valid,
    attachment: valid[0],
  };
  return JSON.stringify(payload);
}

export function decodeChatPayload(raw: string): {
  text: string;
  attachments: ImageAttachment[];
} {
  if (raw.startsWith('{') && raw.includes('"__scv":2')) {
    try {
      const parsed = JSON.parse(raw) as Partial<StructuredChatPayload>;
      if (parsed.__scv === 2) {
        const list: ImageAttachment[] = [];
        if (Array.isArray(parsed.attachments)) {
          for (const item of parsed.attachments) {
            if (isValidAttachment(item)) {
              list.push(item);
            }
          }
        }
        if (list.length === 0 && isValidAttachment(parsed.attachment)) {
          list.push(parsed.attachment);
        }
        return {
          text: typeof parsed.text === 'string' ? parsed.text : '',
          attachments: list,
        };
      }
    } catch {
      // Fallback to raw string
    }
  }
  return { text: raw, attachments: [] };
}
