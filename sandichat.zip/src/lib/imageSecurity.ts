import type { ImageAttachment } from '../types/chat';

export type AllowedImageMime = 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif';

const ALLOWED_MIMES = new Set<string>([
  'image/png',
  'image/jpeg',
  'image/webp',
  'image/gif',
]);

const ALLOWED_EXTENSIONS = new Set<string>(['png', 'jpg', 'jpeg', 'webp', 'gif']);

const DANGEROUS_EXTENSIONS = new Set<string>([
  'php',
  'phtml',
  'php3',
  'php4',
  'php5',
  'php7',
  'php8',
  'phps',
  'phar',
  'asp',
  'aspx',
  'jsp',
  'jspx',
  'cgi',
  'pl',
  'py',
  'rb',
  'sh',
  'bash',
  'zsh',
  'exe',
  'dll',
  'bat',
  'cmd',
  'msi',
  'js',
  'mjs',
  'cjs',
  'ts',
  'jsx',
  'tsx',
  'html',
  'htm',
  'xhtml',
  'svg',
  'svgz',
  'xml',
  'htaccess',
]);

const POLYGLOT_PATTERNS = [
  '<?php',
  '<?=',
  '<script',
  '</script',
  '<svg',
  'javascript:',
  'onerror=',
  'onload=',
  'shell_exec(',
  'passthru(',
  'base64_decode(',
];

const MAX_RAW_BYTES = 2 * 1024 * 1024; // 2 MB

export function validateFileName(fileName: string): string | null {
  if (!fileName || fileName.includes('\0') || fileName.includes('/') || fileName.includes('\\')) {
    return 'Nama file tidak valid.';
  }
  const parts = fileName.toLowerCase().split('.');
  if (parts.length < 2) {
    return 'File harus memiliki ekstensi gambar yang valid (.png, .jpg, .webp, .gif).';
  }
  const finalExt = parts[parts.length - 1];
  if (!ALLOWED_EXTENSIONS.has(finalExt)) {
    return `Format .${finalExt} tidak diizinkan. Hanya gambar PNG, JPG, WebP, atau GIF yang diperbolehkan.`;
  }
  for (let i = 1; i < parts.length; i++) {
    if (DANGEROUS_EXTENSIONS.has(parts[i])) {
      return `File ditolak karena terdeteksi ekstensi berbahaya (.${parts[i]}).`;
    }
  }
  return null;
}

export function detectImageMagicBytes(bytes: Uint8Array): AllowedImageMime | null {
  if (bytes.length < 12) return null;

  // PNG: 89 50 4E 47 0D 0A 1A 0A
  if (
    bytes[0] === 0x89 &&
    bytes[1] === 0x50 &&
    bytes[2] === 0x4e &&
    bytes[3] === 0x47 &&
    bytes[4] === 0x0d &&
    bytes[5] === 0x0a &&
    bytes[6] === 0x1a &&
    bytes[7] === 0x0a
  ) {
    return 'image/png';
  }

  // JPEG: FF D8 FF
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    return 'image/jpeg';
  }

  // GIF: GIF87a or GIF89a
  if (
    bytes[0] === 0x47 &&
    bytes[1] === 0x49 &&
    bytes[2] === 0x46 &&
    bytes[3] === 0x38 &&
    (bytes[4] === 0x37 || bytes[4] === 0x39) &&
    bytes[5] === 0x61
  ) {
    return 'image/gif';
  }

  // WebP: RIFF....WEBP
  if (
    bytes[0] === 0x52 &&
    bytes[1] === 0x49 &&
    bytes[2] === 0x46 &&
    bytes[3] === 0x46 &&
    bytes[8] === 0x57 &&
    bytes[9] === 0x45 &&
    bytes[10] === 0x42 &&
    bytes[11] === 0x50
  ) {
    return 'image/webp';
  }

  return null;
}

export function containsDangerousSignature(bytes: Uint8Array): boolean {
  // Decode first 256KB + last 64KB as Latin-1 to catch embedded PHP/script polyglots
  const decoder = new TextDecoder('latin1');
  const head = decoder.decode(bytes.subarray(0, Math.min(bytes.length, 262144))).toLowerCase();
  const tailStart = Math.max(0, bytes.length - 65536);
  const tail =
    tailStart > 0 ? decoder.decode(bytes.subarray(tailStart)).toLowerCase() : '';

  for (const pattern of POLYGLOT_PATTERNS) {
    if (head.includes(pattern) || tail.includes(pattern)) {
      return true;
    }
  }
  return false;
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...chunk);
  }
  return btoa(binary);
}

async function reencodeRasterImage(
  blob: Blob,
  targetMime: 'image/png' | 'image/jpeg' | 'image/webp'
): Promise<{ dataUrl: string; width: number; height: number }> {
  const objectUrl = URL.createObjectURL(blob);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('File bukan gambar yang valid atau rusak.'));
      el.src = objectUrl;
    });

    const maxDim = 1280;
    let width = img.naturalWidth;
    let height = img.naturalHeight;
    if (width <= 0 || height <= 0) {
      throw new Error('Dimensi gambar tidak valid.');
    }

    if (width > maxDim || height > maxDim) {
      const scale = Math.min(maxDim / width, maxDim / height);
      width = Math.round(width * scale);
      height = Math.round(height * scale);
    }

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Gagal memproses kanvas gambar.');
    }
    ctx.drawImage(img, 0, 0, width, height);

    const dataUrl = canvas.toDataURL(
      targetMime,
      targetMime === 'image/png' ? undefined : 0.86
    );
    return { dataUrl, width, height };
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

export async function validateAndSanitizeImageFile(file: File): Promise<ImageAttachment> {
  const nameErr = validateFileName(file.name);
  if (nameErr) {
    throw new Error(nameErr);
  }

  if (file.size <= 0 || file.size > MAX_RAW_BYTES) {
    throw new Error('Ukuran gambar maksimal 2 MB.');
  }

  if (file.type && !ALLOWED_MIMES.has(file.type.toLowerCase())) {
    throw new Error(
      `Tipe MIME "${file.type}" ditolak. Hanya gambar PNG, JPEG, WebP, atau GIF yang diizinkan.`
    );
  }

  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);

  const detectedMime = detectImageMagicBytes(bytes);
  if (!detectedMime) {
    throw new Error(
      'Header biner (magic bytes) file tidak cocok dengan format gambar asli. Upload ditolak.'
    );
  }

  if (containsDangerousSignature(bytes)) {
    throw new Error(
      'Terdeteksi pola skrip/injeksi berbahaya di dalam file. Upload diblokir demi keamanan.'
    );
  }

  // Server-side verification check (magic bytes + filename + polyglot inspection)
  const rawBase64 = arrayBufferToBase64(buffer);
  const verifyRes = await fetch('/api/media/verify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      fileName: file.name,
      mimeType: detectedMime,
      base64Data: rawBase64,
    }),
  });

  if (!verifyRes.ok) {
    const errBody = (await verifyRes.json().catch(() => ({}))) as { error?: string };
    throw new Error(errBody.error || 'Validasi keamanan gambar di server gagal.');
  }

  // Re-encode PNG/JPEG/WebP via Canvas to strip EXIF & any trailing polyglot bytes
  if (detectedMime === 'image/gif') {
    const dataUrl = `data:image/gif;base64,${rawBase64}`;
    return {
      dataUrl,
      fileName: file.name,
      mimeType: 'image/gif',
      sizeBytes: file.size,
    };
  }

  const sanitized = await reencodeRasterImage(
    new Blob([bytes], { type: detectedMime }),
    detectedMime
  );
  const approxBytes = Math.round((sanitized.dataUrl.length * 3) / 4);

  return {
    dataUrl: sanitized.dataUrl,
    fileName: file.name,
    mimeType: detectedMime,
    sizeBytes: approxBytes,
    width: sanitized.width,
    height: sanitized.height,
  };
}

export const MAX_CHAT_IMAGES = 5;

export async function validateMultipleImageFiles(
  fileList: FileList | File[],
  existingCount = 0,
  maxImages = MAX_CHAT_IMAGES
): Promise<{ accepted: ImageAttachment[]; errors: string[] }> {
  const files = Array.from(fileList);
  const remainingSlots = Math.max(0, maxImages - existingCount);
  const errors: string[] = [];
  const accepted: ImageAttachment[] = [];

  if (files.length === 0) {
    return { accepted, errors };
  }

  if (remainingSlots <= 0) {
    errors.push(`Maksimal ${maxImages} gambar dapat dilampirkan dalam satu pesan.`);
    return { accepted, errors };
  }

  const targetFiles = files.slice(0, remainingSlots);
  if (files.length > remainingSlots) {
    errors.push(
      `Hanya ${remainingSlots} gambar pertama yang diproses (maksimal ${maxImages} gambar per pesan).`
    );
  }

  for (const file of targetFiles) {
    try {
      const sanitized = await validateAndSanitizeImageFile(file);
      accepted.push(sanitized);
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'File gambar ditolak.';
      errors.push(`${file.name}: ${reason}`);
    }
  }

  return { accepted, errors };
}
