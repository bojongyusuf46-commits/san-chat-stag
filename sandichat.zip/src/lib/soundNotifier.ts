import type { NotificationSoundPreset } from '../types/chat';

let sharedAudioCtx: AudioContext | null = null;
let unlockListenersInstalled = false;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const Ctx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return null;
  if (!sharedAudioCtx || sharedAudioCtx.state === 'closed') {
    sharedAudioCtx = new Ctx();
  }
  return sharedAudioCtx;
}

export function installAudioUnlockListeners(): void {
  if (typeof window === 'undefined' || unlockListenersInstalled) return;
  unlockListenersInstalled = true;

  const unlock = () => {
    const ctx = getAudioContext();
    if (ctx && ctx.state === 'suspended') {
      void ctx.resume().catch(() => undefined);
    }
  };

  window.addEventListener('pointerdown', unlock, { passive: true });
  window.addEventListener('keydown', unlock, { passive: true });
}

function scheduleTone(
  ctx: AudioContext,
  startOffsetSec: number,
  durationSec: number,
  startFreq: number,
  endFreq: number,
  type: OscillatorType,
  peakGain: number
): void {
  const now = ctx.currentTime + startOffsetSec;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = type;
  osc.frequency.setValueAtTime(startFreq, now);
  if (endFreq !== startFreq) {
    osc.frequency.exponentialRampToValueAtTime(Math.max(40, endFreq), now + durationSec);
  }

  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.linearRampToValueAtTime(peakGain, now + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + durationSec);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + durationSec + 0.02);
}

export async function playNotificationSound(
  preset: NotificationSoundPreset = 'chime',
  volumePercent = 70
): Promise<void> {
  const ctx = getAudioContext();
  if (!ctx) return;

  if (ctx.state === 'suspended') {
    try {
      await ctx.resume();
    } catch {
      return;
    }
  }

  const clamped = Math.min(100, Math.max(0, volumePercent));
  if (clamped === 0) return;
  const masterGain = (clamped / 100) * 0.28;

  try {
    switch (preset) {
      case 'pop':
        scheduleTone(ctx, 0, 0.11, 460, 920, 'sine', masterGain);
        scheduleTone(ctx, 0.09, 0.12, 740, 1180, 'sine', masterGain * 0.65);
        break;

      case 'bell':
        scheduleTone(ctx, 0, 0.28, 880, 880, 'sine', masterGain * 0.9);
        scheduleTone(ctx, 0, 0.22, 1318.5, 1318.5, 'triangle', masterGain * 0.35);
        scheduleTone(ctx, 0.12, 0.32, 1046.5, 1046.5, 'sine', masterGain * 0.75);
        break;

      case 'subtle':
        scheduleTone(ctx, 0, 0.14, 587.33, 659.25, 'sine', masterGain * 0.65);
        break;

      case 'chime':
      default:
        // Pleasant C6 -> E6 two-note chime
        scheduleTone(ctx, 0, 0.18, 523.25, 523.25, 'sine', masterGain * 0.85);
        scheduleTone(ctx, 0.09, 0.26, 659.25, 659.25, 'sine', masterGain);
        scheduleTone(ctx, 0.09, 0.22, 1318.5, 1318.5, 'triangle', masterGain * 0.22);
        break;
    }
  } catch {
    // Ignore audio scheduling errors in restricted browser contexts
  }
}
