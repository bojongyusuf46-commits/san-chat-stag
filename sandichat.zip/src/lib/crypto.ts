const ECDH_PARAMS: EcKeyGenParams = {
  name: 'ECDH',
  namedCurve: 'P-256',
};

function bufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

export async function generateECDHKeyPair(): Promise<CryptoKeyPair> {
  return window.crypto.subtle.generateKey(ECDH_PARAMS, true, ['deriveKey']);
}

export async function exportPublicKeyJWK(publicKey: CryptoKey): Promise<JsonWebKey> {
  return window.crypto.subtle.exportKey('jwk', publicKey);
}

export async function exportPrivateKeyJWK(privateKey: CryptoKey): Promise<JsonWebKey> {
  return window.crypto.subtle.exportKey('jwk', privateKey);
}

export async function importPublicKeyJWK(jwk: JsonWebKey): Promise<CryptoKey> {
  return window.crypto.subtle.importKey('jwk', jwk, ECDH_PARAMS, true, []);
}

export async function importPrivateKeyJWK(jwk: JsonWebKey): Promise<CryptoKey> {
  return window.crypto.subtle.importKey('jwk', jwk, ECDH_PARAMS, true, ['deriveKey']);
}

export async function computeKeyFingerprint(jwk: JsonWebKey): Promise<string> {
  const canonical = JSON.stringify({
    crv: jwk.crv,
    kty: jwk.kty,
    x: jwk.x,
    y: jwk.y,
  });
  const encoded = new TextEncoder().encode(canonical);
  const digest = await window.crypto.subtle.digest('SHA-256', encoded);
  const hex = Array.from(new Uint8Array(digest))
    .slice(0, 8)
    .map((b) => b.toString(16).padStart(2, '0').toUpperCase())
    .join('');
  return `${hex.slice(0, 4)} · ${hex.slice(4, 8)} · ${hex.slice(8, 12)} · ${hex.slice(12, 16)}`;
}

export async function deriveSharedAESKey(
  privateKey: CryptoKey,
  peerPublicKey: CryptoKey
): Promise<CryptoKey> {
  return window.crypto.subtle.deriveKey(
    {
      name: 'ECDH',
      public: peerPublicKey,
    },
    privateKey,
    {
      name: 'AES-GCM',
      length: 256,
    },
    false,
    ['encrypt', 'decrypt']
  );
}

export async function encryptWithAESGCM(
  aesKey: CryptoKey,
  plaintext: string
): Promise<{ ciphertext: string; iv: string }> {
  const ivBytes = window.crypto.getRandomValues(new Uint8Array(12));
  const encoded = new TextEncoder().encode(plaintext);
  const encryptedBuffer = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv: ivBytes,
    },
    aesKey,
    encoded
  );
  return {
    ciphertext: bufferToBase64(encryptedBuffer),
    iv: bufferToBase64(ivBytes.buffer),
  };
}

export async function decryptWithAESGCM(
  aesKey: CryptoKey,
  ciphertext: string,
  iv: string
): Promise<string> {
  const cipherBuffer = base64ToBuffer(ciphertext);
  const ivBuffer = base64ToBuffer(iv);
  const decryptedBuffer = await window.crypto.subtle.decrypt(
    {
      name: 'AES-GCM',
      iv: new Uint8Array(ivBuffer),
    },
    aesKey,
    cipherBuffer
  );
  return new TextDecoder().decode(decryptedBuffer);
}

export interface StoredIdentity {
  keyPair: CryptoKeyPair;
  publicJwk: JsonWebKey;
  fingerprint: string;
}

const WORKSPACE_STORAGE_KEY = 'sandichat_workspace_ecdh_v1';

export async function getOrCreateWorkspaceIdentity(): Promise<StoredIdentity> {
  try {
    const raw = localStorage.getItem(WORKSPACE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as {
        publicJwk: JsonWebKey;
        privateJwk: JsonWebKey;
      };
      const publicKey = await importPublicKeyJWK(parsed.publicJwk);
      const privateKey = await importPrivateKeyJWK(parsed.privateJwk);
      const fingerprint = await computeKeyFingerprint(parsed.publicJwk);
      return {
        keyPair: { publicKey, privateKey },
        publicJwk: parsed.publicJwk,
        fingerprint,
      };
    }
  } catch {
    // Regenerate fresh keypair if stored data is invalid
  }

  const keyPair = await generateECDHKeyPair();
  const publicJwk = await exportPublicKeyJWK(keyPair.publicKey);
  const privateJwk = await exportPrivateKeyJWK(keyPair.privateKey);
  const fingerprint = await computeKeyFingerprint(publicJwk);

  try {
    localStorage.setItem(
      WORKSPACE_STORAGE_KEY,
      JSON.stringify({ publicJwk, privateJwk })
    );
  } catch {
    // Storage quota unavailable
  }

  return { keyPair, publicJwk, fingerprint };
}

export async function getOrCreateVisitorIdentity(roomId: string): Promise<StoredIdentity> {
  const storageKey = `sandichat_visitor_ecdh_${roomId}`;
  try {
    const raw = sessionStorage.getItem(storageKey);
    if (raw) {
      const parsed = JSON.parse(raw) as {
        publicJwk: JsonWebKey;
        privateJwk: JsonWebKey;
      };
      const publicKey = await importPublicKeyJWK(parsed.publicJwk);
      const privateKey = await importPrivateKeyJWK(parsed.privateJwk);
      const fingerprint = await computeKeyFingerprint(parsed.publicJwk);
      return {
        keyPair: { publicKey, privateKey },
        publicJwk: parsed.publicJwk,
        fingerprint,
      };
    }
  } catch {
    // Regenerate if corrupted
  }

  const keyPair = await generateECDHKeyPair();
  const publicJwk = await exportPublicKeyJWK(keyPair.publicKey);
  const privateJwk = await exportPrivateKeyJWK(keyPair.privateKey);
  const fingerprint = await computeKeyFingerprint(publicJwk);

  try {
    sessionStorage.setItem(
      storageKey,
      JSON.stringify({ publicJwk, privateJwk })
    );
  } catch {
    // Ignore storage error
  }

  return { keyPair, publicJwk, fingerprint };
}
