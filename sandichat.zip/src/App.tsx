import { Lock, LogOut, Menu, MessageSquare, X } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { AdminLoginView } from './components/AdminLoginView';
import { AdminStudioView } from './components/AdminStudioView';
import { AnalyticsView } from './components/AnalyticsView';
import { ApiIntegrationView } from './components/ApiIntegrationView';
import { InboxView } from './components/InboxView';
import { LiveVisitorWidget, WidgetLauncherButton } from './components/LiveVisitorWidget';
import { Sidebar } from './components/Sidebar';
import { useLiveChatSocket } from './hooks/useLiveChatSocket';
import type { AdminAuthUser, AuthStatusResponse, NavSection, WidgetSettings } from './types/chat';

const SECTION_LABELS: Record<NavSection, string> = {
  inbox: 'Live Inbox',
  analytics: 'Aktivitas Pengguna & Analitik',
  studio: 'Studio Pengaturan Widget',
  api: 'Pasang Widget & API',
};

const EMBED_FALLBACK_SETTINGS: WidgetSettings = {
  brandName: 'SandiChat',
  agentName: 'Citra Pratama',
  agentAvatarUrl: '/src/assets/images/avatar_admin_agent_1795413952963.jpg',
  logoStyle: 'shield',
  customLogoUrl: '',
  accentColor: '#10B981',
  surfaceContrast: 'obsidian',
  borderRadius: 'balanced',
  typingAnimation: 'wave',
  entranceAnimation: 'spring',
  welcomeMessage:
    'Halo! Percakapan ini dilindungi enkripsi end-to-end. Ada yang bisa kami bantu hari ini?',
  offlineMessage:
    'Tim kami sedang offline. Tinggalkan pesan terenkripsi dan kami akan segera membalas.',
  inputPlaceholder: 'Tulis pesan terenkripsi...',
  enforceE2EE: true,
  showReadReceipts: true,
  adminSoundEnabled: true,
  widgetSoundEnabled: true,
  soundPreset: 'chime',
  soundVolume: 70,
  launcherPosition: 'bottom-right',
  launcherMode: 'button',
  launcherImageUrl: '',
  launcherImageShape: 'floating',
  launcherImageSize: 72,
  launcherBubbleText: '',
  preChatFormEnabled: true,
  preChatFormTitle: 'Mulai Percakapan Terenkripsi',
  preChatFormDescription: 'Lengkapi data singkat di bawah ini sebelum terhubung dengan tim kami.',
  preChatSubmitLabel: 'Mulai Obrolan',
  preChatFields: [
    {
      id: 'field-username',
      label: 'Username',
      key: 'username',
      type: 'text',
      placeholder: 'Masukkan username Anda...',
      required: true,
    },
    {
      id: 'field-topic',
      label: 'Topik Bantuan',
      key: 'topik',
      type: 'radio',
      required: true,
      options: ['Dukungan Teknis', 'Integrasi API', 'Pertanyaan Billing'],
    },
  ],
};

function EmbedOnlyApp() {
  const [settings, setSettings] = useState<WidgetSettings>(EMBED_FALLBACK_SETTINGS);

  useEffect(() => {
    fetch('/api/v1/widget-config')
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { settings?: WidgetSettings } | null) => {
        if (data?.settings) {
          setSettings(data.settings);
        }
      })
      .catch(() => undefined);
  }, []);

  return (
    <div className="h-screen w-screen bg-[#090A0D]">
      <LiveVisitorWidget
        open
        embedded
        onClose={() => {
          if (window.parent && window.parent !== window) {
            window.parent.postMessage('sandichat:close', '*');
          }
        }}
        settings={settings}
        onSettingsUpdated={setSettings}
      />
    </div>
  );
}

function AuthenticatedAdminWorkspace({
  authToken,
  adminUser,
  envManaged,
  onLogout,
  onUnauthorized,
}: {
  authToken: string;
  adminUser: AdminAuthUser;
  envManaged: boolean;
  onLogout: () => void;
  onUnauthorized: () => void;
}) {
  const [activeSection, setActiveSection] = useState<NavSection>('inbox');
  const [widgetOpen, setWidgetOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const {
    connected,
    settings,
    rooms,
    activeRoomId,
    selectRoom,
    messages,
    decryptedPreviews,
    loadingMessages,
    typingMap,
    analytics,
    workspaceFingerprint,
    sendAgentMessage,
    deleteMessage,
    emitAgentTyping,
    updateRoomStatus,
    saveSettings,
    refreshAnalytics,
  } = useLiveChatSocket({ authToken, onUnauthorized });

  useEffect(() => {
    if (activeSection === 'analytics') {
      void refreshAnalytics();
    }
  }, [activeSection, refreshAnalytics]);

  const handleJumpToRoom = (roomId: string) => {
    selectRoom(roomId);
    setActiveSection('inbox');
    setMobileMenuOpen(false);
  };

  const handleSelectSection = (section: NavSection) => {
    setActiveSection(section);
    setMobileMenuOpen(false);
  };

  return (
    <div className="h-screen w-screen overflow-hidden flex bg-[#090A0D] text-slate-100">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block h-full">
        <Sidebar
          activeSection={activeSection}
          onSelectSection={handleSelectSection}
          settings={settings}
          connected={connected}
          rooms={rooms}
          typingMap={typingMap}
          analytics={analytics}
          onJumpToRoom={handleJumpToRoom}
          adminUser={adminUser}
          onLogout={onLogout}
        />
      </div>

      {/* Mobile Sidebar Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/70"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative z-10 h-full flex">
            <Sidebar
              activeSection={activeSection}
              onSelectSection={handleSelectSection}
              settings={settings}
              connected={connected}
              rooms={rooms}
              typingMap={typingMap}
              analytics={analytics}
              onJumpToRoom={handleJumpToRoom}
              adminUser={adminUser}
              onLogout={onLogout}
            />
            <button
              type="button"
              onClick={() => setMobileMenuOpen(false)}
              aria-label="Tutup menu"
              className="m-3 h-9 w-9 rounded-lg bg-[#14171F] border border-white/10 flex items-center justify-center text-slate-200"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      <div className="flex-1 flex flex-col min-w-0 min-h-0">
        {/* Top Workspace Header */}
        <header className="h-14 shrink-0 px-4 lg:px-6 border-b border-white/[0.08] bg-[#0B0D12] flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Buka menu navigasi"
              className="lg:hidden p-1.5 rounded-lg border border-white/10 text-slate-300 hover:text-white"
            >
              <Menu className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2 text-xs text-slate-400 min-w-0">
              <span className="text-slate-300 font-medium whitespace-nowrap">
                {settings.brandName}
              </span>
              <span aria-hidden="true">/</span>
              <span className="text-slate-100 font-medium truncate">
                {SECTION_LABELS[activeSection]}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4 shrink-0">
            <span className="hidden md:inline-flex items-center gap-1.5 text-xs text-slate-400 whitespace-nowrap">
              <Lock className="w-3.5 h-3.5" style={{ color: settings.accentColor }} />
              <span>{settings.enforceE2EE ? 'E2EE Aktif' : 'Enkripsi Opsional'}</span>
            </span>

            <button
              type="button"
              onClick={() => setWidgetOpen((prev) => !prev)}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold text-slate-950 transition-opacity hover:opacity-90 whitespace-nowrap shrink-0"
              style={{ backgroundColor: settings.accentColor }}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>{widgetOpen ? 'Tutup Widget Uji' : 'Uji Widget Langsung'}</span>
            </button>

            <button
              type="button"
              onClick={onLogout}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/[0.1] bg-[#12151D] text-xs font-medium text-slate-300 hover:text-white hover:border-white/25 transition-colors whitespace-nowrap shrink-0"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Keluar</span>
            </button>
          </div>
        </header>

        {/* Main Content Viewport */}
        <main className="flex-1 min-h-0 overflow-hidden">
          {activeSection === 'inbox' && (
            <InboxView
              rooms={rooms}
              activeRoomId={activeRoomId}
              onSelectRoom={selectRoom}
              messages={messages}
              decryptedPreviews={decryptedPreviews}
              loadingMessages={loadingMessages}
              typingMap={typingMap}
              settings={settings}
              workspaceFingerprint={workspaceFingerprint}
              onSendMessage={sendAgentMessage}
              onDeleteMessage={deleteMessage}
              onEmitTyping={emitAgentTyping}
              onUpdateRoomStatus={updateRoomStatus}
            />
          )}

          {activeSection === 'analytics' && (
            <AnalyticsView
              analytics={analytics}
              rooms={rooms}
              typingMap={typingMap}
              settings={settings}
              onJumpToRoom={handleJumpToRoom}
            />
          )}

          {activeSection === 'studio' && (
            <AdminStudioView
              settings={settings}
              onSaveSettings={saveSettings}
              authToken={authToken}
              envManaged={envManaged}
              onUnauthorized={onUnauthorized}
            />
          )}

          {activeSection === 'api' && (
            <ApiIntegrationView
              settings={settings}
              rooms={rooms}
              authToken={authToken}
              onUnauthorized={onUnauthorized}
            />
          )}
        </main>
      </div>

      {!widgetOpen && activeSection !== 'inbox' && (
        <div
          className={`fixed bottom-6 z-40 ${
            settings.launcherPosition === 'bottom-left' ? 'left-6 lg:left-[284px]' : 'right-6'
          }`}
        >
          <WidgetLauncherButton
            settings={settings}
            onClick={() => setWidgetOpen(true)}
          />
        </div>
      )}

      <LiveVisitorWidget
        open={widgetOpen}
        onClose={() => setWidgetOpen(false)}
        settings={settings}
        onOpenRoomInInbox={(roomId) => {
          if (activeSection === 'inbox') {
            selectRoom(roomId);
          }
        }}
      />
    </div>
  );
}

function AdminConsoleApp() {
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [adminUser, setAdminUser] = useState<AdminAuthUser | null>(null);
  const [authStatus, setAuthStatus] = useState<AuthStatusResponse | null>(null);

  const fetchAuthStatus = useCallback(async (token?: string | null) => {
    try {
      const res = await fetch('/api/auth/status', {
        headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      });
      if (res.ok) {
        const data = (await res.json()) as AuthStatusResponse;
        setAuthStatus(data);
        return;
      }
    } catch {
      // Fallback status if server temporarily unreachable
    }
    setAuthStatus({
      authenticated: false,
      setupRequired: false,
      envManaged: false,
      expectedEmailHint: null,
      user: null,
    });
  }, []);

  useEffect(() => {
    void fetchAuthStatus(null);
  }, [fetchAuthStatus]);

  const handleAuthenticated = useCallback((token: string, user: AdminAuthUser) => {
    setAuthToken(token);
    setAdminUser(user);
    setAuthStatus((prev) => ({
      authenticated: true,
      setupRequired: false,
      envManaged: prev?.envManaged ?? false,
      expectedEmailHint: user.email,
      user,
    }));
  }, []);

  const handleUnauthorized = useCallback(() => {
    setAuthToken(null);
    setAdminUser(null);
    void fetchAuthStatus(null);
  }, [fetchAuthStatus]);

  const handleLogout = useCallback(() => {
    const token = authToken;
    setAuthToken(null);
    setAdminUser(null);
    if (token) {
      void fetch('/api/auth/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      }).finally(() => {
        void fetchAuthStatus(null);
      });
    } else {
      void fetchAuthStatus(null);
    }
  }, [authToken, fetchAuthStatus]);

  if (!authStatus) {
    return (
      <div className="h-screen w-screen bg-[#090A0D] text-slate-400 flex items-center justify-center text-xs">
        Memeriksa sesi admin...
      </div>
    );
  }

  if (!authToken || !adminUser) {
    return (
      <AdminLoginView
        authStatus={authStatus}
        onAuthenticated={handleAuthenticated}
      />
    );
  }

  return (
    <AuthenticatedAdminWorkspace
      authToken={authToken}
      adminUser={adminUser}
      envManaged={authStatus.envManaged}
      onLogout={handleLogout}
      onUnauthorized={handleUnauthorized}
    />
  );
}

export default function App() {
  const isEmbedOnly =
    typeof window !== 'undefined' &&
    new URLSearchParams(window.location.search).get('embed') === '1';

  return isEmbedOnly ? <EmbedOnlyApp /> : <AdminConsoleApp />;
}
