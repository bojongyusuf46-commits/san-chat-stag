import crypto from 'node:crypto';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import express from 'express';
import { createServer as createViteServer } from 'vite';
import { WebSocketServer, WebSocket } from 'ws';
import type {
  AnalyticsSnapshot,
  ApiKeyRecord,
  ChatMessage,
  CustomFormField,
  CustomFormFieldType,
  HourlyBucket,
  ImageAttachment,
  TypingState,
  VisitorRoom,
  WebhookConfig,
  WidgetSettings,
} from './src/types/chat.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT) || 3000;

interface SocketMeta {
  ws: WebSocket;
  role: 'agent' | 'visitor';
  roomId?: string;
  clientId: string;
}

const defaultSettings: WidgetSettings = {
  brandName: 'SandiChat',
  agentName: 'Citra Pratama',
  agentAvatarUrl: '/src/assets/images/avatar_admin_agent_1795413952963.jpg',
  logoStyle: 'shield',
  customLogoUrl: '',
  accentColor: '#10B981',
  surfaceContrast: 'obsidian',
  borderRadius: 'balanced',
  typingAnimation: 'wave',
  entranceAnimation: 'spring',
  welcomeMessage: 'Halo! Percakapan ini dilindungi enkripsi end-to-end. Ada yang bisa kami bantu hari ini?',
  offlineMessage: 'Tim kami sedang offline. Tinggalkan pesan terenkripsi dan kami akan segera membalas.',
  inputPlaceholder: 'Tulis pesan terenkripsi...',
  enforceE2EE: true,
  showReadReceipts: true,
  adminSoundEnabled: true,
  widgetSoundEnabled: true,
  soundPreset: 'chime',
  soundVolume: 70,
  launcherPosition: 'bottom-right',
  launcherMode: 'button',
  launcherImageUrl: '',
  launcherImageShape: 'floating',
  launcherImageSize: 72,
  launcherBubbleText: '',
  preChatFormEnabled: true,
  preChatFormTitle: 'Mulai Percakapan Terenkripsi',
  preChatFormDescription: 'Lengkapi data singkat di bawah ini sebelum terhubung dengan tim kami.',
  preChatSubmitLabel: 'Mulai Obrolan',
  preChatFields: [
    {
      id: 'field-username',
      label: 'Username',
      key: 'username',
      type: 'text',
      placeholder: 'Masukkan username Anda...',
      required: true,
    },
    {
      id: 'field-topic',
      label: 'Topik Bantuan',
      key: 'topik',
      type: 'radio',
      required: true,
      options: ['Dukungan Teknis', 'Integrasi API', 'Pertanyaan Billing'],
    },
  ],
};

let widgetSettings: WidgetSettings = { ...defaultSettings };
let workspacePublicKey: JsonWebKey | null = null;
let workspaceFingerprint: string | null = null;

const rooms = new Map<string, VisitorRoom>();
const messagesByRoom = new Map<string, ChatMessage[]>();
const typingByRoom = new Map<string, Map<string, TypingState>>();
const apiKeyStore = new Map<string, { record: ApiKeyRecord; hash: string }>();
const webhooks: WebhookConfig[] = [];
const sockets = new Set<SocketMeta>();

// Server-side admin auth & session store
const SESSION_SECRET =
  process.env.SESSION_SECRET?.trim() || crypto.randomBytes(32).toString('hex');
const SESSION_TTL_MS = 24 * 60 * 60 * 1000;

interface ClaimedAdminRecord {
  email: string;
  name: string;
  salt: string;
  passwordHash: string;
}

interface AdminSessionRecord {
  email: string;
  name: string;
  exp: number;
}

let claimedAdmin: ClaimedAdminRecord | null = null;
const activeAdminSessions = new Map<string, AdminSessionRecord>();
const authAttemptMap = new Map<string, { count: number; resetAt: number }>();

function seedInitialData(): void {
  const now = Date.now();
  const minute = 60_000;
  const hour = 60 * minute;

  const seedRooms: Array<{
    room: VisitorRoom;
    messages: ChatMessage[];
  }> = [
    {
      room: {
        id: 'room-nadia-841',
        visitorName: 'Nadia Kusuma',
        visitorEmail: 'nadia@fintech-id.co',
        visitorAvatar: '/src/assets/images/avatar_visitor_user_1795413952633.jpg',
        currentPage: '/checkout/billing',
        location: 'Jakarta, ID',
        device: 'Desktop',
        browser: 'Chrome 131',
        status: 'active',
        online: true,
        unreadCount: 2,
        e2eeVerified: true,
        keyFingerprint: 'A4F8 · 29C1 · 8E04 · D119',
        startedAt: now - 14 * minute,
        lastActivityAt: now - 45_000,
        lastMessagePreview: 'Apakah webhook event message.encrypted mendukung payload signature HMAC?',
        lastMessageEncrypted: false,
        messageCount: 4,
      },
      messages: [
        {
          id: 'seed-msg-101',
          roomId: 'room-nadia-841',
          senderId: 'visitor-nadia',
          senderName: 'Nadia Kusuma',
          senderRole: 'visitor',
          encrypted: false,
          keyFingerprint: 'A4F8 · 29C1 · 8E04 · D119',
          plaintext: 'Halo tim SandiChat, kami berencana integrasi widget ke portal nasabah.',
          timestamp: now - 12 * minute,
          read: true,
        },
        {
          id: 'seed-msg-102',
          roomId: 'room-nadia-841',
          senderId: 'agent-citra',
          senderName: 'Citra Pratama',
          senderRole: 'agent',
          encrypted: false,
          keyFingerprint: 'A4F8 · 29C1 · 8E04 · D119',
          plaintext: 'Halo Nadia! Tentu, script embed kami ringan dan langsung menjalankan handshake ECDH P-256 di browser.',
          timestamp: now - 9 * minute,
          read: true,
        },
        {
          id: 'seed-msg-103',
          roomId: 'room-nadia-841',
          senderId: 'visitor-nadia',
          senderName: 'Nadia Kusuma',
          senderRole: 'visitor',
          encrypted: false,
          keyFingerprint: 'A4F8 · 29C1 · 8E04 · D119',
          plaintext: 'Bagus sekali. Untuk verifikasi server-to-server di backend kami nanti:',
          timestamp: now - 2 * minute,
          read: false,
        },
        {
          id: 'seed-msg-104',
          roomId: 'room-nadia-841',
          senderId: 'visitor-nadia',
          senderName: 'Nadia Kusuma',
          senderRole: 'visitor',
          encrypted: false,
          keyFingerprint: 'A4F8 · 29C1 · 8E04 · D119',
          plaintext: 'Apakah webhook event message.encrypted mendukung payload signature HMAC?',
          timestamp: now - 45_000,
          read: false,
        },
      ],
    },
    {
      room: {
        id: 'room-rafi-309',
        visitorName: 'Rafi Wirawan',
        visitorEmail: 'rafi@karya.dev',
        currentPage: '/docs/sdk-react',
        location: 'Bandung, ID',
        device: 'Desktop',
        browser: 'Firefox 132',
        status: 'active',
        online: true,
        unreadCount: 0,
        e2eeVerified: true,
        keyFingerprint: '7C10 · 55B2 · 19EA · 402F',
        startedAt: now - 38 * minute,
        lastActivityAt: now - 6 * minute,
        lastMessagePreview: 'Siap, key API sudah berhasil terhubung ke staging app kami.',
        lastMessageEncrypted: false,
        messageCount: 3,
      },
      messages: [
        {
          id: 'seed-msg-201',
          roomId: 'room-rafi-309',
          senderId: 'visitor-rafi',
          senderName: 'Rafi Wirawan',
          senderRole: 'visitor',
          encrypted: false,
          plaintext: 'Selamat malam, bagaimana cara mengubah animasi typing indicator lewat REST API?',
          timestamp: now - 30 * minute,
          read: true,
        },
        {
          id: 'seed-msg-202',
          roomId: 'room-rafi-309',
          senderId: 'agent-citra',
          senderName: 'Citra Pratama',
          senderRole: 'agent',
          encrypted: false,
          plaintext: 'Anda bisa mengatur preset animasi di Studio Pengaturan atau mengirim parameter typingAnimation pada config widget.',
          timestamp: now - 26 * minute,
          read: true,
        },
        {
          id: 'seed-msg-203',
          roomId: 'room-rafi-309',
          senderId: 'visitor-rafi',
          senderName: 'Rafi Wirawan',
          senderRole: 'visitor',
          encrypted: false,
          plaintext: 'Siap, key API sudah berhasil terhubung ke staging app kami.',
          timestamp: now - 6 * minute,
          read: true,
        },
      ],
    },
    {
      room: {
        id: 'room-tania-512',
        visitorName: 'Tania Wijaya',
        visitorEmail: 'tania@logistik.id',
        currentPage: '/pricing',
        location: 'Surabaya, ID',
        device: 'Mobile',
        browser: 'Safari iOS 18',
        status: 'resolved',
        online: false,
        unreadCount: 0,
        e2eeVerified: true,
        keyFingerprint: 'F29A · 1108 · 6D4C · 9B31',
        startedAt: now - 3 * hour,
        lastActivityAt: now - 2 * hour,
        lastMessagePreview: 'Terima kasih atas bantuannya, sangat membantu!',
        lastMessageEncrypted: false,
        messageCount: 2,
      },
      messages: [
        {
          id: 'seed-msg-301',
          roomId: 'room-tania-512',
          senderId: 'visitor-tania',
          senderName: 'Tania Wijaya',
          senderRole: 'visitor',
          encrypted: false,
          plaintext: 'Apakah kuota API webhook sudah termasuk di paket standar?',
          timestamp: now - 2.4 * hour,
          read: true,
        },
        {
          id: 'seed-msg-302',
          roomId: 'room-tania-512',
          senderId: 'visitor-tania',
          senderName: 'Tania Wijaya',
          senderRole: 'visitor',
          encrypted: false,
          plaintext: 'Terima kasih atas bantuannya, sangat membantu!',
          timestamp: now - 2 * hour,
          read: true,
        },
      ],
    },
  ];

  for (const item of seedRooms) {
    rooms.set(item.room.id, item.room);
    messagesByRoom.set(item.room.id, item.messages);
  }
}

seedInitialData();

function computeAnalytics(): AnalyticsSnapshot {
  const allRooms = Array.from(rooms.values());
  let totalMessages = 0;
  let encryptedMessages = 0;

  for (const list of messagesByRoom.values()) {
    for (const msg of list) {
      if (msg.senderRole === 'system') continue;
      totalMessages += 1;
      if (msg.encrypted) {
        encryptedMessages += 1;
      }
    }
  }

  const encryptionRate =
    totalMessages > 0 ? Math.round((encryptedMessages / totalMessages) * 1000) / 10 : 100;

  const activeVisitors = allRooms.filter((r) => r.online).length;

  const now = Date.now();
  const hourlyVolume: HourlyBucket[] = [];
  for (let i = 9; i >= 0; i--) {
    const bucketEnd = now - i * 3600_000;
    const bucketStart = bucketEnd - 3600_000;
    const date = new Date(bucketEnd);
    const label = `${String(date.getHours()).padStart(2, '0')}:00`;

    let bucketTotal = 0;
    let bucketEnc = 0;
    for (const list of messagesByRoom.values()) {
      for (const msg of list) {
        if (msg.timestamp >= bucketStart && msg.timestamp < bucketEnd && msg.senderRole !== 'system') {
          bucketTotal += 1;
          if (msg.encrypted) bucketEnc += 1;
        }
      }
    }

    // Add baseline activity from historical buckets while keeping current hour strictly live
    const baseline = i === 0 ? 0 : [6, 9, 14, 11, 18, 22, 16, 12, 8][9 - i] ?? 5;
    const baselineEnc = i === 0 ? 0 : Math.max(0, baseline - 1);

    hourlyVolume.push({
      hour: label,
      totalMessages: bucketTotal + baseline,
      encryptedMessages: bucketEnc + baselineEnc,
      avgResponseSec: i === 0 ? 18 : 14 + ((i * 7) % 15),
    });
  }

  const pageMap = new Map<string, number>();
  const deviceMap = new Map<string, number>();
  for (const r of allRooms) {
    pageMap.set(r.currentPage, (pageMap.get(r.currentPage) ?? 0) + 1);
    deviceMap.set(r.device, (deviceMap.get(r.device) ?? 0) + 1);
  }

  const totalRooms = allRooms.length || 1;
  const topPages = Array.from(pageMap.entries())
    .map(([pagePath, visitors]) => ({
      path: pagePath,
      visitors,
      share: Math.round((visitors / totalRooms) * 100),
    }))
    .sort((a, b) => b.visitors - a.visitors);

  const deviceSplit = Array.from(deviceMap.entries()).map(([label, count]) => ({
    label,
    count,
    percentage: Math.round((count / totalRooms) * 100),
  }));

  return {
    totalMessages,
    encryptedMessages,
    encryptionRate,
    activeVisitors,
    totalRooms: allRooms.length,
    avgFirstResponseSec: 19,
    hourlyVolume,
    topPages,
    deviceSplit,
  };
}

function getSortedRooms(): VisitorRoom[] {
  return Array.from(rooms.values()).sort((a, b) => b.lastActivityAt - a.lastActivityAt);
}

function broadcastToAgents(payload: unknown): void {
  const raw = JSON.stringify(payload);
  for (const client of sockets) {
    if (client.role === 'agent' && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(raw);
    }
  }
}

function broadcastToRoom(roomId: string, payload: unknown): void {
  const raw = JSON.stringify(payload);
  for (const client of sockets) {
    if (client.ws.readyState !== WebSocket.OPEN) continue;
    if (client.role === 'agent' || client.roomId === roomId) {
      client.ws.send(raw);
    }
  }
}

function broadcastAll(payload: unknown): void {
  const raw = JSON.stringify(payload);
  for (const client of sockets) {
    if (client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(raw);
    }
  }
}

function isSafeWebhookUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return false;
    }
    const hostname = parsed.hostname.toLowerCase();
    if (
      hostname === 'localhost' ||
      hostname === '127.0.0.1' ||
      hostname === '::1' ||
      hostname === '0.0.0.0' ||
      hostname === '169.254.169.254' ||
      hostname.startsWith('10.') ||
      hostname.startsWith('192.168.') ||
      /^172\.(1[6-9]|2\d|3[0-1])\./.test(hostname)
    ) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

function isSafeLogoUrl(rawUrl: string): boolean {
  if (!rawUrl) return true;
  if (rawUrl.startsWith('/')) return true;
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

function hashApiKey(rawKey: string): string {
  return crypto.createHash('sha256').update(rawKey).digest('hex');
}

function requireApiKey(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
): void {
  const headerKey = req.header('x-api-key');
  const authHeader = req.header('authorization');
  const token =
    headerKey ||
    (authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : '');

  if (!token) {
    res.status(401).json({
      error: 'API key diperlukan pada header x-api-key atau Authorization: Bearer <key>.',
    });
    return;
  }

  const tokenHash = hashApiKey(token);
  let matched: { record: ApiKeyRecord; hash: string } | undefined;
  for (const entry of apiKeyStore.values()) {
    if (entry.hash === tokenHash) {
      matched = entry;
      break;
    }
  }

  if (!matched) {
    res.status(403).json({
      error: 'API key tidak valid atau telah dicabut.',
    });
    return;
  }

  matched.record.lastUsedAt = Date.now();
  matched.record.requestsCount += 1;
  next();
}

function isEnvAdminConfigured(): boolean {
  return Boolean(process.env.ADMIN_PASSCODE && process.env.ADMIN_PASSCODE.trim().length > 0);
}

function safeEqualHexOrUtf8(a: string, b: string): boolean {
  const hashA = crypto.createHash('sha256').update(a).digest();
  const hashB = crypto.createHash('sha256').update(b).digest();
  return crypto.timingSafeEqual(hashA, hashB);
}

function hashPasswordWithScrypt(password: string, saltHex?: string): { salt: string; hash: string } {
  const salt = saltHex || crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return { salt, hash: derived };
}

function verifyScryptPassword(password: string, salt: string, expectedHashHex: string): boolean {
  const derived = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(expectedHashHex, 'hex');
  if (derived.length !== expected.length) return false;
  return crypto.timingSafeEqual(derived, expected);
}

function issueAdminSessionToken(email: string, name: string): {
  token: string;
  user: { email: string; name: string; role: 'admin' };
  expiresAt: number;
} {
  const sid = crypto.randomBytes(24).toString('hex');
  const exp = Date.now() + SESSION_TTL_MS;
  activeAdminSessions.set(sid, { email, name, exp });

  const payloadB64 = Buffer.from(JSON.stringify({ sid, email, name, exp })).toString('base64url');
  const sigHex = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(payloadB64)
    .digest('hex');

  return {
    token: `${payloadB64}.${sigHex}`,
    user: { email, name, role: 'admin' },
    expiresAt: exp,
  };
}

function verifyAdminSessionToken(rawToken?: string | null): {
  sid: string;
  email: string;
  name: string;
  exp: number;
} | null {
  if (!rawToken || typeof rawToken !== 'string') return null;
  const parts = rawToken.trim().split('.');
  if (parts.length !== 2) return null;
  const [payloadB64, sigHex] = parts;
  if (!payloadB64 || !sigHex) return null;

  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(payloadB64)
    .digest('hex');
  const sigBuf = Buffer.from(sigHex, 'utf8');
  const expectedBuf = Buffer.from(expectedSig, 'utf8');
  if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
    return null;
  }

  try {
    const parsed = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8')) as {
      sid?: string;
      email?: string;
      name?: string;
      exp?: number;
    };
    if (!parsed.sid || !parsed.email || !parsed.exp || Date.now() > parsed.exp) {
      if (parsed.sid) activeAdminSessions.delete(parsed.sid);
      return null;
    }
    const stored = activeAdminSessions.get(parsed.sid);
    if (!stored || Date.now() > stored.exp) {
      activeAdminSessions.delete(parsed.sid);
      return null;
    }
    return {
      sid: parsed.sid,
      email: stored.email,
      name: stored.name,
      exp: stored.exp,
    };
  } catch {
    return null;
  }
}

function extractBearerToken(req: express.Request): string | null {
  const auth = req.header('authorization');
  if (!auth || !auth.startsWith('Bearer ')) return null;
  return auth.slice(7).trim() || null;
}

function requireAdminAuth(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
): void {
  const token = extractBearerToken(req);
  const session = verifyAdminSessionToken(token);
  if (!session) {
    res.status(401).json({
      error: 'Autentikasi admin diperlukan. Silakan login kembali.',
    });
    return;
  }
  next();
}

function checkAuthRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = authAttemptMap.get(ip);
  if (!entry || now > entry.resetAt) {
    authAttemptMap.set(ip, { count: 1, resetAt: now + 60_000 });
    return true;
  }
  if (entry.count >= 25) {
    return false;
  }
  entry.count += 1;
  return true;
}

const ALLOWED_IMG_EXTS = new Set(['png', 'jpg', 'jpeg', 'webp', 'gif']);
const DANGEROUS_EXTS = new Set([
  'php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'php8', 'phps', 'phar',
  'asp', 'aspx', 'jsp', 'jspx', 'cgi', 'pl', 'py', 'rb', 'sh', 'bash',
  'exe', 'dll', 'bat', 'cmd', 'msi', 'js', 'mjs', 'cjs', 'ts', 'jsx', 'tsx',
  'html', 'htm', 'xhtml', 'svg', 'svgz', 'xml', 'htaccess',
]);
const POLYGLOT_SIGNATURES = [
  '<?php', '<?=', '<script', '</script', '<svg', 'javascript:',
  'onerror=', 'onload=', 'shell_exec(', 'passthru(', 'base64_decode(',
];

function validateStrictImageBuffer(
  fileName: string,
  base64Raw: string
): { ok: true; mime: ImageAttachment['mimeType']; sizeBytes: number } | { ok: false; error: string } {
  if (!fileName || fileName.includes('\0') || fileName.includes('/') || fileName.includes('\\')) {
    return { ok: false, error: 'Nama file gambar tidak valid.' };
  }
  const parts = fileName.toLowerCase().split('.');
  if (parts.length < 2) {
    return { ok: false, error: 'File harus memiliki ekstensi gambar (.png, .jpg, .webp, .gif).' };
  }
  const finalExt = parts[parts.length - 1];
  if (!ALLOWED_IMG_EXTS.has(finalExt)) {
    return { ok: false, error: `Ekstensi .${finalExt} dilarang. Wajib file gambar.` };
  }
  for (let i = 1; i < parts.length; i++) {
    if (DANGEROUS_EXTS.has(parts[i])) {
      return { ok: false, error: `Upload ditolak: terdeteksi ekstensi berbahaya (.${parts[i]}).` };
    }
  }

  const cleanBase64 = base64Raw.includes(',') ? base64Raw.split(',')[1] : base64Raw;
  if (!cleanBase64 || !/^[A-Za-z0-9+/=\s]+$/.test(cleanBase64)) {
    return { ok: false, error: 'Payload base64 gambar tidak valid.' };
  }

  const buf = Buffer.from(cleanBase64, 'base64');
  if (buf.length < 12 || buf.length > 2.5 * 1024 * 1024) {
    return { ok: false, error: 'Ukuran gambar harus di antara 12 byte hingga 2,5 MB.' };
  }

  let detectedMime: ImageAttachment['mimeType'] | null = null;
  if (
    buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47 &&
    buf[4] === 0x0d && buf[5] === 0x0a && buf[6] === 0x1a && buf[7] === 0x0a
  ) {
    detectedMime = 'image/png';
  } else if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) {
    detectedMime = 'image/jpeg';
  } else if (
    buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x38 &&
    (buf[4] === 0x37 || buf[4] === 0x39) && buf[5] === 0x61
  ) {
    detectedMime = 'image/gif';
  } else if (
    buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46 &&
    buf[8] === 0x57 && buf[9] === 0x45 && buf[10] === 0x42 && buf[11] === 0x50
  ) {
    detectedMime = 'image/webp';
  }

  if (!detectedMime) {
    return {
      ok: false,
      error: 'Signature biner (magic bytes) bukan gambar PNG, JPEG, WebP, atau GIF yang sah.',
    };
  }

  const head = buf.subarray(0, Math.min(buf.length, 262144)).toString('latin1').toLowerCase();
  const tailStart = Math.max(0, buf.length - 65536);
  const tail = tailStart > 0 ? buf.subarray(tailStart).toString('latin1').toLowerCase() : '';
  for (const sig of POLYGLOT_SIGNATURES) {
    if (head.includes(sig) || tail.includes(sig)) {
      return {
        ok: false,
        error: 'Upload diblokir: ditemukan pola skrip atau kode injeksi di dalam file.',
      };
    }
  }

  return { ok: true, mime: detectedMime, sizeBytes: buf.length };
}

async function createServer(): Promise<void> {
  const app = express();
  app.set('trust proxy', 1);
  app.use('/api/media/verify', express.json({ limit: '4mb' }));
  app.use('/api/settings', express.json({ limit: '4mb' }));
  app.use(express.json({ limit: '512kb' }));

  // Health
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', activeRooms: rooms.size, connectedSockets: sockets.size });
  });

  // Admin Auth (Status, One-time First-Run Setup, Login, Logout)
  app.get('/api/auth/status', (req, res) => {
    const token = extractBearerToken(req);
    const session = verifyAdminSessionToken(token);
    const envManaged = isEnvAdminConfigured();
    const setupRequired = !envManaged && !claimedAdmin;

    res.json({
      authenticated: Boolean(session),
      setupRequired,
      envManaged,
      expectedEmailHint: envManaged ? process.env.ADMIN_EMAIL?.trim() || null : claimedAdmin?.email || null,
      user: session
        ? { email: session.email, name: session.name, role: 'admin' as const }
        : null,
    });
  });

  app.post('/api/auth/setup', (req, res) => {
    const clientIp = req.ip || 'unknown';
    if (!checkAuthRateLimit(clientIp)) {
      res.status(429).json({ error: 'Terlalu banyak percobaan. Coba lagi dalam 1 menit.' });
      return;
    }

    if (isEnvAdminConfigured() || claimedAdmin !== null) {
      res.status(403).json({
        error: 'Akun admin sudah aktif. Silakan gunakan halaman login.',
      });
      return;
    }

    const { email, name, password } = req.body as {
      email?: string;
      name?: string;
      password?: string;
    };

    const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : '';
    const cleanName =
      typeof name === 'string' && name.trim().length > 0
        ? name.trim().slice(0, 60)
        : widgetSettings.agentName || 'Admin Support';
    const rawPassword = typeof password === 'string' ? password : '';

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      res.status(400).json({ error: 'Masukkan alamat email admin yang valid.' });
      return;
    }
    if (rawPassword.length < 8 || rawPassword.length > 128) {
      res.status(400).json({ error: 'Kata sandi minimal 8 karakter (maksimal 128 karakter).' });
      return;
    }

    const { salt, hash } = hashPasswordWithScrypt(rawPassword);
    claimedAdmin = {
      email: cleanEmail,
      name: cleanName,
      salt,
      passwordHash: hash,
    };

    const issued = issueAdminSessionToken(claimedAdmin.email, claimedAdmin.name);
    res.status(201).json(issued);
  });

  app.post('/api/auth/login', (req, res) => {
    const clientIp = req.ip || 'unknown';
    if (!checkAuthRateLimit(clientIp)) {
      res.status(429).json({ error: 'Terlalu banyak percobaan login. Tunggu 1 menit.' });
      return;
    }

    const { email, password } = req.body as { email?: string; password?: string };
    const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : '';
    const rawPassword = typeof password === 'string' ? password : '';

    if (!cleanEmail || !rawPassword) {
      res.status(400).json({ error: 'Email dan kata sandi wajib diisi.' });
      return;
    }

    if (isEnvAdminConfigured()) {
      const envPass = process.env.ADMIN_PASSCODE!.trim();
      const envEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();

      if (envEmail && !safeEqualHexOrUtf8(cleanEmail, envEmail)) {
        res.status(401).json({ error: 'Email atau kata sandi admin tidak sesuai.' });
        return;
      }
      if (!safeEqualHexOrUtf8(rawPassword, envPass)) {
        res.status(401).json({ error: 'Email atau kata sandi admin tidak sesuai.' });
        return;
      }

      const issued = issueAdminSessionToken(
        envEmail || cleanEmail,
        widgetSettings.agentName || 'Admin Support'
      );
      res.json(issued);
      return;
    }

    if (!claimedAdmin) {
      res.status(400).json({
        error: 'Akun admin belum dibuat. Silakan lengkapi setup admin pertama kali.',
      });
      return;
    }

    const emailMatch = safeEqualHexOrUtf8(cleanEmail, claimedAdmin.email);
    const passMatch = verifyScryptPassword(rawPassword, claimedAdmin.salt, claimedAdmin.passwordHash);
    if (!emailMatch || !passMatch) {
      res.status(401).json({ error: 'Email atau kata sandi admin tidak sesuai.' });
      return;
    }

    const issued = issueAdminSessionToken(claimedAdmin.email, claimedAdmin.name);
    res.json(issued);
  });

  app.post('/api/auth/logout', (req, res) => {
    const token = extractBearerToken(req);
    const session = verifyAdminSessionToken(token);
    if (session) {
      activeAdminSessions.delete(session.sid);
    }
    res.json({ ok: true });
  });

  app.post('/api/auth/change-password', requireAdminAuth, (req, res) => {
    const clientIp = req.ip || 'unknown';
    if (!checkAuthRateLimit(clientIp)) {
      res.status(429).json({ error: 'Terlalu banyak percobaan. Tunggu 1 menit.' });
      return;
    }

    if (isEnvAdminConfigured()) {
      res.status(400).json({
        error:
          'Kata sandi dikelola melalui environment variable (ADMIN_PASSCODE). Ubah langsung di file .env atau menu Secrets server.',
      });
      return;
    }

    if (!claimedAdmin) {
      res.status(400).json({ error: 'Akun admin belum terdaftar.' });
      return;
    }

    const { currentPassword, newPassword } = req.body as {
      currentPassword?: string;
      newPassword?: string;
    };

    const curr = typeof currentPassword === 'string' ? currentPassword : '';
    const nextPass = typeof newPassword === 'string' ? newPassword : '';

    if (!curr || !verifyScryptPassword(curr, claimedAdmin.salt, claimedAdmin.passwordHash)) {
      res.status(401).json({ error: 'Kata sandi saat ini tidak sesuai.' });
      return;
    }

    if (nextPass.length < 8 || nextPass.length > 128) {
      res.status(400).json({ error: 'Kata sandi baru minimal 8 karakter (maksimal 128 karakter).' });
      return;
    }

    const { salt, hash } = hashPasswordWithScrypt(nextPass);
    claimedAdmin.salt = salt;
    claimedAdmin.passwordHash = hash;

    const currentToken = extractBearerToken(req);
    const currentSession = verifyAdminSessionToken(currentToken);
    for (const sid of Array.from(activeAdminSessions.keys())) {
      if (!currentSession || sid !== currentSession.sid) {
        activeAdminSessions.delete(sid);
      }
    }

    res.json({ ok: true, message: 'Kata sandi admin berhasil diperbarui.' });
  });

  // Settings (Protected Admin Routes)
  app.get('/api/settings', requireAdminAuth, (_req, res) => {
    res.json({ settings: widgetSettings, workspacePublicKey, workspaceFingerprint });
  });

  app.put('/api/settings', requireAdminAuth, (req, res) => {
    const body = req.body as Partial<WidgetSettings>;
    const next: WidgetSettings = { ...widgetSettings };

    if (typeof body.brandName === 'string' && body.brandName.trim().length > 0) {
      next.brandName = body.brandName.trim().slice(0, 40);
    }
    if (typeof body.agentName === 'string' && body.agentName.trim().length > 0) {
      next.agentName = body.agentName.trim().slice(0, 40);
    }
    if (typeof body.agentAvatarUrl === 'string') {
      const trimmedAvatar = body.agentAvatarUrl.trim();
      if (!trimmedAvatar) {
        next.agentAvatarUrl = '';
      } else if (trimmedAvatar.startsWith('data:image/')) {
        const mimeMatch = /^data:image\/(png|jpeg|webp|gif);base64,/i.exec(trimmedAvatar);
        if (!mimeMatch) {
          res.status(400).json({ error: 'Format foto profil harus PNG, JPEG, WebP, atau GIF.' });
          return;
        }
        const ext = mimeMatch[1] === 'jpeg' ? 'jpg' : mimeMatch[1].toLowerCase();
        const check = validateStrictImageBuffer(`avatar.${ext}`, trimmedAvatar);
        if (!check.ok) {
          res.status(400).json({ error: check.error });
          return;
        }
        next.agentAvatarUrl = trimmedAvatar;
      } else if (isSafeLogoUrl(trimmedAvatar)) {
        const lowerPath = trimmedAvatar.split('?')[0].toLowerCase();
        if (/\.(php|phtml|phar|svg|html|htm|js|asp|aspx|jsp)$/.test(lowerPath)) {
          res.status(400).json({
            error: 'URL foto agen tidak boleh mengarah ke skrip atau HTML.',
          });
          return;
        }
        next.agentAvatarUrl = trimmedAvatar.slice(0, 500);
      } else {
        res.status(400).json({ error: 'URL foto agen tidak valid.' });
        return;
      }
    }
    if (
      body.logoStyle &&
      ['shield', 'waveform', 'hexagon', 'custom'].includes(body.logoStyle)
    ) {
      next.logoStyle = body.logoStyle;
    }
    if (typeof body.customLogoUrl === 'string' && isSafeLogoUrl(body.customLogoUrl.trim())) {
      next.customLogoUrl = body.customLogoUrl.trim().slice(0, 300);
    }
    if (typeof body.accentColor === 'string' && /^#[0-9A-Fa-f]{6}$/.test(body.accentColor)) {
      next.accentColor = body.accentColor;
    }
    if (
      body.surfaceContrast &&
      ['obsidian', 'slate', 'midnight'].includes(body.surfaceContrast)
    ) {
      next.surfaceContrast = body.surfaceContrast;
    }
    if (body.borderRadius && ['sharp', 'balanced', 'soft'].includes(body.borderRadius)) {
      next.borderRadius = body.borderRadius;
    }
    if (
      body.typingAnimation &&
      ['wave', 'dots', 'pulse-bar', 'minimal'].includes(body.typingAnimation)
    ) {
      next.typingAnimation = body.typingAnimation;
    }
    if (
      body.entranceAnimation &&
      ['spring', 'slide', 'fade'].includes(body.entranceAnimation)
    ) {
      next.entranceAnimation = body.entranceAnimation;
    }
    if (typeof body.welcomeMessage === 'string') {
      next.welcomeMessage = body.welcomeMessage.slice(0, 300);
    }
    if (typeof body.offlineMessage === 'string') {
      next.offlineMessage = body.offlineMessage.slice(0, 300);
    }
    if (typeof body.inputPlaceholder === 'string') {
      next.inputPlaceholder = body.inputPlaceholder.slice(0, 80);
    }
    if (typeof body.enforceE2EE === 'boolean') {
      next.enforceE2EE = body.enforceE2EE;
    }
    if (typeof body.showReadReceipts === 'boolean') {
      next.showReadReceipts = body.showReadReceipts;
    }
    if (typeof body.adminSoundEnabled === 'boolean') {
      next.adminSoundEnabled = body.adminSoundEnabled;
    }
    if (typeof body.widgetSoundEnabled === 'boolean') {
      next.widgetSoundEnabled = body.widgetSoundEnabled;
    }
    if (
      body.soundPreset &&
      ['chime', 'pop', 'bell', 'subtle'].includes(body.soundPreset)
    ) {
      next.soundPreset = body.soundPreset;
    }
    if (typeof body.soundVolume === 'number' && Number.isFinite(body.soundVolume)) {
      next.soundVolume = Math.min(100, Math.max(10, Math.round(body.soundVolume)));
    }
    if (
      body.launcherPosition &&
      ['bottom-right', 'bottom-left'].includes(body.launcherPosition)
    ) {
      next.launcherPosition = body.launcherPosition;
    }
    if (body.launcherMode && ['button', 'image'].includes(body.launcherMode)) {
      next.launcherMode = body.launcherMode;
    }
    if (
      body.launcherImageShape &&
      ['floating', 'circle', 'rounded'].includes(body.launcherImageShape)
    ) {
      next.launcherImageShape = body.launcherImageShape;
    }
    if (
      typeof body.launcherImageSize === 'number' &&
      Number.isFinite(body.launcherImageSize)
    ) {
      next.launcherImageSize = Math.min(128, Math.max(48, Math.round(body.launcherImageSize)));
    }
    if (typeof body.launcherBubbleText === 'string') {
      next.launcherBubbleText = body.launcherBubbleText.trim().slice(0, 60);
    }
    if (typeof body.launcherImageUrl === 'string') {
      const trimmedImg = body.launcherImageUrl.trim();
      if (!trimmedImg) {
        next.launcherImageUrl = '';
      } else if (trimmedImg.startsWith('data:image/')) {
        const mimeMatch = /^data:image\/(png|jpeg|webp|gif);base64,/i.exec(trimmedImg);
        if (!mimeMatch) {
          res.status(400).json({
            error: 'Format gambar launcher wajib PNG, JPEG, WebP, atau GIF.',
          });
          return;
        }
        const ext = mimeMatch[1] === 'jpeg' ? 'jpg' : mimeMatch[1].toLowerCase();
        const check = validateStrictImageBuffer(`launcher.${ext}`, trimmedImg);
        if (!check.ok) {
          res.status(400).json({ error: check.error });
          return;
        }
        next.launcherImageUrl = trimmedImg;
      } else if (isSafeLogoUrl(trimmedImg)) {
        const lowerPath = trimmedImg.split('?')[0].toLowerCase();
        if (/\.(php|phtml|phar|svg|html|htm|js|asp|aspx|jsp)$/.test(lowerPath)) {
          res.status(400).json({
            error: 'URL gambar launcher tidak boleh mengarah ke file skrip atau HTML.',
          });
          return;
        }
        next.launcherImageUrl = trimmedImg.slice(0, 500);
      } else {
        res.status(400).json({ error: 'URL gambar launcher tidak valid.' });
        return;
      }
    }
    if (typeof body.preChatFormEnabled === 'boolean') {
      next.preChatFormEnabled = body.preChatFormEnabled;
    }
    if (typeof body.preChatFormTitle === 'string') {
      next.preChatFormTitle = body.preChatFormTitle.trim().slice(0, 80);
    }
    if (typeof body.preChatFormDescription === 'string') {
      next.preChatFormDescription = body.preChatFormDescription.trim().slice(0, 200);
    }
    if (typeof body.preChatSubmitLabel === 'string' && body.preChatSubmitLabel.trim()) {
      next.preChatSubmitLabel = body.preChatSubmitLabel.trim().slice(0, 40);
    }
    if (Array.isArray(body.preChatFields)) {
      const allowedTypes: CustomFormFieldType[] = [
        'text',
        'email',
        'number',
        'textarea',
        'select',
        'radio',
      ];
      const sanitizedFields: CustomFormField[] = [];
      for (const item of body.preChatFields.slice(0, 12)) {
        if (!item || typeof item !== 'object') continue;
        const fieldType: CustomFormFieldType = allowedTypes.includes(item.type)
          ? item.type
          : 'text';
        const label =
          typeof item.label === 'string' && item.label.trim()
            ? item.label.trim().slice(0, 50)
            : 'Field Kustom';
        const rawKey =
          typeof item.key === 'string' && item.key.trim()
            ? item.key.trim().toLowerCase().replace(/[^a-z0-9_]/g, '_')
            : label.toLowerCase().replace(/[^a-z0-9_]/g, '_');
        const options =
          fieldType === 'select' || fieldType === 'radio'
            ? (Array.isArray(item.options) ? item.options : [])
                .filter((opt): opt is string => typeof opt === 'string' && opt.trim().length > 0)
                .map((opt) => opt.trim().slice(0, 60))
                .slice(0, 12)
            : undefined;

        sanitizedFields.push({
          id:
            typeof item.id === 'string' && item.id.trim()
              ? item.id.trim().slice(0, 40)
              : `field_${crypto.randomBytes(4).toString('hex')}`,
          label,
          key: rawKey || `field_${sanitizedFields.length + 1}`,
          type: fieldType,
          placeholder:
            typeof item.placeholder === 'string'
              ? item.placeholder.slice(0, 100)
              : '',
          required: Boolean(item.required),
          options:
            fieldType === 'select' || fieldType === 'radio'
              ? options && options.length > 0
                ? options
                : ['Opsi 1', 'Opsi 2']
              : undefined,
        });
      }
      next.preChatFields = sanitizedFields;
    }

    widgetSettings = next;
    broadcastAll({ type: 'settings:updated', settings: widgetSettings });
    res.json({ settings: widgetSettings });
  });

  // Workspace Public Key registration (public key only; private key stays strictly in admin browser)
  app.put('/api/workspace-key', requireAdminAuth, (req, res) => {
    const { publicKey, fingerprint } = req.body as {
      publicKey?: JsonWebKey;
      fingerprint?: string;
    };
    if (!publicKey || publicKey.kty !== 'EC' || publicKey.crv !== 'P-256') {
      res.status(400).json({ error: 'Public key ECDH P-256 JWK tidak valid.' });
      return;
    }
    workspacePublicKey = publicKey;
    workspaceFingerprint = typeof fingerprint === 'string' ? fingerprint.slice(0, 64) : null;
    broadcastAll({
      type: 'workspace:key',
      workspacePublicKey,
      workspaceFingerprint,
    });
    res.json({ ok: true, workspaceFingerprint });
  });

  // Rooms & Messages
  app.get('/api/rooms', requireAdminAuth, (_req, res) => {
    res.json({ rooms: getSortedRooms() });
  });

  app.get('/api/rooms/:roomId/messages', requireAdminAuth, (req, res) => {
    const { roomId } = req.params;
    res.json({ messages: messagesByRoom.get(roomId) ?? [] });
  });

  app.patch('/api/rooms/:roomId/status', requireAdminAuth, (req, res) => {
    const { roomId } = req.params;
    const { status } = req.body as { status?: VisitorRoom['status'] };
    const room = rooms.get(roomId);
    if (!room) {
      res.status(404).json({ error: 'Ruang percakapan tidak ditemukan.' });
      return;
    }
    if (status && ['active', 'idle', 'resolved'].includes(status)) {
      room.status = status;
      broadcastToAgents({ type: 'room:updated', room });
    }
    res.json({ room });
  });

  app.delete('/api/rooms/:roomId/messages/:messageId', requireAdminAuth, (req, res) => {
    const { roomId, messageId } = req.params;
    const room = rooms.get(roomId);
    if (!room) {
      res.status(404).json({ error: 'Ruang percakapan tidak ditemukan.' });
      return;
    }

    const list = messagesByRoom.get(roomId) ?? [];
    const idx = list.findIndex((m) => m.id === messageId);
    if (idx === -1) {
      res.status(404).json({ error: 'Pesan tidak ditemukan.' });
      return;
    }

    list.splice(idx, 1);
    messagesByRoom.set(roomId, list);
    room.messageCount = list.length;

    const lastMsg = list[list.length - 1];
    if (!lastMsg) {
      room.lastMessagePreview = 'Belum ada pesan';
      room.lastMessageEncrypted = false;
    } else {
      room.lastMessageEncrypted = lastMsg.encrypted;
      const attCount = lastMsg.attachments?.length ?? (lastMsg.attachment ? 1 : 0);
      room.lastMessagePreview = lastMsg.encrypted
        ? 'Pesan terenkripsi end-to-end'
        : attCount > 0
          ? lastMsg.plaintext
            ? `[${attCount} Gambar] ${lastMsg.plaintext}`
            : `[${attCount} Gambar]`
          : lastMsg.plaintext || '';
    }

    broadcastToRoom(roomId, { type: 'message:deleted', roomId, messageId });
    broadcastToAgents({
      type: 'room:updated',
      room,
      analytics: computeAnalytics(),
    });

    res.json({ ok: true, roomId, messageId });
  });

  // Analytics
  app.get('/api/analytics', requireAdminAuth, (_req, res) => {
    res.json({ analytics: computeAnalytics() });
  });

  // API Keys Management
  app.get('/api/keys', requireAdminAuth, (_req, res) => {
    const list = Array.from(apiKeyStore.values()).map((k) => k.record);
    res.json({ keys: list.sort((a, b) => b.createdAt - a.createdAt) });
  });

  app.post('/api/keys', requireAdminAuth, (req, res) => {
    const { name, scopes } = req.body as { name?: string; scopes?: string[] };
    const cleanName =
      typeof name === 'string' && name.trim().length > 0
        ? name.trim().slice(0, 50)
        : 'Integrasi Pihak Ketiga';
    const allowedScopes = ['messages:write', 'analytics:read', 'widget:read'];
    const validScopes = Array.isArray(scopes)
      ? scopes.filter((s) => allowedScopes.includes(s))
      : allowedScopes;

    const rawSecret = `sc_live_${crypto.randomBytes(20).toString('hex')}`;
    const id = `key_${crypto.randomBytes(6).toString('hex')}`;
    const record: ApiKeyRecord = {
      id,
      name: cleanName,
      prefix: `${rawSecret.slice(0, 14)}••••`,
      scopes: validScopes.length > 0 ? validScopes : allowedScopes,
      createdAt: Date.now(),
      lastUsedAt: null,
      requestsCount: 0,
    };

    apiKeyStore.set(id, { record, hash: hashApiKey(rawSecret) });
    res.status(201).json({ key: record, secret: rawSecret });
  });

  app.delete('/api/keys/:id', requireAdminAuth, (req, res) => {
    const deleted = apiKeyStore.delete(req.params.id);
    if (!deleted) {
      res.status(404).json({ error: 'API key tidak ditemukan.' });
      return;
    }
    res.json({ ok: true });
  });

  // Webhooks
  app.get('/api/webhooks', requireAdminAuth, (_req, res) => {
    res.json({ webhooks });
  });

  app.post('/api/webhooks', requireAdminAuth, (req, res) => {
    const { url, events } = req.body as { url?: string; events?: string[] };
    if (typeof url !== 'string' || !isSafeWebhookUrl(url.trim())) {
      res.status(400).json({
        error: 'URL webhook harus menggunakan skema http/https publik yang valid.',
      });
      return;
    }
    const allowedEvents = ['message.encrypted', 'session.started', 'typing.updated'];
    const validEvents = Array.isArray(events)
      ? events.filter((e) => allowedEvents.includes(e))
      : ['message.encrypted'];

    const hook: WebhookConfig = {
      id: `wh_${crypto.randomBytes(5).toString('hex')}`,
      url: url.trim(),
      events: validEvents.length > 0 ? validEvents : ['message.encrypted'],
      active: true,
      createdAt: Date.now(),
      lastStatus: null,
      lastTriggeredAt: null,
    };
    webhooks.unshift(hook);
    res.status(201).json({ webhook: hook });
  });

  app.delete('/api/webhooks/:id', requireAdminAuth, (req, res) => {
    const idx = webhooks.findIndex((w) => w.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'Webhook tidak ditemukan.' });
      return;
    }
    webhooks.splice(idx, 1);
    res.json({ ok: true });
  });

  // Strict Image Validation Endpoint (blocks PHP, SVG, polyglots, double extensions)
  app.options('/api/media/verify', (_req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.status(204).end();
  });

  app.post('/api/media/verify', (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    const { fileName, base64Data } = req.body as {
      fileName?: string;
      base64Data?: string;
    };
    if (typeof fileName !== 'string' || typeof base64Data !== 'string') {
      res.status(400).json({ error: 'Parameter fileName dan base64Data wajib disertakan.' });
      return;
    }
    const result = validateStrictImageBuffer(fileName, base64Data);
    if (!result.ok) {
      res.status(400).json({ error: result.error });
      return;
    }
    res.json({
      verified: true,
      detectedMime: result.mime,
      sizeBytes: result.sizeBytes,
    });
  });

  // Third-Party Public & Authenticated Developer API (/api/v1/*)
  app.get('/api/v1/widget-config', (_req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json({
      settings: widgetSettings,
      workspacePublicKey,
      workspaceFingerprint,
      wsPath: '/ws',
      e2eeAlgorithm: 'ECDH-P256 + AES-256-GCM',
    });
  });

  app.get('/api/v1/analytics', requireApiKey, (_req, res) => {
    res.json({
      analytics: computeAnalytics(),
      generatedAt: new Date().toISOString(),
    });
  });

  app.post('/api/v1/messages', requireApiKey, (req, res) => {
    const {
      roomId,
      senderName,
      plaintext,
      ciphertext,
      iv,
      senderPublicKey,
      keyFingerprint,
    } = req.body as {
      roomId?: string;
      senderName?: string;
      plaintext?: string;
      ciphertext?: string;
      iv?: string;
      senderPublicKey?: JsonWebKey;
      keyFingerprint?: string;
    };

    const targetRoomId = typeof roomId === 'string' && roomId.trim() ? roomId.trim() : 'room-nadia-841';
    const room = rooms.get(targetRoomId);
    if (!room) {
      res.status(404).json({ error: `Room '${targetRoomId}' tidak ditemukan.` });
      return;
    }

    const isEncrypted = Boolean(ciphertext && iv);
    if (!isEncrypted && (typeof plaintext !== 'string' || !plaintext.trim())) {
      res.status(400).json({
        error: 'Sertakan plaintext atau payload terenkripsi (ciphertext + iv).',
      });
      return;
    }

    const msg: ChatMessage = {
      id: `api_${crypto.randomUUID()}`,
      roomId: targetRoomId,
      senderId: 'third-party-api',
      senderName:
        typeof senderName === 'string' && senderName.trim()
          ? senderName.trim().slice(0, 40)
          : 'Integrasi API',
      senderRole: 'api',
      encrypted: isEncrypted,
      ciphertext: isEncrypted ? ciphertext : undefined,
      iv: isEncrypted ? iv : undefined,
      senderPublicKey,
      keyFingerprint: keyFingerprint || room.keyFingerprint,
      plaintext: isEncrypted ? undefined : plaintext?.trim().slice(0, 2000),
      timestamp: Date.now(),
      read: false,
    };

    const list = messagesByRoom.get(targetRoomId) ?? [];
    list.push(msg);
    messagesByRoom.set(targetRoomId, list);

    room.lastActivityAt = msg.timestamp;
    room.messageCount += 1;
    room.lastMessageEncrypted = msg.encrypted;
    room.lastMessagePreview = msg.encrypted
      ? 'Pesan terenkripsi melalui REST API'
      : msg.plaintext || '';

    broadcastToRoom(targetRoomId, { type: 'message:new', message: msg });
    broadcastToAgents({
      type: 'room:updated',
      room,
      analytics: computeAnalytics(),
    });

    res.status(201).json({
      id: msg.id,
      roomId: msg.roomId,
      encrypted: msg.encrypted,
      timestamp: msg.timestamp,
    });
  });

  // Plug-and-play third-party embeddable loader script (zero backend integration required)
  app.get('/embed.js', (req, res) => {
    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'no-cache');
    const forwardedProto = req.header('x-forwarded-proto');
    const protocol = forwardedProto ? forwardedProto.split(',')[0].trim() : req.protocol;
    const origin = `${protocol}://${req.get('host')}`;
    const script = `(function(){
  if(window.__sandichatLoaded) return;
  window.__sandichatLoaded = true;
  var origin = ${JSON.stringify(origin)};
  fetch(origin + '/api/v1/widget-config')
    .then(function(r){ return r.json(); })
    .then(function(cfg){
      var s = cfg.settings || {};
      var accent = s.accentColor || '#10B981';
      var isLeft = s.launcherPosition === 'bottom-left';
      var sideStyle = isLeft ? 'left:24px;' : 'right:24px;';
      var useImage = s.launcherMode === 'image' && typeof s.launcherImageUrl === 'string' &&
        (/^data:image\\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+\\/=]+$/.test(s.launcherImageUrl) || /^https?:\\/\\//.test(s.launcherImageUrl) || s.launcherImageUrl.charAt(0) === '/');

      var wrap = document.createElement('div');
      wrap.style.cssText = 'position:fixed;bottom:24px;' + sideStyle +
        'z-index:2147483000;display:flex;align-items:center;gap:10px;' +
        (isLeft ? 'flex-direction:row-reverse;' : 'flex-direction:row;');

      var bubble = null;
      if(useImage && s.launcherBubbleText){
        bubble = document.createElement('div');
        bubble.textContent = s.launcherBubbleText;
        bubble.style.cssText = 'padding:8px 12px;border-radius:10px;background:#0F1218;color:#F8FAFC;' +
          'border:1px solid rgba(255,255,255,0.14);font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;' +
          'font-size:12px;font-weight:500;box-shadow:0 10px 26px rgba(0,0,0,0.45);max-width:210px;cursor:pointer;';
        wrap.appendChild(bubble);
      }

      var btn = document.createElement('button');
      btn.setAttribute('aria-label', 'Buka ' + (s.brandName || 'SandiChat'));
      if(useImage){
        var size = Math.min(128, Math.max(48, Number(s.launcherImageSize) || 72));
        var shape = s.launcherImageShape || 'floating';
        var shapeStyle = shape === 'circle'
          ? 'border-radius:9999px;border:2px solid ' + accent + ';background:#0F1218;overflow:hidden;box-shadow:0 14px 34px rgba(0,0,0,0.52);'
          : shape === 'rounded'
            ? 'border-radius:16px;border:1px solid rgba(255,255,255,0.16);background:#0F1218;overflow:hidden;box-shadow:0 14px 34px rgba(0,0,0,0.52);'
            : 'border-radius:0;border:none;background:transparent;filter:drop-shadow(0 12px 24px rgba(0,0,0,0.52));';
        btn.style.cssText = 'width:' + size + 'px;height:' + size + 'px;padding:0;cursor:pointer;' +
          'display:inline-flex;align-items:center;justify-content:center;transition:transform 0.18s ease;' + shapeStyle;
        var img = document.createElement('img');
        img.src = s.launcherImageUrl;
        img.alt = s.brandName || 'Live Chat';
        img.style.cssText = 'width:100%;height:100%;object-fit:' + (shape === 'floating' ? 'contain' : 'cover') + ';display:block;pointer-events:none;';
        btn.appendChild(img);
        btn.onmouseenter = function(){ btn.style.transform = 'scale(1.06)'; };
        btn.onmouseleave = function(){ btn.style.transform = 'scale(1)'; };
      } else {
        btn.style.cssText = 'display:inline-flex;align-items:center;gap:8px;padding:11px 16px;' +
          'border:1px solid rgba(255,255,255,0.14);border-radius:12px;background:#0F1218;color:#F8FAFC;' +
          'font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;font-size:13px;font-weight:600;' +
          'cursor:pointer;box-shadow:0 14px 34px rgba(0,0,0,0.48);transition:transform 0.16s ease,opacity 0.16s ease;';
        btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">' +
          '<path d="M12 3L4.5 6.2V11.5C4.5 16.3 7.7 20.6 12 22C16.3 20.6 19.5 16.3 19.5 11.5V6.2L12 3Z" stroke="' + accent + '" stroke-width="2" stroke-linejoin="round"/>' +
          '<path d="M9.5 12L11.2 13.7L14.8 10.1" stroke="' + accent + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' +
          '</svg>';
        var label = document.createElement('span');
        label.textContent = s.brandName || 'Live Chat';
        btn.appendChild(label);
      }
      wrap.appendChild(btn);

      var frameWrap = null;
      var isOpen = false;
      function setOpen(next){
        if(next){
          if(!frameWrap){
            frameWrap = document.createElement('div');
            frameWrap.style.cssText = 'position:fixed;bottom:24px;' + sideStyle +
              'z-index:2147483001;width:368px;max-width:calc(100vw - 24px);height:520px;max-height:calc(100vh - 48px);' +
              'border-radius:14px;overflow:hidden;border:1px solid rgba(255,255,255,0.14);' +
              'box-shadow:0 24px 64px rgba(0,0,0,0.65);background:#090A0D;';
            var iframe = document.createElement('iframe');
            iframe.src = origin + '/?embed=1';
            iframe.title = (s.brandName || 'SandiChat') + ' Widget';
            iframe.setAttribute('allow', 'clipboard-write');
            iframe.style.cssText = 'width:100%;height:100%;border:0;';
            frameWrap.appendChild(iframe);
            document.body.appendChild(frameWrap);
          } else {
            frameWrap.style.display = 'block';
          }
          wrap.style.display = 'none';
          isOpen = true;
        } else {
          if(frameWrap) frameWrap.style.display = 'none';
          wrap.style.display = 'flex';
          isOpen = false;
        }
      }

      btn.onclick = function(){ setOpen(!isOpen); };
      if(bubble) bubble.onclick = function(){ setOpen(true); };
      window.addEventListener('message', function(ev){
        if(ev && ev.data === 'sandichat:close'){
          setOpen(false);
        }
      });
      document.body.appendChild(wrap);
    }).catch(function(err){ console.warn('SandiChat embed error:', err); });
})();`;
    res.send(script);
  });

  const httpServer = http.createServer(app);
  const wss = new WebSocketServer({
    server: httpServer,
    path: '/ws',
    maxPayload: 12 * 1024 * 1024,
  });

  wss.on('connection', (ws) => {
    const meta: SocketMeta = {
      ws,
      role: 'visitor',
      clientId: crypto.randomUUID(),
    };
    sockets.add(meta);

    ws.on('message', (raw) => {
      try {
        const data = JSON.parse(raw.toString()) as Record<string, unknown>;
        const eventType = data.type;

        if (eventType === 'join') {
          const role = data.role === 'agent' ? 'agent' : 'visitor';

          if (role === 'agent') {
            const session = verifyAdminSessionToken(
              typeof data.token === 'string' ? data.token : null
            );
            if (!session) {
              ws.send(
                JSON.stringify({
                  type: 'auth:error',
                  error: 'Sesi dashboard tidak valid. Silakan login kembali.',
                })
              );
              ws.close(4001, 'Unauthorized');
              return;
            }
            meta.role = 'agent';
            ws.send(
              JSON.stringify({
                type: 'init',
                role: 'agent',
                settings: widgetSettings,
                workspacePublicKey,
                workspaceFingerprint,
                rooms: getSortedRooms(),
                analytics: computeAnalytics(),
              })
            );
          } else {
            meta.role = 'visitor';
            const requestedRoomId =
              typeof data.roomId === 'string' && data.roomId.trim()
                ? data.roomId.trim()
                : `room-visitor-${crypto.randomBytes(3).toString('hex')}`;
            meta.roomId = requestedRoomId;

            const visitorInfo = (data.visitorInfo ?? {}) as Record<string, unknown>;
            let room = rooms.get(requestedRoomId);
            if (!room) {
              room = {
                id: requestedRoomId,
                visitorName:
                  typeof visitorInfo.name === 'string' && visitorInfo.name.trim()
                    ? visitorInfo.name.trim().slice(0, 40)
                    : `Pengunjung #${requestedRoomId.slice(-4).toUpperCase()}`,
                currentPage:
                  typeof visitorInfo.currentPage === 'string'
                    ? visitorInfo.currentPage.slice(0, 120)
                    : '/widget-live',
                location:
                  typeof visitorInfo.location === 'string'
                    ? visitorInfo.location.slice(0, 40)
                    : 'Jakarta, ID',
                device:
                  typeof visitorInfo.device === 'string'
                    ? visitorInfo.device.slice(0, 24)
                    : 'Desktop',
                browser:
                  typeof visitorInfo.browser === 'string'
                    ? visitorInfo.browser.slice(0, 32)
                    : 'Web Browser',
                status: 'active',
                online: true,
                unreadCount: 0,
                e2eeVerified: Boolean(data.publicKey),
                visitorPublicKey: data.publicKey as JsonWebKey | undefined,
                keyFingerprint:
                  typeof data.fingerprint === 'string' ? data.fingerprint : undefined,
                startedAt: Date.now(),
                lastActivityAt: Date.now(),
                lastMessagePreview: 'Sesi terenkripsi dimulai',
                lastMessageEncrypted: true,
                messageCount: 0,
              };
              rooms.set(requestedRoomId, room);
              messagesByRoom.set(requestedRoomId, []);
            } else {
              room.online = true;
              if (data.publicKey) {
                room.visitorPublicKey = data.publicKey as JsonWebKey;
                room.e2eeVerified = true;
              }
              if (typeof data.fingerprint === 'string') {
                room.keyFingerprint = data.fingerprint;
              }
            }

            ws.send(
              JSON.stringify({
                type: 'init',
                role: 'visitor',
                roomId: requestedRoomId,
                room,
                settings: widgetSettings,
                workspacePublicKey,
                workspaceFingerprint,
                messages: messagesByRoom.get(requestedRoomId) ?? [],
              })
            );

            broadcastToAgents({
              type: 'room:updated',
              room,
              analytics: computeAnalytics(),
            });
          }
          return;
        }

        if (eventType === 'visitor:prechat') {
          const roomId = typeof data.roomId === 'string' ? data.roomId : meta.roomId;
          if (!roomId) return;
          const room = rooms.get(roomId);
          if (!room) return;

          const attrsRaw = (data.customAttributes ?? {}) as Record<string, unknown>;
          const cleanAttrs: Record<string, string> = {};
          for (const [k, v] of Object.entries(attrsRaw).slice(0, 15)) {
            if (typeof v === 'string' && v.trim()) {
              cleanAttrs[k.slice(0, 40)] = v.trim().slice(0, 200);
            }
          }

          room.customAttributes = { ...(room.customAttributes ?? {}), ...cleanAttrs };

          const candidateName =
            cleanAttrs.username ||
            cleanAttrs.nama ||
            cleanAttrs.name ||
            Object.values(cleanAttrs)[0];
          if (candidateName) {
            room.visitorName = candidateName.slice(0, 40);
          }
          if (cleanAttrs.email) {
            room.visitorEmail = cleanAttrs.email.slice(0, 80);
          }

          room.lastActivityAt = Date.now();
          broadcastToAgents({
            type: 'room:updated',
            room,
            analytics: computeAnalytics(),
          });
          return;
        }

        if (eventType === 'e2ee:pubkey') {
          const roomId = typeof data.roomId === 'string' ? data.roomId : meta.roomId;
          if (!roomId) return;
          const room = rooms.get(roomId);
          if (room && data.publicKey) {
            room.visitorPublicKey = data.publicKey as JsonWebKey;
            room.e2eeVerified = true;
            if (typeof data.fingerprint === 'string') {
              room.keyFingerprint = data.fingerprint;
            }
            broadcastToRoom(roomId, {
              type: 'e2ee:pubkey',
              roomId,
              publicKey: data.publicKey,
              fingerprint: data.fingerprint,
            });
            broadcastToAgents({ type: 'room:updated', room });
          }
          return;
        }

        if (eventType === 'message:send') {
          const msgPayload = data.message as Partial<ChatMessage> | undefined;
          if (!msgPayload || typeof msgPayload.roomId !== 'string' || typeof msgPayload.id !== 'string') {
            return;
          }

          const roomId = msgPayload.roomId;
          const room = rooms.get(roomId);
          if (!room) return;

          const list = messagesByRoom.get(roomId) ?? [];
          // Idempotent check
          if (list.some((m) => m.id === msgPayload.id)) {
            return;
          }

          const isEncrypted = Boolean(msgPayload.encrypted && msgPayload.ciphertext && msgPayload.iv);
          let validatedAttachments: ImageAttachment[] = [];
          if (!isEncrypted) {
            const rawAttachments: Partial<ImageAttachment>[] = Array.isArray(msgPayload.attachments)
              ? msgPayload.attachments.slice(0, 6)
              : msgPayload.attachment
                ? [msgPayload.attachment]
                : [];

            for (const att of rawAttachments) {
              if (
                att &&
                typeof att.fileName === 'string' &&
                typeof att.dataUrl === 'string' &&
                att.dataUrl.startsWith('data:image/')
              ) {
                const check = validateStrictImageBuffer(att.fileName, att.dataUrl);
                if (!check.ok) {
                  ws.send(JSON.stringify({ type: 'error', error: check.error }));
                  return;
                }
                validatedAttachments.push({
                  dataUrl: att.dataUrl,
                  fileName: att.fileName.slice(0, 120),
                  mimeType: check.mime,
                  sizeBytes: check.sizeBytes,
                  width: typeof att.width === 'number' ? att.width : undefined,
                  height: typeof att.height === 'number' ? att.height : undefined,
                });
              } else {
                ws.send(JSON.stringify({ type: 'error', error: 'Lampiran gambar tidak valid.' }));
                return;
              }
            }
          }

          const cleanMsg: ChatMessage = {
            id: msgPayload.id,
            roomId,
            senderId:
              typeof msgPayload.senderId === 'string' ? msgPayload.senderId : meta.clientId,
            senderName:
              typeof msgPayload.senderName === 'string' ? msgPayload.senderName : 'Pengguna',
            senderRole:
              msgPayload.senderRole === 'agent' && meta.role === 'agent' ? 'agent' : 'visitor',
            encrypted: isEncrypted,
            ciphertext: isEncrypted ? msgPayload.ciphertext : undefined,
            iv: isEncrypted ? msgPayload.iv : undefined,
            senderPublicKey: msgPayload.senderPublicKey,
            keyFingerprint: msgPayload.keyFingerprint || room.keyFingerprint,
            plaintext: isEncrypted ? undefined : msgPayload.plaintext?.slice(0, 4000),
            attachment: validatedAttachments[0],
            attachments: validatedAttachments.length > 0 ? validatedAttachments : undefined,
            timestamp: typeof msgPayload.timestamp === 'number' ? msgPayload.timestamp : Date.now(),
            read: false,
          };

          list.push(cleanMsg);
          messagesByRoom.set(roomId, list);

          room.lastActivityAt = cleanMsg.timestamp;
          room.messageCount += 1;
          room.status = 'active';
          room.lastMessageEncrypted = cleanMsg.encrypted;
          room.lastMessagePreview = cleanMsg.encrypted
            ? 'Pesan terenkripsi end-to-end'
            : validatedAttachments.length > 0
              ? cleanMsg.plaintext
                ? `[${validatedAttachments.length} Gambar] ${cleanMsg.plaintext}`
                : `[${validatedAttachments.length} Gambar] ${validatedAttachments[0].fileName}`
              : cleanMsg.plaintext || '';

          if (cleanMsg.senderRole === 'visitor') {
            room.unreadCount += 1;
            if (msgPayload.senderPublicKey) {
              room.visitorPublicKey = msgPayload.senderPublicKey;
              room.e2eeVerified = true;
            }
          }

          // Clear sender typing state upon message send
          const roomTyping = typingByRoom.get(roomId);
          if (roomTyping && roomTyping.has(cleanMsg.senderId)) {
            roomTyping.delete(cleanMsg.senderId);
            broadcastToRoom(roomId, {
              type: 'typing:state',
              typing: {
                roomId,
                senderId: cleanMsg.senderId,
                senderName: cleanMsg.senderName,
                senderRole: cleanMsg.senderRole,
                isTyping: false,
                updatedAt: Date.now(),
              },
            });
          }

          broadcastToRoom(roomId, { type: 'message:new', message: cleanMsg });
          broadcastToAgents({
            type: 'room:updated',
            room,
            analytics: computeAnalytics(),
          });
          return;
        }

        if (eventType === 'typing:update') {
          const roomId = typeof data.roomId === 'string' ? data.roomId : meta.roomId;
          if (!roomId) return;
          const typing: TypingState = {
            roomId,
            senderId: typeof data.senderId === 'string' ? data.senderId : meta.clientId,
            senderName: typeof data.senderName === 'string' ? data.senderName : 'Pengguna',
            senderRole:
              data.senderRole === 'agent' && meta.role === 'agent' ? 'agent' : 'visitor',
            isTyping: Boolean(data.isTyping),
            updatedAt: Date.now(),
          };

          if (!typingByRoom.has(roomId)) {
            typingByRoom.set(roomId, new Map());
          }
          const map = typingByRoom.get(roomId)!;
          if (typing.isTyping) {
            map.set(typing.senderId, typing);
          } else {
            map.delete(typing.senderId);
          }

          broadcastToRoom(roomId, { type: 'typing:state', typing });
          return;
        }

        if (eventType === 'room:read') {
          if (meta.role !== 'agent') return;
          const roomId = typeof data.roomId === 'string' ? data.roomId : '';
          const room = rooms.get(roomId);
          if (!room) return;
          room.unreadCount = 0;
          const list = messagesByRoom.get(roomId) ?? [];
          for (const msg of list) {
            msg.read = true;
          }
          broadcastToRoom(roomId, { type: 'room:read', roomId });
          broadcastToAgents({ type: 'room:updated', room });
        }
      } catch {
        // Ignore malformed socket frames
      }
    });

    ws.on('close', () => {
      sockets.delete(meta);
      if (meta.role === 'visitor' && meta.roomId) {
        const room = rooms.get(meta.roomId);
        if (room) {
          // Only mark offline if no other visitor socket is open in this room
          const stillConnected = Array.from(sockets).some(
            (s) => s.role === 'visitor' && s.roomId === meta.roomId && s.ws.readyState === WebSocket.OPEN
          );
          if (!stillConnected) {
            room.online = false;
            room.status = room.status === 'resolved' ? 'resolved' : 'idle';
            broadcastToAgents({
              type: 'room:updated',
              room,
              analytics: computeAnalytics(),
            });
          }
        }
      }
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use('/src/assets/images', express.static(path.resolve(__dirname, 'src/assets/images')));
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`SandiChat server running on http://0.0.0.0:${PORT}`);
  });
}

createServer();
